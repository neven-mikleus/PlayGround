select
	dtc.counterparty_id,
	concat(dtpts.product_type_id,'-', dtpts.product_subtype_id) as dwh_code ,
	dtpts.rzb_grp_prod_type_id as gpc
from
	lng_zne_g30.dwhco_tb0_counterparty dtc
join lng_zne_g30.dwhco_tb0_product_type_subtype dtpts on
	dtpts.product_type_id = dtc.product_type_id
	and dtpts.product_subtype_id = dtc.product_subtype_id
where
	dtc.counterparty_id = '016-10-368723'
	and date'2023-11-30' between dtc.bus_date_from and dtc.bus_date_until
	and date'2023-11-30' between dtpts.bus_date_from and dtpts.bus_date_until;