with dat as
(
select '418-42-1008265*GAR*RBHRCBS*RBHR' id_contract from dual  union
select '038-40-905354*GAR*RBHRCBS*RBHR' id_contract from dual  
)
select 
id_contract,
regexp_substr(id_contract,'\*[^*]+\*') modul_asterics
,regexp_substr(id_contract,'[^\*]+\\*[^\*]+') counterparty_id
,regexp_substr(id_contract,'\*(.*?)\*',1,1,null,1) modul
 from   dat

