DECLARE
   l_date_start        DATE := DATE '2021-06-30';
   l_date_end          DATE := DATE '2021-08-31';
   
BEGIN
dbms_output.put_line('prompt  PO�ETAK'||chr(10));

dbms_output.put_line(
  ' set echo off
    set feedback off
    set linesize 1000
    set pagesize 0
    set sqlprompt ''''
    set trimspool on
    set headsep off
    set trim on
    set wrap off');
    
   WHILE l_date_start <= l_date_end
   LOOP
      dbms_output.put_line('spool c:\temp\nmi_export_'||to_char(l_date_start,'yyyymmdd')||'.csv'||chr(10));
    
      dbms_output.put_line(
      'SELECT    a.CLIENT_ID
                    || ''|''
                    || a.UNIQUE_CAMP_CUST_ID
                    || ''|''
                    || a.APPL_ID
                    || ''|''
                       record
               FROM dwhrba.car360_INTERACTION a
              WHERE A.REPORTING_DATE = date'''||to_char(l_date_start,'yyyy-mm-dd')||'''
              fetch first 50 rows only;'||chr(10)
      );
      
       dbms_output.put_line('spool off'||chr(10));

      l_date_start := ADD_MONTHS (l_date_start, 1);
   END LOOP;
    dbms_output.put_line('prompt  KRAJ'||chr(10));
END;
/