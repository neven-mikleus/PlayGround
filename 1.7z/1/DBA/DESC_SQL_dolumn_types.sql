DECLARE
   cur               PLS_INTEGER := DBMS_SQL.OPEN_CURSOR;
   cols              DBMS_SQL.DESC_TAB;
   ncols             PLS_INTEGER;

   l_guid            RAW (32);
   l_col_type_name   VARCHAR2 (255);

   PROCEDURE p_desc (p_sql IN CLOB, P_GUID OUT RAW)
   IS
   BEGIN
      P_GUID := SYS_GUID;

      BEGIN
         EXECUTE IMMEDIATE 'CREATE TABLE GROUPDWH.TEMP_SQL_DESC_COLUMNS(
        uid_col RAW(32),
        col_type            NUMBER ,
        col_type_name            varchar2(255) ,
        col_max_len         NUMBER ,
        col_name            varchar2(255)  ,
        col_name_len        NUMBER ,
        col_schema_name     varchar2(255)  ,
        col_schema_name_len NUMBER ,
        col_precision       NUMBER ,
        col_scale           NUMBER ,
        col_charsetid       NUMBER ,
        col_charsetform     NUMBER ,
        col_null_ok         NUMBER 
       )';
      EXCEPTION
         WHEN OTHERS
         THEN
            NULL;
      END;

      DBMS_SQL.PARSE (cur, p_sql, DBMS_SQL.NATIVE);
      DBMS_SQL.DESCRIBE_COLUMNS (cur, ncols, cols);

      FOR i IN 1 .. ncols
      LOOP
         l_col_type_name :=
            CASE cols (i).col_type
               WHEN DBMS_TYPES.TYPECODE_DATE THEN 'DATE'
               WHEN DBMS_TYPES.TYPECODE_NUMBER THEN 'NUMBER'
               WHEN DBMS_TYPES.TYPECODE_RAW THEN 'RAW'
               WHEN DBMS_TYPES.TYPECODE_CHAR THEN 'CHAR'
               WHEN DBMS_TYPES.TYPECODE_VARCHAR2 THEN 'VARCHAR2'
               WHEN DBMS_TYPES.TYPECODE_VARCHAR THEN 'VARCHAR'
               WHEN DBMS_TYPES.TYPECODE_MLSLABEL THEN 'MLSLABEL'
               WHEN DBMS_TYPES.TYPECODE_BLOB THEN 'BLOB'
               WHEN DBMS_TYPES.TYPECODE_BFILE THEN 'BFILE'
               WHEN DBMS_TYPES.TYPECODE_CLOB THEN 'CLOB'
               WHEN DBMS_TYPES.TYPECODE_CFILE THEN 'CFILE'
               WHEN DBMS_TYPES.TYPECODE_TIMESTAMP THEN 'TIMESTAMP'
               WHEN DBMS_TYPES.TYPECODE_TIMESTAMP_TZ THEN 'TIMESTAMP_TZ'
               WHEN DBMS_TYPES.TYPECODE_TIMESTAMP_LTZ THEN 'TIMESTAMP_LTZ'
               WHEN DBMS_TYPES.TYPECODE_INTERVAL_YM THEN 'INTERVAL_YM'
               WHEN DBMS_TYPES.TYPECODE_INTERVAL_DS THEN 'INTERVAL_DS'
               WHEN DBMS_TYPES.TYPECODE_REF THEN 'REF'
               WHEN DBMS_TYPES.TYPECODE_OBJECT THEN 'OBJECT'
               WHEN DBMS_TYPES.TYPECODE_VARRAY THEN 'VARRAY'
               WHEN DBMS_TYPES.TYPECODE_TABLE THEN 'TABLE'
               WHEN DBMS_TYPES.TYPECODE_NAMEDCOLLECTION THEN 'NAMEDCOLLECTION'
               WHEN DBMS_TYPES.TYPECODE_OPAQUE THEN 'OPAQUE'
               WHEN DBMS_TYPES.TYPECODE_NCHAR THEN 'NCHAR'
               WHEN DBMS_TYPES.TYPECODE_NVARCHAR2 THEN 'NVARCHAR2'
               WHEN DBMS_TYPES.TYPECODE_NCLOB THEN 'NCLOB'
               WHEN DBMS_TYPES.TYPECODE_BFLOAT THEN 'BFLOAT'
               WHEN DBMS_TYPES.TYPECODE_BDOUBLE THEN 'BDOUBLE'
               WHEN DBMS_TYPES.TYPECODE_UROWID THEN 'UROWID'
            END;


         INSERT INTO GROUPDWH.TEMP_SQL_DESC_COLUMNS (uid_col,
                                                     col_type,
                                                     col_type_name,
                                                     col_max_len,
                                                     col_name,
                                                     col_name_len,
                                                     col_schema_name,
                                                     col_schema_name_len,
                                                     col_precision,
                                                     col_scale,
                                                     col_charsetid,
                                                     col_charsetform)
              VALUES (P_GUID,
                      cols (i).col_type,
                      l_col_type_name,
                      cols (i).col_max_len,
                      cols (i).col_name,
                      cols (i).col_name_len,
                      cols (i).col_schema_name,
                      cols (i).col_schema_name_len,
                      cols (i).col_precision,
                      cols (i).col_scale,
                      cols (i).col_charsetid,
                      cols (i).col_charsetform);
      /*
       DBMS_OUTPUT.PUT_LINE (
       'Column name:'|| cols(i).col_name ||
       ' Column type:'|| cols(i).col_type ||
       ' Max column length:' || cols(i).col_max_len);
       */
      END LOOP;

      DBMS_SQL.CLOSE_CURSOR (cur);
      COMMIT;
   END;
BEGIN
   p_desc (
      p_sql    => 'select A.COUNTERPARTY_ID, A.BUS_DATE_FROM from   DWHCO.TB0_COUNTERPARTY a where 1=1 and  rownum <4',
      p_guid   => l_guid);
   DBMS_OUTPUT.put_line ('' || l_guid);
   
END;