select dbms_metadata.get_ddl('TABLE', 'FV_SBL_KONTROLA_IMP_PIVOT','DWHRBA') from dual 
--union all select dbms_metadata.get_ddl('TABLE', '<ime_tab>','<OWNER>') from dual 
--union all select dbms_metadata.get_ddl('TABLE', '<ime_tab>','<OWNER>') from dual 
--union all select dbms_metadata.get_ddl('TABLE', '<ime_tab>','<OWNER>') from dual 


select * from   DWHRBA.FV_SBL_KONTROLA_MOVEMENT_RBHR;

    select * from   DWHRBA.FV_SBL_KONTROLA_IMP;
    
    select * from   DWHRBA.FV_SBL_KONTROLA_IMP_PIVOT;