--CREATE TABLE nmi_test( DATA CLOB);
DECLARE 
   v_clob clob;
   v_cnt number := 1;
  
BEGIN
 v_clob := empty_clob();

 v_clob := '--';
 DBMS_LOB.APPEND(v_clob,'--');

FOR REC IN (
SELECT VIEW_NAME, OWNER,dbms_metadata.get_ddl('VIEW', VIEW_NAME,'DWHRBA') DDL,
DBMS_LOB.GETLENGTH(dbms_metadata.get_ddl('VIEW', VIEW_NAME,'DWHRBA')) L
  FROM ALL_VIEWS A
 WHERE 1 = 1 AND A.OWNER = 'DWHRBA' AND VIEW_NAME LIKE 'POS%'
 AND VIEW_NAME NOT LIKE '%OLD'
) loop
   
    DBMS_LOB.APPEND(v_clob,to_clob(rec.DDL));
    v_cnt := v_cnt+1;
end loop;


delete nmi_test;
insert into nmi_test(data) values (v_clob);

commit;
  
  
end;