with to_dwh as
(
select 'IMP_V_CONTRACT_LEVEL_REPORT' obj_name from dual  union all
select 'IMP_V_MOVEMENT_RBHR' obj_name from dual  union all
select 'EIR_V_MOVEMENT' obj_name from dual  union all
select 'EIR_V_OUTPUT' obj_name from dual  union all
select 'OSA_V_CONTRACT_LEVEL_REPORT' obj_name from dual   
)
select
level lvl,
substr(
lpad(' ',level*4)||
        (connect_by_root 
        d.referenced_type || ':' || 
        d.referenced_name) ||
        sys_connect_by_path(type || ':' || name, ' -> '), 4) putanja,
        case
        when d.name in (select obj_name from  to_dwh ) or
             d.referenced_name in (select obj_name from  to_dwh )  then 'DA' else 'NE' end koristi_u_dwh,
             d.name,
             d.referenced_name               
from
        all_dependencies d
start with
        d.referenced_type = 'TABLE'
and     d.referenced_name = 'RES_EIR_DBG' -- 'RES_EIR_DBG'
connect by nocycle
        d.referenced_name = prior name
and     d.referenced_type = prior type
--and     referenced_owner = 'FV_FIN_PROD'

BENCH_V_RES_EIR_DBG