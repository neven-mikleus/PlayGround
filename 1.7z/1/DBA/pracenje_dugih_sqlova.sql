/*

https://ittutorial.org/vsession_longops-find-long-running-queries-long-ops-in-oracle/

https://www.dba-oracle.com/longops.htm

*/

select 
A.SQL_ID,
A.SQLTYPE,
B.SID,
B.SERIAL#,
b.module,
l.OPNAME,
l.TARGET,
l.SOFAR,
l.TOTALWORK,
l.START_TIME,
l.LAST_UPDATE_TIME,
l.TIME_REMAINING,
sysdate + (l.TIME_REMAINING/24/60/60) will_finish_at,
l.ELAPSED_SECONDS,
l.MESSAGE,
l.SQL_PLAN_OPERATION,
a.sql_text
 from   v$sql a
        join V$SESSION b on B.SQL_ID = a.sql_id
        join v$session_longops l on L.SID = b.sid and L.SERIAL# = B.SERIAL#
where 1=1 
--and   a.sql_text like 'MERGE INTO DWHRBA.TB0_REPAYMENT_SCHEDULE_HISTORY Y%'
and l.SOFAR <> l.TOTALWORK



--
-- Find the Top 10 long running Query by User parameter
--

SELECT sofar Blocks_Processed,
       totalwork Total_Work,
       ROUND ( (sofar / totalwork) * 100, 2) Percentage_Completed,
       totalwork - sofar Total_Work_Left,
       start_time Start_Time,
       ROUND ( (elapsed_seconds / 60), 0) Elapsed_Minutes,
       SUBSTR (MESSAGE, 1, 33) MESSAGE,
       username
  FROM v$session_longops
 WHERE ROWNUM < 10 AND username = 'SYS'

--

--Find the SQL ID of long running query
--

SELECT SID,
       SERIAL#,
       OPNAME,
       TARGET,
       SOFAR,
       TOTALWORK,
       UNITS,
       TO_CHAR (START_TIME, 'DD/MON/YYYY HH24:MI:SS') START_TIME,
       TO_CHAR (LAST_UPDATE_TIME, 'DD/MON/YYYY HH24:MI:SS') LAST_UPDATE_TIME,
       TIME_REMAINING,
       ELAPSED_SECONDS,
       MESSAGE,
       USERNAME
  FROM V$SESSION_LONGOPS
 WHERE TIME_REMAINING != 0;

--
--Find the Sql Text related with SQL _id
--

SELECT SQL_ID, SQL_TEXT, ELAPSED_TIME
  FROM V$SQL
 WHERE SQL_ID = (SELECT SQL_ID
                   FROM V$SESSION
                  WHERE SID = ????);