with dat as
(
select '1' provision_id, date'2020-02-29' date_from,  date'9999-07-01' date_until from dual union all
select '1' provision_id, date'2022-12-31' date_from,  date'9999-07-01' date_until from dual union all
select '1' provision_id, date'2023-02-28' date_from,  date'9999-07-01' date_until from dual  
)
, dat2 as
(
select d.date_from, d.date_until, lead(d.date_from) over (partition by provision_id order by date_from) lead_date_from from  dat d 
) 
select d.date_from, d.date_until, lead_date_from-1
  from dat2 d
 order by d.date_from;
 
  
  