https://blogs.oracle.com/optimizer/post/how-to-generate-a-useful-sql-execution-plan

https://docs.oracle.com/database/121/TGSQL/tgsql_join.htm#TGSQL244

When the Optimizer Considers Nested Loops Joins
Nested loops joins are useful when the database joins small subsets of data, the database joins large sets of data with the optimizer mode set to FIRST_ROWS, or the join condition is an efficient method of accessing the inner table.

When the Optimizer Considers Hash Joins
In general, the optimizer considers a hash join when a relatively large amount of data must be joined (or a large percentage of a small table must be joined), and the join is an equijoin.

When the Optimizer Considers Sort Merge Joins
A hash join requires one hash table and one probe of this table, whereas a sort merge join requires two sorts.

The optimizer may choose a sort merge join over a hash join for joining large amounts of data when any of the following conditions is true:

The join condition between two tables is not an equijoin, that is, uses an inequality condition such as <, <=, >, or >=.

In contrast to sort merges, hash joins require an equality condition.

Because of sorts required by other operations, the optimizer finds it cheaper to use a sort merge.

If an index exists, then the database can avoid sorting the first data set. However, the database always sorts the second data set, regardless of indexes.

--
-- 1. Ovdje stavi svoj selekt kojega žeLiš monitorirati
--
SELECT /*+ MONITOR PARALLEL(4) */
/* CODE123*/
		CASE 
			WHEN A.CUSTOMER_ID = '0' OR A.CUSTOMER_ID IS NULL THEN 
				'910079' 
			ELSE 
				CASE 
						WHEN A.CATEGORY_ID = '31100' THEN 
							'910079' 
				ELSE  
					A.CUSTOMER_ID 
				END 
		END AS  CUSTOMER_ID,
		CASE WHEN CUS.TIGER_ASSET_CLASS_ID IN ('1','20') THEN 'RET' ELSE 'NRT' END NRT_RET,
		--
		--
		--
		round(SUM(  CASE WHEN 
		       (A.CATEGORY_ID LIKE '5%' OR A.CATEGORY_ID LIKE '3%' OR A.CATEGORY_ID LIKE '42%' OR A.CATEGORY_ID LIKE '44%' 
		        OR A.CATEGORY_ID LIKE'1000_' OR A.CATEGORY_ID IN ('100392', '10004', '10044' ))
		        AND A.CATEGORY_ID != '507135' 
		        AND A.CATEGORY_ID NOT LIKE '5____9_' AND A.CATEGORY_ID NOT LIKE '5_8____' 
		        AND A.CATEGORY_ID NOT LIKE '54__9_' AND A.CATEGORY_ID NOT LIKE '5_8___' AND A.CATEGORY_ID NOT LIKE '50120%'    
			    AND A.CATEGORY_ID NOT LIKE '30%' AND A.CATEGORY_ID NOT LIKE '39%' AND A.CATEGORY_ID NOT LIKE '35%'
		        AND A.CATEGORY_ID NOT LIKE '38%' AND A.CATEGORY_ID NOT LIKE '34__571'
				AND A.CATEGORY_ID NOT LIKE '3____9_' AND A.CATEGORY_ID NOT LIKE '3_8____'
		        AND A.CATEGORY_ID NOT LIKE '3___9_' AND A.CATEGORY_ID NOT LIKE '3_8___' 
		        AND A.CATEGORY_ID NOT LIKE '36__7__' AND A.CATEGORY_ID NOT IN ( '31104', '3118') 
			    AND A.CATEGORY_ID NOT LIKE '4_8____' 
		        AND A.CATEGORY_ID NOT LIKE '42__7__'
		    THEN A.DEBIT_AMOUNT_LCY - A.CREDIT_AMOUNT_LCY ELSE 0 END),2) AS GLAVNICA
	FROM DWHRBA.TB0_ZBA_2024 A 
	     JOIN DWHCO.TB0_CUSTOMER CUS ON CUS.CUSTOMER_ID = A.CUSTOMER_ID 
	WHERE 1=1
	AND DATE'2024-10-31'  BETWEEN CUS.BUS_DATE_FROM AND CUS.BUS_DATE_UNTIL
	--AND A.GL_DOC_TYPE NOT IN ('973', '975', '972') AND A.GL_DOC_TYPE NOT LIKE ('96%')
	AND A.ZBA_VALUE_DATE BETWEEN DATE'2023-12-31' AND DATE'2024-01-31' 
	AND A.ZBA_POSTING_DATE <  DATE'2024-11-06'
	AND CUS.CUSTOMER_ID = '1'
GROUP BY CASE 
			WHEN A.CUSTOMER_ID = '0' OR A.CUSTOMER_ID IS NULL THEN 
				'910079' 
			ELSE 
				CASE 
						WHEN A.CATEGORY_ID = '31100' THEN 
							'910079' 
				ELSE  
					A.CUSTOMER_ID 
				END 
		END ,
		CASE WHEN CUS.TIGER_ASSET_CLASS_ID IN ('1','20') THEN 'RET' ELSE 'NRT' END
	;
   
--
-- Nađi svoj SQL prema šifri za pretraživanje
--
SELECT S.SQL_ID,S.*
FROM v$sql s
WHERE sql_text LIKE '%CODE123%'
-- koristi svoju šifru za pretraživanje
AND sql_text NOT LIKE '%v$sql%'
ORDER BY s.last_active_time DESC

826dx08jhcrk6

-- Kreiraj HTML report i spremi ga na disk
select DBMS_SQL_MONITOR.REPORT_SQL_MONITOR
        (sql_id       =>'7utw5pra4wn94',
         report_level =>'all', 
         type         =>'ACTIVE') report
from dual;