  SELECT
	a.SID "Blocking Session",
	b.SID "Blocked Session"
FROM
	v$lock a,
	v$lock b
WHERE
	a.SID != b.SID
	AND a.ID1 = b.ID1
	AND a.ID2 = b.ID2
	AND 
b.request > 0
	AND a.block = 1;
	

SELECT * FROM v$session_wait h WHERE h.sid = 3

SELECT sid,serial#,status,state,sql_id FROM v$session WHERE sid = 3