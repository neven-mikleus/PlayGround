with rws as (
  select 'DSA_BEVENT,DSA_CLIENT,DSA_CLIENT_CUSTOM,DSA_COLLATERAL' str from dual
), TABS AS
(
  select regexp_substr (
           str,
           '[^,]+',
           1,
           level
         ) TABLE_NAME
  from   rws
  connect by level <= 
    length ( str ) - length ( replace ( str, ',' ) ) + 1
)
SELECT 
 C.OWNER, C.TABLE_NAME,
        LISTAGG(COLUMN_NAME, ',') WITHIN GROUP (ORDER BY C.OWNER, C.TABLE_NAME, C.COLUMN_ID) COLS,
        rank() over(order by C.OWNER, C.TABLE_NAME) rnk,
        count(1) over() cnt,
        case 
            when rank() over(order by C.OWNER, C.TABLE_NAME) = count(1) over() then
                1
            else
                0
        end last_row 
 FROM all_tab_COLUMNS C JOIN TABS ON TABS.TABLE_NAME = C.TABLE_NAME
         WHERE     1 = 1
               AND C.OWNER = 'FV_DSA_PROD'  
GROUP BY C.OWNER, C.TABLE_NAME
  order by C.OWNER, C.TABLE_NAME;               

   



