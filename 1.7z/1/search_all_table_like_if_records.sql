 DECLARE
    l_cnt NUMBER;
 BEGIN
   for rec in (
   select 
       'select count(1) from '||owner||'.'||table_name||'  where rownum = 1' sq   
        from    all_tables a
       where 1=1 
       and    a.table_name like '%GENERAL_PROVISION_DET%'
   ) loop
   
  --dbms_output.put_line( rec.sq);    
  
    execute immediate rec.sq into l_cnt;
    if l_cnt > 0 then
        dbms_output.put_line( rec.sq); 
    end if;
    
   end loop;
 END;  
 