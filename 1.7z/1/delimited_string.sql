with
reg as (select '[^;]*;?' r, ';' del from   dual), 
dat as (select  ';;;1;22222;3;' s from dual)
select 
 level, 
 --regexp_count (dat.s, reg.r),
 replace(regexp_substr(dat.s, reg.r, 1, level),reg.del) val
from   dat cross join reg 
connect by level <= regexp_count(dat.s, reg.del) + 1;

with data as
(
select 
'Finevare load;078-50-9520607;2087993' text
from dual
)
select 
text,
regexp_substr(text, '(^|;)([^;]*)', 1, 1, null, 2)  as col1,
regexp_substr(text, '(^|;)([^;]*)', 1, 2, null, 2)  as col2,
regexp_substr(text, '(^|;)([^;]*)', 1, 3, null, 2)  as col3
from   data  


--
-- Postgres
--
SELECT 
(STRING_TO_ARRAY('Finevare load;078-50-9520607;2087993', ';'))[1] col1,
(STRING_TO_ARRAY('Finevare load;078-50-9520607;2087993', ';'))[2] col2,
(STRING_TO_ARRAY('Finevare load;078-50-9520607;2087993', ';'))[3] col3
   


--
-- Ovaj ne radi!!!!
--
with
reg as (select '[^|]*|?' r, '|' del from   dual), 
dat as (select  '|1|2|' s from dual)
select 
 level, 
 --regexp_count (dat.s, reg.r),
 replace(regexp_substr(dat.s, reg.r, 1, level), reg.del) val
from   dat cross join reg 
connect by level <= regexp_count(dat.s, reg.del) + 1;


--
-- Ovaj ne radi!!!!
--                      
with
reg as
(
select '([^|]*)(\||$)' r from   dual
)
, dat as
(
select  
'|52097731|47640351|2750876|RB071130|A.J. OBRT ZA TRGOVINU|1508777|5651||002-RBHR POS Terminal|||||||||20200723|Verifon VX675 WIFI-BT CTLS||Contactless||||||||Not Active|||||||ME_D_Blocked||P|RBHR_HYPERCOM|191|||24072020' s
from dual 
)
select level,regexp_substr (dat.s, reg.r,1, level,null,1) str
from dat cross join reg
connect by level <= regexp_count (dat.s, reg.r) ;


--
-- koimpliciranije i nepotrebno
--
with
reg as
(select '[^,]*,?' r from   dual), 
--
dat as
(select  ',,hello,,,world,,' s from dual)
--
select lvl, replace(regexp_substr(dat.s, reg.r, 1, lvl), ',') val
    from dat 
         cross join reg
         cross apply (select level lvl
                        from dual
                      connect by level <= regexp_count(dat.s, ',') + 1)


