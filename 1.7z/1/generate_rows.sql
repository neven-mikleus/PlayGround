 SELECT LEVEL , 
        date'2023-10-01'-1 + level -- po�etni datum
         FROM   dual
         CONNECT BY LEVEL <= 30
order by 2 

--recursive
WITH data (r)
     AS (SELECT 1 r FROM DUAL
         UNION ALL
         SELECT r + 1
           FROM data
          WHERE r < 10)
SELECT r
  FROM data