--
-- Skripta idem po zadanim tablicam i tipovima kolona i traži da li se u kolino nalazi stringa
-- za matchece se ispusuje ime tablice i kolone te broj matchava
--
DECLARE
    -- Upiši stringu koju tražiš
    l_string      VARCHAR2 (2000) := '%AllocationB%';
    
    
    match_count   INTEGER;
    v_sql  VARCHAR2 (2000) ;
BEGIN
   FOR t
      IN (SELECT owner, table_name, column_name
            FROM all_tab_columns
           WHERE     (
                        data_type LIKE '%CHAR%' 
                      or data_type = 'NCLOB'
                     )
                 --AND table_name IN ('BCK_NMI_20211022_SUBLEDGER_PARAMS_IMPAIRMENT2')
                 and owner = 'XMETA'
                 and table_name like 'DA%'
                 )
   LOOP
      v_sql := 'SELECT COUNT(*) FROM '|| t.owner|| '.'|| t.table_name
         || ' WHERE ('|| t.column_name|| ') LIKE :1 and rownum = 1';
        
      --DBMS_OUTPUT.put_line (v_sql);
      EXECUTE IMMEDIATE      v_sql          INTO match_count         USING l_string;

      IF match_count > 0
      THEN
         DBMS_OUTPUT.put_line (
            t.owner||'.'||t.table_name || '   -    ' || t.column_name || '  ---> ' || match_count||' '||v_sql);
      END IF;
   END LOOP;
END;

