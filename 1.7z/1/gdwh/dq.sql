--
-- Gre�ke po tablicama
--
SELECT a.*
FROM GROUPDWH.DQ_EVENT_LOG A
 WHERE  1=1
  and   A.TABLE_NAME  LIKE   '%CP_HOLISTIC%'  
  --AND A.BUS_DATE_FROM >= DATE '2024-03-01'
  --and A.LOAD_BATCH_NUMBER = 56188  
  --and A.ORIGINAL_VALUE is not null
  --and A.ORIGINAL_VALUE  like '%044-55-090487%'
  --and DQ_EVENT_UNID >= 3339929479
  --and A.ORIGINAL_VALUE not like '%FAC%'
  --and A.ORIGINAL_VALUE not like '%SDR%' 
  --and A.ORIGINAL_VALUE  != 'FAC9999/9999/0001c*FAC*RBHRCBS*RBHR'
  and  A.TIMESTAMP_EVENT >= trunc(sysdate)-1
  --AND A.BUS_DATE_FROM >= DATE '2024-08-31'

  
  --AND A.DQ_EVENT_UNID IN (  )
  order by A.TIMESTAMP_EVENT desc
  
select * from   DWHST.DQ_INCOME_EXPENSE_POSTINGS_56204 a
where A.VALUE_DATE = date'2023-11-30' 


  
  
  select *
  from GROUPDWH.DQ_EVENT_LOG A
  where A.TIMESTAMP_EVENT >= trunc(sysdate)-5
  AND a.TABLE_NAME =  'ST_CP_HOLISTIC'
  AND a.COLUMN_NAME  = 'ON_BALANCE_INDICATOR'
  
  SELECT *   from GROUPDWH.DQ_EVENT_LOG A
  
  select  trunc(sysdate)-5 from dual;
  
  LKPD_ACCOUNT
LKPD_ACCOUNT


SELECT 
A.COUNTERPARTY_INDICATOR
,A.STATUS_INDICATOR
,A.
FROM   DWHCO.TB0_CONTRACT A
WHERE 1=1 AND   A.CONTRACT_ID = '044-55-090487'
AND DATE'2023-11-30' BETWEEN BUS_DATE_FROM AND BUS_DATE_UNTIL  


GL_ACCOUNT_ID*GL_ACCOUNT_APPLICATION_ID*GL_ACCOUNT_SOURCE_SYSTEM_ID*GL_ACCOUNT_ENTITY_ID

CONTRACT_TRANSACTION_SCR

select * from   all_objects a
where A.OBJECT_NAME like '%CONTRACTTR%'
AND OWNER NOT IN ('SYS','SYSTEM','PUBLIC')
AND A.OBJECT_TYPE LIKE '%PACKAGE%'

GDWH_DYNSQL.VAP_STCONTRACTTRANSACTION


select * from   DWHST.DQ_INCOME_EXPENSE_POSTINGS_56204 a
where A.VALUE_DATE = date'2023-11-30' 
  
  
  SELECT DISTINCT A.*
  FROM GROUPDWH.DQ_REJECT_ROW a  
 WHERE  1=1
       AND a.table_name like ('%GENERAL_PROVISION%')
       and (TIMESTAMP_REJECTED) >= trunc(SYSTIMESTAMP)-1
       order by A.TIMESTAMP_REJECTED DESC
       
       
       select 
       trunc(SYSTIMESTAMP)-1
       from dual;
       

              
       --privrmeeni ti je u batch number:
       
       select * 
       from  DWHST.DQ_INCOME_EXPENSE_POSTINGS_56188 a
     where 1=1 and  A.VALUE_DATE != date'2023-11-30'
     
     
      select A.CONTRACT_ID,A.COUNTERPARTY_INDICATOR,A.CONTRACT_ENTITY_ID,A.CATEGORY_SOURCE_SYSTEM_ID,A.QUALITY_INDICATOR,A.*      
       from  DWHST.DQ_CONTRACT_TRANSACTION_56188 a
     where 1=1 and  A.VALUE_DATE = date'2023-11-30'
     
  
  
SELECT M.QUALITY_INDICATOR,
       m.transaction_id,
       m.recovery_type,
       m.DRAWING_INDICATOR,
       m.PREPAYMENT_INDICATOR,
       M.GROUP_FEE_TYPE,
       m.*
  FROM DWHRBA_MC.DQ_ST_CONTRACT_TRANSACTION m
 WHERE batch_number = 55118 AND unid = 249655062  
 
 
      SELECT M.*
  FROM DWHRBA_MC.DQ_ST_INCOME_EXPENSE_POSTINGS m
 WHERE batch_number = 56188
 -- AND unid = 249655062 
  
  
  
  select * from all_tables a where A.TABLE_NAME like 'L%_COUNTERPARTY'
  
  select 
  A.COUNTERPARTY_INDICATOR,A.ENTITY_ID,A.SOURCE_SYSTEM_ID
   from DWHCO.TB0_COUNTERPARTY a
  where 1=1 and A.COUNTERPARTY_ID = '044-55-090487' 
  
  and date'2022-11-30'  between bus_date_from and bus_date_until      
  
  select * from LGKM_COUNTERPARTY
  
  
  select * from DWHVA.LKPD_COUNTERPARTY a
  where 1=1 and A.COUNTERPARTY_ID = '044-55-090487'
  
    select * from DWHVA.LKPD_CONTRACT a
  where 1=1 and A.COUNTERPARTY_ID = '044-55-090487'
  
  select * from DWHVA.LKPD_CONTRACT a
  where 1=1 and A.CONTRACT_ID = '044-55-090487'
  AND DATE'2023-11-30' BETWEEN BUS_DATE_FROM AND BUS_DATE_UNTIL   
  
  DWHVA.LKP_CONTRACT
  
  
  SELECT * FROM DWHVA.LKPD
  
  --and COUNTERPARTY_INDICATOR = 'A'
  
  and APPLICATION_ID = 'KRD'
  
  and 

--
-- Odba�eni reci po tablici za datum
--  
SELECT A.*
  FROM GROUPDWH.DQ_REJECT_ROW a
 WHERE     a.schema_name = 'DWHST'
       AND a.table_name = 'ST_ACCOUNT_BALANCE'
       AND bus_date_from = DATE '2021-08-29'
       AND row_unid IN (1489643597, 1489643598, 1489643599)
 
 
SELECT *
  FROM GROUPDWH.DQ_EVENT_LOG A
 WHERE     A.TABLE_NAME = 'ST_CONTRACT_TRANSACTION'
       AND A.BUS_DATE_FROM >= DATE '2021-06-30'
       AND TRUNC (TIMESTAMP_EVENT) >= DATE '2021-08-01'       

 --
 -- QUALITY INDICATOR:
 --
 SELECT TRIM (LEADING 0 FROM LISTAGG (BIN, '') WITHIN GROUP (ORDER BY N DESC))
  FROM (SELECT N, DECODE (BITAND (6039, N), N, '1', '0') BIN
          FROM (SELECT 1 N FROM DUAL
                UNION ALL
                    SELECT POWER (2, LEVEL) N
                      FROM DUAL
                CONNECT BY LEVEL <= 15));
                
                
                