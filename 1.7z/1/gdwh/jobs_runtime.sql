----------------------------------------------------------------------------------------------------------------------
-- DWH Load - provjera
-- Provjera izvršavanja današnjeg ETL loada
-- Formirana je lista JOB_GROUPa prema statistici od mjesec dana, poredana po TONI-DALIBOR algoritmu
-- Provjerava se da li se pojedina grupa danas izvrtila, koji je status
-- Ako se izvrti neka grupa koju nismo imali na popisu, detektirat ćemo ju
----------------------------------------------------------------------------------------------------------------------
with jb_grp as (
  select  1 id, 'L02L1-L02L1' job_group, 'DAILY' freq, 'PRESTAGE' phase from dual union all
  select  2, 'STAGE_CONVERTER-STAGE_CONVERTER', 'DAILY', 'PRESTAGE' from dual union all
  select  3, 'PRESTAGE_LOADER-PRESTAGE_LOADER_LEASING', 'DAILY', 'PRESTAGE' from dual union all
  select  4, 'PRESTAGE2STAGE-PRESTAGE2STAGE_SIMPLE', 'DAILY', 'STAGE' from dual union all
  select  5, 'GDWH_CORE-CORE_DAILY', 'DAILY', 'CORE_LOAD' from dual union all
  select  6, 'TIGER30-TIGER30_SOURCE_TO_CORE', 'DAILY', 'POST_CORE_LOAD' from dual union all
  select  7, 'GDWH2ESIF-GDWH2ESIF_FULL', 'DAILY', 'POST_CORE_LOAD' from dual union all
  select  8, 'SMB-SMB', 'MONTHLY', 'POST_CORE_LOAD' from dual union all
  select  9, 'SUBLEDGER', 'MONTHLY', 'POST_CORE_LOAD' from dual union all
  select 10, 'AML30-AML_LOAD', 'DAILY', 'POST_CORE_LOAD' from dual union all
  select 11, 'G2R-G2R', 'DAILY', 'POST_CORE_LOAD' from dual union all
  select 12, 'GDWH2GEM-GDWH2GEM', 'DAILY', 'POST_CORE_LOAD' from dual union all
  select 13, 'AML2GDWH-AML2GDWH_DAILY', 'MONTHLY', 'POST_CORE_LOAD' from dual union all
  select 14, 'AML30-AML_FILE_OUT', 'DAILY', 'POST_CORE_LOAD' from dual union all
  select 15, 'STAGE_CONVERTER-STAGE_CONVERTER_BV', 'MONTHLY', 'POST_CORE_LOAD' from dual union all
  select 16, 'OFSA-OFSA', 'MONTHLY', 'POST_CORE_LOAD' from dual union all
  select 17, 'CORE_D1', 'MONTHLY', 'POST_CORE_LOAD' from dual union all
  select 18, 'IREG-IREG', 'MONTHLY', 'POST_CORE_LOAD' from dual
),
one_day as (
  select
    to_char(regexp_substr(STARTUP_VARIABLES, 'PRM_JC_JOBGROUP_ID=(.*)',1,1,'i',1))
    as job_group,             -- 0            -- 0
    scen_Task_no,
    trunc(task_beg) job_Date,
    stl.SESS_NO,              -- 1
    ss.SCEN_NAME,             -- 2
    stl.TASK_BEG,             -- 3 
    stl.TASK_END,             -- 4
    to_timestamp(stl.TASK_END) - to_timestamp(stl.TASK_BEG)
    as task_dur_diff,         -- 5
    stl.TASK_DUR,             -- 6
    ss.CONTEXT_CODE,          -- 7
    ss.sess_status,           -- 8
    ss.error_message          -- 9
  from SNP_SESSION ss
  join SNP_SESS_TASK_LOG  stl
    on ss.SESS_NO = stl.sess_no
  where 17=17
    --and stl.TASK_beg >= TRUNC(SYSDATE-3)
    --and stl.TASK_beg < TRUNC(SYSDATE-2)
    and stl.TASK_beg >= TRUNC(SYSDATE)
    and scen_name = 'OJC'
    and scen_Task_no = 5 -- na zadnjem koraku vidimo dužinu trajanja
  order by SESS_NAME, task_beg, scen_task_no
)
select
  jb_grp.id,
  coalesce(jb_grp.job_group, one_day.job_group) job_group,
  jb_grp.freq,
  jb_grp.phase,
  one_day.job_date,
  one_day.SESS_NO,
  one_day.task_beg,
  one_day.task_end,
  one_day.task_dur_diff,
  one_day.task_dur task_dur_sec,
  one_day.context_code,
  case
    when sess_status = 'E' then 'ERROR'
    when one_day.job_group is null and freq = 'DAILY' then 'NOK'
    when jb_grp.job_group is null then 'NEW_JOB_GROUP' 
    else 'OK' 
  end as chk_status,
  to_char(sysdate,'yyyy-mm-dd hh24:mi:ss') as chk_date,
  one_day.sess_status,
  one_day.error_message
  --and freq='DAILY' then 'NOK' else 'OK' end as status
from jb_grp
full join one_day
  on jb_grp.job_group = one_day.job_group
--where nvl(freq,'DAILY') = 'DAILY'
order by id, task_beg
;


select *
  from dwhrba.core_jobs
where 1=1 
AND naziv = 'HNB_MainSeq_FINISHED'
order by 3 desc, 1

select to_char(date'2024-11-03', 'DY'), to_char(date'2024-11-03' - 2,'yyyy-mm-dd') , 
           case when to_char(date'2024-11-03' - 2,'yyyy-mm-dd')  <> to_char(last_day(date'2024-11-03' - 2),'yyyy-mm-dd')  then 'KRENI' Else 'STOP' End As PROVJERA
from dual



select * from OJC.ODI_JC_RUNTIME_JOB r
WHERE started >= trunc(sysdate)
ORDER BY started desc

with dat as (select trunc(sysdate) dat from dual),
batch as
(   
SELECT * 
  FROM   OJC.ODI_JC_RUNTIME_BATCH B
    join dat ON  trunc(b.started) = dat
 where 1=1
 )  
 select * 
  from  batch b
        join  OJC.ODI_JC_RUNTIME_JOB j on J.BATCH_NUMBER = b.BATCH_NUMBER
        join OJC.ODI_JC_RUNTIME_TRACE t on T.BATCH_NUMBER =  J.BATCH_NUMBER and T.JOB_ID = J.JOB_ID and T.JOBGROUP_ID = J.JOBGROUP_ID
order by b.started        
        


with dat as (select trunc(sysdate)-1 dat from dual),
batch as
(   
SELECT * 
  FROM   OJC.ODI_JC_RUNTIME_BATCH B
    join dat ON  trunc(b.started) = dat
 WHERE 1=1
 ) 
 select * from  batch order by started DESC
 
 
 