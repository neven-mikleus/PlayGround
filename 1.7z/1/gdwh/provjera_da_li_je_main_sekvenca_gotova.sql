select * from DWHRBA.CORE_JOBS D ORDER BY DATUM_obrade DESC

select *
  from dwhrba.core_jobs
where 1=1 
AND naziv = 'HNB_MainSeq_FINISHED'
order by 3 desc, 1



select count(1),datum
from DWHRBA.CORE_JOBS D 
WHERE datum >= trunc(sysdate)-34--IN(date'2024-12-02',date'2024-12-01')
GROUP BY datum
ORDER BY datum


ORDER BY DATUM_obrade desc

SELECT
			DISTINCT 'START' FLAG_START
		FROM
			DWHRBA.CORE_JOBS D,
			DWHRBA.CORE_JOBS B
		WHERE
			1 = 1
			AND D.NAZIV LIKE '%HNB_MainSeq_FINISHED%'
			AND D.DATUM = TRUNC(SYSDATE) -1
			AND B.NAZIV LIKE 'S2C_D-1_FINISHED%'
			AND B.DATUM = TRUNC(SYSDATE) -1
			
			

SELECT
	FLAG_START
FROM
	(
	SELECT
		FLAG_START,
		ROW_NUMBER() OVER(ORDER BY 1 DESC) RN
	FROM
		(
		SELECT
			DISTINCT 'START' FLAG_START
		FROM
			DWHRBA.CORE_JOBS D,
			DWHRBA.CORE_JOBS B
		WHERE
			1 = 1
			AND D.NAZIV LIKE '%HNB_MainSeq_FINISHED%'
			AND D.DATUM = TRUNC(SYSDATE) -1
			AND B.NAZIV LIKE 'S2C_D-1_FINISHED%'
			AND B.DATUM = TRUNC(SYSDATE) -1
	UNION ALL
		SELECT
			'NO START'
		FROM
			DUAL
) A
)
WHERE
	1 = 1
	AND RN = 1