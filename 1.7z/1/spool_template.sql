set echo off
set feedback off
set linesize 1000
set pagesize 0
set sqlprompt ''
set trimspool on
set headsep off
set trim on
set wrap off

-- ime filea

spool c:\temp\output.csv

-- labele
select 'Patija;iznos;datum'  from dual union all
-- podaci
select '054-66698585-10'||';'||to_char(123.56,'999,999,999,999.00')||';'||to_char(date'2021-01-01','dd.mm.yyyy') from dual union all
select '054-8-10'||';'||to_char(123.12,'999,999,999,999.00')||';'||to_char(date'2021-12-01','dd.mm.yyyy') from dual union all
select '054-666554498585-67'||';'||to_char(999.56,'999,999,999,999.00')||';'||to_char(date'2021-01-12','dd.mm.yyyy') from dual  
;  

spool off

exit;