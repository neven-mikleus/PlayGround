with dat as
(
select  
CAST(to_date('03.12.2023 13:52:00','dd.mm.yyyy hh24:mi:ss') as timestamp) dt,
CAST(to_date('03.12.2023 13:31:00','dd.mm.yyyy hh24:mi:ss') as timestamp) df
from dual 
)
select 
dt,
df,
dt- df ddiff,
extract(hour from  dt- df) hours,
extract(minute from  dt- df) mins
 from   dat
