--
-- insert podatak asa jedne baze na drugu za jednu tablicu
--
SELECT 
' insert into '||owner||'.'||table_name||'('||LISTAGG(column_name, ', ')     WITHIN GROUP (ORDER BY column_id)||')' a
,'select '||LISTAGG(column_name, ', ')    WITHIN GROUP (ORDER BY column_id)||' from '||owner||'.'||table_name||'@gdwh30 a where a. BILLING_PHASEDATE =  '''||'2022-12-14'||''' '  b
,' and not exists(select 1 from '||owner||'.'||table_name||' b where  ' c
,LISTAGG('A.'||column_name||' = B.'||column_name, ' AND ') WITHIN GROUP (ORDER BY column_id)||' )'  d     
  FROM all_tab_columns a
 WHERE     1 = 1
       AND a.table_name = 'POS_TERMINALS'
       AND a.owner = 'DWHRBA'
group by owner     ,table_name  


--
-- Compare dvije tablice sa dviju baza
--

SELECT 
' (select '||LISTAGG(column_name, ', ')     WITHIN GROUP (ORDER BY column_id)||' from '||owner||'.'||table_name||'@gdwh30 a where date'''||'2022-03-14'||''' between a.Date_from and a.date_until   '  a
,' minus select '||LISTAGG(column_name, ', ')    WITHIN GROUP (ORDER BY column_id)||' from '||owner||'.'||table_name||' a where date'''||'2022-03-14'||''' between a.Date_from and a.date_until )'  b
,' union all ' c
,' (select '||LISTAGG(column_name, ', ')     WITHIN GROUP (ORDER BY column_id)||' from '||owner||'.'||table_name||' a where date'''||'2022-03-14'||''' between a.Date_from and a.date_until '  d
,' minus select '||LISTAGG(column_name, ', ')    WITHIN GROUP (ORDER BY column_id)||' from '||owner||'.'||table_name||'@gdwh30 a where date'''||'2022-03-14'||''' between a.Date_from and a.date_until )'  e  
  FROM all_tab_columns a
 WHERE     1 = 1
       AND a.table_name = 'POS_TERMINALS'
       AND a.owner = 'DWHRBA'
group by owner     ,table_name  


