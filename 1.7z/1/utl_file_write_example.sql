DECLARE
   l_date        DATE := DATE '2021-06-30';
   l_file        UTL_FILE.file_type;
   L_FILE_NAME   VARCHAR2 (200);
BEGIN
   WHILE l_date <= DATE '2021-06-30'
   LOOP
      L_FILE_NAME := 'TEST_export_' || TO_CHAR (l_date, 'yyyymmdd') || '.csv';
      
      l_file := UTL_FILE.fopen ('A_IRB'   , L_FILE_NAME   , 'w'  );

      FOR rec_c
         IN (SELECT    a.CLIENT_ID
                    || '|'
                    || a.UNIQUE_CAMP_CUST_ID
                    || '|'
                    || a.APPL_ID
                    || '|'
                       record
               FROM dwhrba.car360_INTERACTION a
              WHERE A.REPORTING_DATE = l_date
              fetch first 50 rows only
              )
      LOOP
         UTL_FILE.put_line (l_file, rec_c.record);
      END LOOP;


      UTL_FILE.fclose (l_file);

      l_date := ADD_MONTHS (l_date, 1);
   END LOOP;
END;
/