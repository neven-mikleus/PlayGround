DECLARE

   l_tab1 VARCHAR2(100) := 'TB0_CP_HOLISTIC_DETAIL';  -- <=== set the first table name that you want to compare
   l_tab2 VARCHAR2(100) := 'TB0_CP_HOLISTIC_DETAIL';                   -- <=== set the second table name that you want to compare
   
   l_tab1_schema VARCHAR2(100) := 'DWHCO'; 
   l_tab2_schema VARCHAR2(100)  := 'DWHCO';
   
   l_tab1_filter VARCHAR2(100) := 'REF_COUNTERP_ID = '016-50-8120727*PKR*RBHRCBS*RBHR'';
   l_tab2_filter VARCHAR2(100) := 'REF_COUNTERP_ID = '016-50-8120727*PKR*RBHRCBS*RBHR'';
   
   
   l_tab_columns VARCHAR2(4000) := 'CREDIT_SPREAD, ALLOCATION_BASIS, ID_CONTRACT_REFERENCE, ID_REFERENCE_RATE, ORIGINATION_DATE, MATURITY_DATE, LIMIT_EXPIRY_DATE, IAF_AMOUNT, FAIR_VALUE, DAYS_PAST_DUE, ID_DAY_COUNT_CONVENTION, INTEREST_RATE, INTEREST_REVENUE, INTEREST_RATE_TYPE, INTEREST_MARGIN_RATE, INTEREST_ACCRUAL, PRINCIPAL_GRANTED, OTHER_OUTSTANDING, OFFBALANCE_COND, OFFBALANCE_UNCOND';
   
   --l_key_columns VARCHAR2(100) := 'ID_EXPORT,ID_CONTRACT';
   l_key_columns VARCHAR2(100) := 'ID_CONTRACT';
   
   -----------------------------------------------------------------------------
   -- do not change after that
   -----------------------------------------------------------------------------
   
   L_SQL VARCHAR2(32767);   
   
   
   CURSOR C_TAB_COLS(p_OWNER  IN VARCHAR2, P_TABLE_NAME IN VARCHAR2,P_exclue IN VARCHAR2 DEFAULT NULL,p_include in varchar2 default null) IS 
   SELECT * 
   FROM ALL_TAB_COLUMNS C 
   WHERE C.TABLE_NAME = P_TABLE_NAME 
   AND  C.OWNER = P_OWNER 
   --AND C.COLUMN_NAME IN ('POS_ADDRESS','REGION_DESC')
   --AND C.COLUMN_NAME NOT IN ('DATE_FROM','DATE_UNTIL','GNUM','HISTORY_INDICATOR')
   --AND INSTR(P_INCLUDE, C.COLUMN_NAME ) > 0
   AND (P_INCLUDE IS NULL OR (P_INCLUDE IS NOT NULL AND INSTR(P_INCLUDE, C.COLUMN_NAME ) > 0))
   AND (P_EXCLUE  IS NULL OR (P_EXCLUE  IS NOT NULL AND INSTR(P_EXCLUE,  C.COLUMN_NAME ) = 0))
   ORDER BY C.COLUMN_ID
   ;
   
   FUNCTION F_TAB_COLS(P_OWNER IN VARCHAR2, P_TAB IN VARCHAR2) RETURN VARCHAR2 IS
        L_RET VARCHAR2(32767);
   BEGIN
    
         FOR R_TAB_COLS IN C_TAB_COLS( p_OWNER => P_OWNER, P_TABLE_NAME => P_TAB, P_exclue => l_key_columns ) LOOP
             L_RET := L_RET ||R_TAB_COLS.COLUMN_NAME||',' ;  
                
         END LOOP;
         L_RET := SUBSTR(L_RET,1,length(L_RET)-1);
         
         
       RETURN L_RET;
   END;
   
   FUNCTION F_COLS(P_COLS IN VARCHAR2,P_ALIAS IN VARCHAR2) RETURN VARCHAR2 IS
   BEGIN
        IF  P_COLS IS NOT NULL THEN       
            RETURN P_ALIAS||'.'||REPLACE(P_COLS,',',','||P_ALIAS||'.');
        ELSE
            RETURN '*';
        END IF;
   END;
   
   
   FUNCTION F_KEY_TRANS(P_TABS IN VARCHAR2,  P_KEY IN VARCHAR2,P_RET_TYPE IN VARCHAR2) RETURN VARCHAR2 AS
        L_TAB1  VARCHAR2(32767);
        L_TAB2  VARCHAR2(32767);
        L_RET VARCHAR2(32767);
    
    CURSOR C_COLS(P_LIST IN VARCHAR2) IS
     WITH
            REG AS (SELECT '[^,]*,?' R, ',' DEL FROM   DUAL), 
            DAT AS (SELECT  P_LIST S  FROM DUAL)
            SELECT 
             LEVEL, 
             --regexp_count (dat.s, reg.r),
             REPLACE(REGEXP_SUBSTR(DAT.S, REG.R, 1, LEVEL),REG.DEL) COLS
               FROM   DAT 
              CROSS JOIN REG 
            CONNECT BY LEVEL <= REGEXP_COUNT(DAT.S, REG.DEL) + 1;
BEGIN

    IF P_RET_TYPE = 'KEY' THEN
        L_RET := P_KEY;
    END IF;
    --
    --
    --
    IF P_RET_TYPE = 'KEY_QUOTES' THEN
        L_RET := ''''||REPLACE(P_KEY,',',''',''')||'''';
    END IF;        
    --
    --
    --
    IF P_RET_TYPE IN ('ON','CONCAT') THEN
        FOR REC IN C_COLS(P_TABS) LOOP              
                   IF REC.LEVEL = 1 THEN
                    L_TAB1 := REC.COLS;
                   ELSE
                    L_TAB2 := REC.COLS;
                   END IF;                   
                   --L_RET := L_RET||REC.TABS||'.'||REC.COLS||' = ';
                   --L_RET := L_RET||REC.COLS||' = ';                             
        END LOOP;
        
        IF P_RET_TYPE = 'ON' THEN
            FOR REC IN C_COLS(P_KEY) LOOP
                L_RET := L_RET||L_TAB1||'.'||REC.COLS||' = '||L_TAB2||'.'||REC.COLS||' AND ';
            END LOOP;
        ELSIF P_RET_TYPE = 'CONCAT' THEN
            FOR REC IN C_COLS(P_KEY) LOOP
                L_RET := L_RET||L_TAB1||'.'||REC.COLS||' ||''-''|| ';
            END LOOP;
        END IF;
    END IF;
    
    IF P_RET_TYPE = 'KEY' THEN
            L_RET := SUBSTR(L_RET,1,LENGTH(L_RET)-3);
    ELSIF P_RET_TYPE = 'ON' THEN
            L_RET := SUBSTR(L_RET,1,LENGTH(L_RET)-5);
    ELSIF P_RET_TYPE = 'CONCAT' THEN
            L_RET := SUBSTR(L_RET,1,LENGTH(L_RET)-9);
    END IF;
    
    RETURN L_rET;
END;
   
BEGIN

   
   
    L_SQL :=  L_SQL ||  
   ' SELECT * FROM   (
    WITH '; 
        
    L_SQL := L_SQL ||    
    'T1 AS
        (
        SELECT  '||F_COLS(P_COLS =>F_TAB_COLS(l_tab1_schema,l_tab1),P_ALIAS => 'aaa')||','||F_COLS(P_COLS =>L_KEY_COLUMNS,P_ALIAS => 'aaa')||'
          FROM '||l_tab1_schema||'.'||l_tab1||' '||'aaa'||'               
         WHERE '||NVL(l_tab1_filter,'1=1')||'
        ), 
        --
        --
        --
        T2 AS
        (
        SELECT '||F_COLS(P_COLS =>F_TAB_COLS(l_tab2_schema,l_tab2),P_ALIAS => 'aaa')||','||F_COLS(P_COLS =>L_KEY_COLUMNS,P_ALIAS => 'aaa')||'
         FROM '||l_tab2_schema||'.'||l_tab2||' '||'aaa'||'  
         WHERE '||NVL(l_tab2_filter,'1=1')||'
        ),
        --
        --
        --
         cols as
            (
            SELECT * 
               FROM ALL_TAB_COLUMNS C 
               WHERE C.TABLE_NAME = '''||l_tab1||''' 
               and  C.OWNER = '''||l_tab1_schema||'''
               --AND C.COLUMN_NAME IN (''POS_ADDRESS'',''REGION_DESC'') 
               AND C.COLUMN_NAME NOT IN (''DATE_FROM'',''DATE_UNTIL'',''GNUM'',''HISTORY_INDICATOR'')
               --AND C.COLUMN_NAME NOT IN ('||F_KEY_TRANS(l_tab1,l_key_columns,'KEY_QUOTES')||')
               AND C.COLUMN_NAME IN ('||F_KEY_TRANS(l_tab1,F_TAB_COLS(l_tab1_schema,l_tab1),'KEY_QUOTES')||')
               ORDER BY C.COLUMN_ID
               --SELECT * FROM DWHRBA.TMP_CDC_TAB_COLUMNS_'||l_tab1||'''
            ),COL_VALS AS
            (
             --
             --
             --
             select
             '''||L_TAB1||''' AS TABLE_NAME1,
             '''||L_TAB2||''' AS TABLE_NAME2,
             '''||l_key_columns||''' AS TABLE_KEY,'             
             ||F_KEY_TRANS('T1,'||'T1', l_key_columns, 'CONCAT')||' AS KEY_VALUE, '||'             
             cols.column_name as column_name,
         CASE ' ;
        
         FOR R_TAB_COLS IN C_TAB_COLS( P_OWNER=>L_TAB1_SCHEMA, P_TABLE_NAME => L_TAB1, P_EXCLUE =>L_KEY_COLUMNS, P_INCLUDE => L_TAB_COLUMNS ) LOOP
             L_SQL := L_SQL ||'
             WHEN  cols.column_name =  '''||R_TAB_COLS.COLUMN_NAME||''' THEN       TO_CHAR(T1.'||R_TAB_COLS.COLUMN_NAME||')' ;     
         END LOOP;
         L_SQL := L_SQL ||' END TABLE1_VALUE, 
         CASE ';         
         
         FOR R_TAB_COLS IN C_TAB_COLS( p_OWNER=>l_tab2_schema, P_TABLE_NAME => l_tab2, P_exclue => l_key_columns, P_INCLUDE => L_TAB_COLUMNS) LOOP
             L_SQL := L_SQL ||'
             WHEN  cols.column_name ='''||R_TAB_COLS.COLUMN_NAME||''' THEN       TO_CHAR(T2.'||R_TAB_COLS.COLUMN_NAME||')' ;     
         END LOOP;
         
         L_SQL := L_SQL ||' END TABLE2_VALUE';                       
         L_SQL := L_SQL ||chr(10)||
         ' FROM T1 
              FULL OUTER JOIN T2 ON  '||F_KEY_TRANS('T1,T2',L_KEY_COLUMNS,'ON' )||'
              CROSS JOIN COLS
            )
            SELECT * 
              FROM COL_VALS 
             WHERE
                 COL_VALS.TABLE1_VALUE is null and COL_VALS.TABLE2_VALUE is not null
             or  COL_VALS.TABLE1_VALUE is not null and COL_VALS.TABLE2_VALUE is null
             or  COL_VALS.TABLE1_VALUE != COL_VALS.TABLE2_VALUE
             ORDER BY 1,2,3';       
         L_SQL := L_SQL ||') union all ';
 
   
  L_SQL := substr(L_SQL,1, length(l_sql) - length('union all ')); 
  DBMS_OUTPUT.PUT_LINE(L_SQL );
 -- DBMS_OUTPUT.PUT_LINE(length(l_sql)||' - '||(length(l_sql) - 2000 ));
  --DBMS_OUTPUT.PUT_LINE(substr(L_SQL,length(l_sql)-9) );   
  
END;