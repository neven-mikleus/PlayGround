with dat
as
(
select '1' customer_id, date'2023-01-01' bus_date_from, date'2023-01-31'    bus_date_until, 'A' status_indicator  from   dual union all
select '1' customer_id, date'2023-02-01' bus_date_from, date'2023-02-28'    bus_date_until, 'C' status_indicator  from   dual union all
select '1' customer_id, date'2023-05-01' bus_date_from, date'2023-05-02'    bus_date_until, 'A' status_indicator  from   dual union all
select '1' customer_id, date'2023-05-03' bus_date_from, date'2023-05-30'    bus_date_until, 'A' status_indicator  from   dual union all
select '1' customer_id, date'2023-06-01' bus_date_from, date'2023-06-30'    bus_date_until, 'C' status_indicator  from   dual union all
select '1' customer_id, date'2023-07-01' bus_date_from, date'2023-07-31'    bus_date_until, 'C' status_indicator  from   dual union all
select '1' customer_id, date'2023-08-01' bus_date_from, date'2023-08-30'    bus_date_until, 'A' status_indicator  from   dual union all
select '1' customer_id, date'2023-09-01' bus_date_from, date'2023-10-30'    bus_date_until, 'A' status_indicator  from   dual union all
select '1' customer_id, date'2023-11-01' bus_date_from, date'2023-12-01'    bus_date_until, 'A' status_indicator  from   dual unIon alL
select '1' customer_id, date'2023-12-02' bus_date_from, date'9999-12-31'    bus_date_until, 'A' status_indicator  from   dual 
)
SELECT  
customer_id,
bus_date_from,
bus_date_until,
status_indicator,
CASE WHEN status_indicator != lag (status_indicator) OVER (PARTITION BY customer_id order by bus_date_from) AND status_indicator = 'A' THEN
    --'RAZ'
    MIN(bus_date_from) OVER (PARTITION BY customer_id,status_indicator order by bus_date_from range between 1 preceding AND 1 following) 
ELSE
    NULL --'IST'
END MIN_DATE
from   dat 
order by bus_date_from