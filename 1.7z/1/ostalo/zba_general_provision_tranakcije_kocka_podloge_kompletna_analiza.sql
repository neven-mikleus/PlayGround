--
-- OdgovaraUzorkuHNB('HNB_SDRPARAMS_Hash','P5','DA',PassOn.Konto) - ispravak potrazivanja       - 50__19%
-- OdgovaraUzorkuHNB('HNB_SDRPARAMS_Hash','P6','DA',PassOn.Konto) - ispravak kamata             - 12~5_090 ; 12~5_19% ;  12~5_90 ; 12~5_091
-- OdgovaraUzorkuHNB('HNB_SDRPARAMS_Hash','P8','DA',PassOn.Konto) - ispravak vanbilance         - 280__0%
-- OdgovaraUzorkuHNB('HNB_SDRPARAMS_Hash','P9','DA',PassOn.Konto) - ispravak naknada            - 135__9%
--                                                                - naknade                     - 135__~9% ; 125__~9%
-- 


WITH 
--
--
--
dat AS (SELECT DATE '2023-06-30' d FROM DUAL)
--
--
--
,cus as
(
select C.CUSTOMER_ID
 from   DWHCO.TB0_CUSTOMER c
cross join dat
where C.CUSTOMER_ID in 
( 
'69218'
)
and dat.d between bus_date_from and bus_date_until 
)
,par as(
select a.counterparty_id,a.customer_id
 from  DWHCO.TB0_COUNTERPARTY a
cross join dat
where a.counterparty_id in( 
'044-55-982264'
)
and dat.d between bus_date_from and bus_date_until 
)
, cat_p5 as
--
-- ispravak potrazivanja       - 50__19%
--
(
sELECT CATEGORY_ID, A.CATEGORY_DESCRIPTION
           FROM DWHCO.TB0_CATEGORY a
           CROSS JOIN dat
          WHERE     1 = 1
                AND A.CATEGORY_ID like '50__19%'
                AND dat.d BETWEEN bus_date_from AND bus_date_until
)
, cat_p6 as
--
-- ispravak kamata             - 12~5_090 ; 12~5_19% ;  12~5_90 ; 12~5_091
--
(
sELECT CATEGORY_ID, A.CATEGORY_DESCRIPTION
           FROM DWHCO.TB0_CATEGORY a
           CROSS JOIN dat
          WHERE     1 = 1
                AND 
                (
                    (A.CATEGORY_ID like '12~5_19%')
                    or
                    (a.CATEGORY_ID like '12~5_090' and substr(a.CATEGORY_ID,5) != '5')
                    or
                    (a.CATEGORY_ID like '12~5_19%' and substr(a.CATEGORY_ID,5) != '5')
                    or
                    (a.CATEGORY_ID like '12~5_90' and substr(a.CATEGORY_ID,5) != '5')
                    or
                    (a.CATEGORY_ID like '12~5_091' and substr(a.CATEGORY_ID,5) != '5')
                )                
                AND dat.d BETWEEN bus_date_from AND bus_date_until
), cat_p8 as
--
-- - ispravak vanbilance         - 280__0%
--
(
sELECT CATEGORY_ID, A.CATEGORY_DESCRIPTION
           FROM DWHCO.TB0_CATEGORY a
                CROSS JOIN dat
          WHERE     1 = 1
                AND A.CATEGORY_ID like '280__0%'
                AND dat.d BETWEEN bus_date_from AND bus_date_until
)
, cat_p9 as
--
-- - ispravak naknada            - 135__9%
--
(
sELECT CATEGORY_ID, A.CATEGORY_DESCRIPTION
           FROM DWHCO.TB0_CATEGORY a
                CROSS JOIN dat
          WHERE     1 = 1
                AND A.CATEGORY_ID like '135__9%'
                AND dat.d BETWEEN bus_date_from AND bus_date_until
)
--
--
--
,cat_A0218
     AS (SELECT CATEGORY_ID, A.CATEGORY_DESCRIPTION
           FROM DWHCO.TB0_CATEGORY a
           CROSS JOIN dat
          WHERE     1 = 1
                AND A.CATEGORY_ID IN (
                '5001390','5001391','5001397','5040390','5040391','5040397','5041390','5041391','5041397','5043390','5043397','5096390'
,'5096397','5098397','5080013','5080143','5080213','5080303','5080403','5080413','5080433','5080953','5080963'
,'5080973','5080983','1280013','1280143','1280303','1280403','1280413','1280433','1280963','1280983')
                AND dat.d BETWEEN bus_date_from
                                          AND bus_date_until)
     --
     --
     --
     ,cat_A0220
     AS (SELECT CATEGORY_ID, A.CATEGORY_DESCRIPTION
           FROM DWHCO.TB0_CATEGORY a
            CROSS JOIN dat
          WHERE     1 = 1
                AND A.CATEGORY_ID IN ('500119','503019','504119','5001190','5001191','5001197','5030197','5041190','5041191','5041197','5040590','5040591','5043590','5040592',
                                      '5040597','5040598','5043591','5043597','5043598','5096590','5096591','5096597','5098598','5098591','5098597','5080011','5080141','5080221',
                                      '5080301','5080405','5080411','5080435','5080951','5080965','5080971','5080985','5280921','1280011','1280401','1280411','1280431','1280961',
                                      '1280981')
                AND dat.d BETWEEN bus_date_from
                                          AND bus_date_until)
     --
     --
     --
     ,cat_A0224
     AS (SELECT CATEGORY_ID, A.CATEGORY_DESCRIPTION
           FROM DWHCO.TB0_CATEGORY a
            CROSS JOIN dat
          WHERE     1 = 1
                AND A.CATEGORY_ID IN ('5001090','5001091')--????? zo nije sve
                AND dat.d BETWEEN bus_date_from
                                          AND bus_date_until)
     --
     --
     --
     ,cat_p10 -- naknade
      as (
      SELECT CATEGORY_ID, A.CATEGORY_DESCRIPTION
           FROM DWHCO.TB0_CATEGORY a
            CROSS JOIN dat
          WHERE     1 = 1               
                AND dat.d BETWEEN bus_date_from
                                          AND bus_date_until                                          
           and substr(a.CATEGORY_id,6,1) !='9'
           and (a.CATEGORY_id like '125__%' or a.CATEGORY_id like '135__%')
      )
      --
      -- Ovdje mijenja� sva konta 
      --
      ,cat as
      (
      --select CATEGORY_ID from  cat_A0224
      select '5001091' CATEGORY_ID from  dual
      )
     ,gp as
     (
       SELECT GPD.CUSTOMER_ID, SUM (GPA.PROVISION_AMOUNT_LCY) PROVISION_AMOUNT_LCY,
       LISTAGG(distinct GPD.COUNTERPARTY_ID, '; '   ON OVERFLOW TRUNCATE '...' WITHOUT COUNT) WITHIN GROUP (ORDER BY GPD.CUSTOMER_ID) COUNTERPARTY_ID_idS
        -- gpa.*
        FROM DWHCO.TB0_GENERAL_PROVISION_DETAILS gpd
             JOIN DWHCO.TB0_GENERAL_PROVISION_AMOUNT gpa
                ON gpd.unid = gpa.provision_unid
             CROSS JOIN dat
       WHERE     gpa.effective_date = dat.d
             AND dat.d BETWEEN gpd.bus_date_from AND gpd.bus_date_until
             and   GPD.COUNTERPARTY_Id in (select par.counterparty_id from par )
             and GPD.ACCOUNTING_INDICATOR = 'L'
    GROUP BY GPD.CUSTOMER_ID
     ),
     trans
     AS (SELECT TRANS.*,
                --SUM(CRED_DEBIT_AMOUNT) OVER () sum_CRED_DEBIT_AMOUNT,
                SUM (
                     CASE
                        WHEN TRANS.debit_credit_indicator = 'C' THEN 1
                        ELSE -1
                     END
                   * TRANS.transaction_amount)
                OVER (PARTITION BY TRANS.customer_id)
                   sum_transaction_amount_BY_CUSTOMER,
                SUM (
                     CASE
                        WHEN TRANS.debit_credit_indicator = 'C' THEN 1
                        ELSE -1
                     END
                   * TRANS.transaction_amount)
                OVER (PARTITION BY TRANS.customer_id, TRANS.CATEGORY_id)
                   sum_transaction_amount_BY_CATEGORY,
                 --LISTAGG(distinct TRANS.partija, '; '   ON OVERFLOW TRUNCATE '...' WITHOUT COUNT) over (ORDER BY TRANS.CUSTOMER_ID) partija_idS
                 LISTAGG(TRANS.partija, '; ')        WITHIN GROUP (ORDER BY TRANS.CUSTOMER_ID) OVER (PARTITION BY TRANS.CUSTOMER_ID) partija_idS
           FROM (SELECT 'ACCOUNT_TRANSACTION' TRANS_GROUP,
                        c.ACCOUNT_id AS partija,
                        c.customer_id,
                        T.VALUE_DATE AS dat_val_gk,
                        T.POSTING_DATE AS dat_knj_gk,
                        t.transaction_amount AS transaction_amount,
                        t.debit_credit_indicator AS debit_credit_indicator,
                          CASE
                             WHEN t.debit_credit_indicator = 'C' THEN 1
                             ELSE -1
                          END
                        * t.transaction_amount
                           AS CRED_DEBIT_AMOUNT,
                        k.category_id AS konto--c.bus_date_from,c.bus_date_until
                        ,
                        c.application_id,
                        K.CATEGORY_ID,
                        t.unid
                   FROM dwhco.tb0_account c
                        INNER JOIN dwhco.tb0_account_transaction t
                           ON c.unid = t.account_unid
                        INNER JOIN dwhco.tb0_category k
                           ON t.category_unid = k.unid
                        CROSS JOIN dat
                  WHERE T.VALUE_DATE <= dat.d
                    --and k.category_id in (select cat_A0220.category_id from cat_A0220)
                    --and k.category_id in (select cat_p5.category_id from cat_p5)
                   -- and k.category_id in (select cat_p8.category_id from cat_p8)
                    and k.category_id in (select cat.category_id from cat)                    
                 UNION ALL
                 SELECT 'CONTRACT_TRANSACTION' TRANS_GROUP,
                        C.CONTRACT_ID AS partija,
                        c.customer_id,
                        T.VALUE_DATE AS dat_val_gk,
                        T.POSTING_DATE AS dat_knj_gk,
                        t.transaction_amount AS transaction_amount,
                        t.debit_credit_indicator AS debit_credit_indicator,
                          CASE
                             WHEN t.debit_credit_indicator = 'C' THEN 1
                             ELSE -1
                          END
                        * t.transaction_amount
                           AS CRED_DEBIT_AMOUNT,
                        k.category_id AS konto--c.bus_date_from,c.bus_date_until
                        ,
                        c.application_id,
                        K.CATEGORY_ID,
                        t.unid
                   FROM DWHCO.TB0_CONTRACT c
                        INNER JOIN DWHCO.TB0_CONTRACT_TRANSACTION T
                           ON C.UNID = T.CONTRACT_UNID
                        INNER JOIN dwhco.tb0_category k
                           ON t.category_unid = k.unid
                        CROSS JOIN dat
                  WHERE T.VALUE_DATE <= dat.d
                   --and k.category_id in (select cat_A0220.category_id from cat_A0220)
                   --and k.category_id in (select cat_p5.category_id from cat_p5)
                   --and k.category_id in (select cat_p8.category_id from cat_p8)
                    and k.category_id in (select cat.category_id from cat)
                ) TRANS
                where 1=1 
                 and   trans.partija in (select par.counterparty_id from par )
                ),
     table_podloga
     AS (  SELECT --a.partija ,
                  SUM (A.ISPRAVAK_POTR_AKT) ISPRAVAK_POTR_AKT,
                  SUM (A.ISPRAVAK_VANBILANCE) ISPRAVAK_VANBILANCE,                  
                  SUM (A.ISPRAVAK_JAVNOBILJ_TROSK_AKT) ISPRAVAK_JAVNOBILJ_TROSK_AKT, 
                  SUM (A.ISPRAVAK_KTA_AKT) ISPRAVAK_KTA_AKT, 
                  SUM (A.ISPRAVAK_KTA_NEDOSP_AKT) ISPRAVAK_KTA_NEDOSP_AKT, 
                  SUM (A.ISPRAVAK_NAKNADA) ISPRAVAK_NAKNADA, 
                  SUM (A.ISPRAVAK_ODVJ_TROSK_AKT) ISPRAVAK_ODVJ_TROSK_AKT, 
                  SUM (A.ISPRAVAK_POTR_PAS) ISPRAVAK_POTR_PAS, 
                  SUM (A.ISPRAVAK_PREMIJA_OSIG_AKT) ISPRAVAK_PREMIJA_OSIG_AKT, 
                  SUM (A.ISPRAVAK_SUDSKIH_TROSK_AKT) ISPRAVAK_SUDSKIH_TROSK_AKT,    
                  SUM (A.naknada) naknada,
                  SUM (A.troskovi) troskovi,
                  LISTAGG(distinct a.partija, '; '   ON OVERFLOW TRUNCATE '...' WITHOUT COUNT) WITHIN GROUP (ORDER BY p.CUSTOMER_ID) partija_idS,
                  p.customer_id
             FROM dwhhnb.HNB_ACCOUNT_BALANCES_TABLE a
                  JOIN DWHCO.TB0_COUNTERPARTY p
                     ON p.COUNTERPARTY_ID = a.partija
                  CROSS JOIN dat
            WHERE     1 = 1
                  AND A.DAT_VAL_GK <= dat.d
                  AND dat.d BETWEEN p.bus_date_from AND p.bus_date_until
                  and  a.partija in (select par.counterparty_id from par )
         GROUP BY p.customer_id                                    --a.partija
                               ),
     bal_podloga
     AS (  SELECT p.customer_id,
                  SUM (A.ISPRAVAK_POTR) ISPRAVAK_POTR,
                  SUM (A.ISPRAVAK_VANBILANCE) ISPRAVAK_VANBILANCE,
                  SUM (A.ISPRAVAK_JAVNOBILJ_TROSK) ISPRAVAK_JAVNOBILJ_TROSK, 
                  SUM (A.ISKLJ_KTA_DOSP) ISKLJ_KTA_DOSP, 
                  SUM (A.ISKLJ_KTA_NEDOSP) ISKLJ_KTA_NEDOSP, 
                  SUM (A.ISPRAVAK_NAKNADA) ISPRAVAK_NAKNADA, 
                  SUM (A.ISPRAVAK_ODVJ_TROSK) ISPRAVAK_ODVJ_TROSK,
                  SUM (A.ISPRAVAK_PREMIJA_OSIG) ISPRAVAK_PREMIJA_OSIG, 
                  SUM (A.ISPRAVAK_SUDSKIH_TROSK) ISPRAVAK_SUDSKIH_TROSK,                  
                  SUM (A.naknada) naknada,
                  SUM (A.troskovi) troskovi,
                  LISTAGG(distinct a.partija, '; '   ON OVERFLOW TRUNCATE '...' WITHOUT COUNT) WITHIN GROUP (ORDER BY p.CUSTOMER_ID) partija_idS
             FROM dwhhnb.HNB_ACCOUNT_BALANCES a
                  JOIN DWHCO.TB0_COUNTERPARTY p
                     ON  a.partija like p.COUNTERPARTY_ID||'%'
                  CROSS JOIN dat
            WHERE     1 = 1
                  --and  a.partija in('30059237381522-978-A','446736990522-978-A','655044376522-978-A','11054743522-978-A','105017448522-978-A')
                  and   p.counterparty_id in (select par.counterparty_id from par )
                  AND A.DAT_VAL_GK =dat.d
                  AND dat.d BETWEEN p.bus_date_from AND p.bus_date_until                  
         GROUP BY p.customer_id)
    , 
    --
    --
    --
    zba as
    (
        SELECT A.CUSTOMER_ID,
           SUM (A.CREDIT_AMOUNT_LCY - A.DEBIT_AMOUNT_LCY) AMOUNT,
           LISTAGG (DISTINCT CATEGORY_id, '; '  ON OVERFLOW TRUNCATE '...' WITHOUT COUNT) WITHIN GROUP (ORDER BY CUSTOMER_ID) CATEGORY_idS
        from   DWHRBA.TB0_ZBA_2023 a
               CROSS JOIN dat
        where   A.ZBA_VALUE_DATE <= dat.d
          --and CATEGORY_id in (select b.CATEGORY_id from   cat_A0220 b)
          --and a.category_id in (select cat_p5.category_id from cat_p5)
          --and a.category_id in (select cat_p8.category_id from cat_p8)
          and a.category_id in (select cat.category_id from cat)
        group by A.CUSTOMER_ID
    )
    select *   
/*   
 select 
    sum(ZBA_AMOUNT) ,
    sum(PROVISION_AMOUNT_LCY),
    sum(TRANSACTION_AMOUNT),
    sum(HNB_ACCOUNT_BALANCES_TABLE_ISPRAVAK_POTR_AKT),
    sum(HNB_ACCOUNT_BALANCES_TABLE_ISPRAVAK_VANBILANCE),
    sum(HNB_ACCOUNT_BALANCES_ISPRAVAK_POTR),
    sum(HNB_ACCOUNT_BALANCES_ISPRAVAK_VANBILANCE),
    --
    sum(HNB_ACCOUNT_BALANCES_ISPRAVAK_VANBILANCE),
    sum(HNB_ACCOUNT_BALANCES_ISPRAVAK_POTR),
    sum(HNB_ACCOUNT_BALANCES_ISPRAVAK_VANBILANCE)
    */
    --
    from   
    (
SELECT 
ZBA.CUSTOMER_ID                 CUSTOMER_ID,
ZBA.AMOUNT                      ZBA_AMOUNT,
ZBA.CATEGORY_IDS                ZBA_CATEGORY_IDS,
--
GP.PROVISION_AMOUNT_LCY         PROVISION_AMOUNT_LCY,
GP.COUNTERPARTY_ID_IDS          GP_COUNTERPARTY_ID_IDS,
--
TRA.AMOUNT                      TRANSACTION_AMOUNT,
TRA.PARTIJA_IDS                 PARTIJA_IDS,
--
P.ISPRAVAK_POTR_AKT                 TABLE_ISPRAVAK_POTR_AKT,
P.ISPRAVAK_VANBILANCE               TABLE_ISPRAVAK_VANBILANCE,
P.NAKNADA                           TABLE_NAKNADA,
P.PARTIJA_IDS                       TABLE_PARTIJA_IDS,
P.ISPRAVAK_JAVNOBILJ_TROSK_AKT      TABLE_ISPRAVAK_JAVNOBILJ_TROSK_AKT, 
P.ISPRAVAK_KTA_AKT                  TABLE_ISPRAVAK_KTA_AKT, 
P.ISPRAVAK_KTA_NEDOSP_AKT           TABLE_ISPRAVAK_KTA_NEDOSP_AKT, 
P.ISPRAVAK_NAKNADA                  TABLE_ISPRAVAK_NAKNADA, 
P.ISPRAVAK_ODVJ_TROSK_AKT           TABLE_ISPRAVAK_ODVJ_TROSK_AKT, 
P.ISPRAVAK_POTR_PAS                 TABLE_ISPRAVAK_POTR_PAS, 
P.ISPRAVAK_PREMIJA_OSIG_AKT         TABLE_ISPRAVAK_PREMIJA_OSIG_AKT, 
P.ISPRAVAK_SUDSKIH_TROSK_AKT        TABLE_ISPRAVAK_SUDSKIH_TROSK_AKT, 
--
B.ISPRAVAK_POTR                     BALANCES_ISPRAVAK_POTR,
B.ISPRAVAK_VANBILANCE               BALANCES_ISPRAVAK_VANBILANCE,
B.NAKNADA                           BALANCES_NAKNADA,
B.PARTIJA_IDS                       BALANCES_PARTIJA_IDS,
--
B.ISPRAVAK_JAVNOBILJ_TROSK       BALANCES_ISPRAVAK_JAVNOBILJ_TROSK, 
B.ISKLJ_KTA_DOSP                 BALANCES_ISKLJ_KTA_DOSP, 
B.ISKLJ_KTA_NEDOSP               BALANCES_ISKLJ_KTA_NEDOSP, 
B.ISPRAVAK_NAKNADA               BALANCES_ISPRAVAK_NAKNADA, 
B.ISPRAVAK_ODVJ_TROSK            BALANCES_ISPRAVAK_ODVJ_TROSK,
B.ISPRAVAK_PREMIJA_OSIG          BALANCES_ISPRAVAK_PREMIJA_OSIG, 
B.ISPRAVAK_SUDSKIH_TROSK         BALANCES_ISPRAVAK_SUDSKIH_TROSK
  FROM 
  zba
  left join gp on zba.CUSTOMER_ID = gp.CUSTOMER_ID
  left join (
         SELECT t.customer_id, SUM (CRED_DEBIT_AMOUNT) AMOUNt
                ,LISTAGG(distinct partija, '; '   ON OVERFLOW TRUNCATE '...' WITHOUT COUNT) WITHIN GROUP (ORDER BY t.CUSTOMER_ID) partija_idS
            FROM TRANS t
        GROUP BY t.customer_id) tra ON zba.CUSTOMER_ID = tra.CUSTOMER_ID
       left JOIN table_podloga p ON p.CUSTOMER_ID = zba.CUSTOMER_ID
       left JOIN bal_podloga b ON b.CUSTOMER_ID = zba.CUSTOMER_ID
 WHERE 1 = 1 
 AND zba.CUSTOMER_ID in (select cus.CUSTOMER_ID from cus) 
 )
 
 and
     (
         (
         (gp.PROVISION_AMOUNT_LCY is not null and zba.amount <> gp.PROVISION_AMOUNT_LCY) 
         or
         (
         gp.PROVISION_AMOUNT_LCY is  null
         and 
         (
              zba.amount <> a.amount
   --or zba.amount <> p.ISPRAVAK_POTR_AKT
   --or zba.amount <> b.ISPRAVAK_POTR
   --
   or zba.amount <> p.ISPRAVAK_VANBILANCE
   or zba.amount <> b.ISPRAVAK_VANBILANCE
         )       
        )
        )
   )  
 
   and 
   (
      zba.amount <> a.amount
   --or zba.amount <> p.ISPRAVAK_POTR_AKT
   --or zba.amount <> b.ISPRAVAK_POTR
   --
   or zba.amount <> p.ISPRAVAK_VANBILANCE
   or zba.amount <> b.ISPRAVAK_VANBILANCE
   )
  
 