select * from lng_zne_jra.dbo_cwd_user
where user_name ='hrabmf'