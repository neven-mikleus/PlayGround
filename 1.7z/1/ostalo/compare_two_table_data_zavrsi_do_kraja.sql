DECLARE

   
   L_SQL VARCHAR2(32767);
   
   CURSOR C_TABS IS
   SELECT * FROM( 
             SELECT 'DWHCO' AS OWNER, 'BCK_20240505_NMI_DSA_CONTRACT'              AS TAB, 'CON' AS ALIAS , 'ID_EXPORT,ID_CONTRACT' AS KEY, 'CREDIT_SPREAD,ALLOCATION_BASIS,ID_CONTRACT_REFERENCE,ID_REFERENCE_RATE,ORIGINATION_DATE,MATURITY_DATE,LIMIT_EXPIRY_DATE,IAF_AMOUNT,FAIR_VALUE,DAYS_PAST_DUE,ID_DAY_COUNT_CONVENTION,INTEREST_RATE,INTEREST_REVENUE,INTEREST_RATE_TYPE,INTEREST_MARGIN_RATE,INTEREST_ACCRUAL,PRINCIPAL_GRANTED,OTHER_OUTSTANDING,OFFBALANCE_COND,OFFBALANCE_UNCOND,INTEREST_UNDUE,INTEREST_OVERDUE,INTEREST_PENALTY,PRINCIPAL_UNDUE,PRINCIPAL_OVERDUE,ID_RISK_STATUS,ID_CONTRACT_STATUS,ID_CURRENCY,ID_BRANCH,ID_PRODUCT,ID_CLIENT,ID_AGREEMENT,ID_COMMITMENT,ID_CONTRACT,DATA_DATE,INITIAL_INTEREST,ERROR_RULE,BUSINESS_MODEL,IFRS_CATEGORY,IS_NO_MOD,RATING,EWS_VALUE,LTV,IS_TD,IS_DEFAULT,IS_FORBORNE,RATING_EXT,SUSPENDED_INTEREST' COLS FROM    DUAL --OK
   --union all SELECT 'FV_DSA_PROD' AS OWNER, 'DSA_CONTRACT'     AS TAB, 'OUT' AS ALIAS , 'DATABASE_ID_OF_CONTRACT' AS KEY, 'CONTRACT_NUMBER,ACCOUNT_NUMBER_IBAN,DATE_FROM,DATE_UNTIL' COLS FROM    DUAL --OK
   --union all SELECT 'DWHRBA' AS OWNER, 'POS_W4_MSE_TERMINAL_CONTRACT'   AS TAB, 'TER' AS ALIAS , 'DATABASE_ID_OF_CONTRACT' AS KEY, 'CONTRACT_NUMBER,DATE_FROM,DATE_UNTIL' COLS FROM    DUAL --ok
   --union all SELECT 'DWHRBA' AS OWNER, 'POS_W4_MSE_TARIFFS'             AS TAB, 'TAR' AS ALIAS , 'DATABASE_ID_OF_CONTRACT' AS KEY, 'TARIFF_ROLE,TARIFF_NAME,TARIFF_CODE_FROM,MINIMAL_AMOUNT,MAXIMAL_AMOUNT,FEE_BASE_VALUE,FEE_RATE_PERCENTAGE,TARIFF_DATE_FROM,DATE_FROM,DATE_UNTIL' COLS FROM    DUAL --OK
   )
   ORDER BY 1,2,3
   ;
   
   CURSOR C_TAB_COLS(p_OWNER  IN VARCHAR2, P_TABLE_NAME IN VARCHAR2,P_INCLUDE IN VARCHAR2 DEFAULT NULL) IS 
   SELECT * 
   FROM ALL_TAB_COLUMNS C 
   WHERE C.TABLE_NAME = P_TABLE_NAME 
   and  C.OWNER = p_OWNER 
   --AND C.COLUMN_NAME IN ('POS_ADDRESS','REGION_DESC')
   AND C.COLUMN_NAME NOT IN ('DATE_FROM','DATE_UNTIL','GNUM','HISTORY_INDICATOR')
   AND INSTR(P_INCLUDE, C.COLUMN_NAME ) > 0
   ORDER BY C.COLUMN_ID
   ;
   
   FUNCTION F_COLS(P_COLS IN VARCHAR2,P_ALIAS IN VARCHAR2) RETURN VARCHAR2 IS
   BEGIN
        IF  P_COLS IS NOT NULL THEN       
            RETURN P_ALIAS||'.'||REPLACE(P_COLS,',',','||P_ALIAS||'.');
        ELSE
            RETURN '*';
        END IF;
    END;
   
   
   FUNCTION F_KEY_TRANS(P_TABS IN VARCHAR2,  P_KEY IN VARCHAR2,P_RET_TYPE IN VARCHAR2) RETURN VARCHAR2 AS
        L_TAB1  VARCHAR2(32767);
        L_TAB2  VARCHAR2(32767);
        L_RET VARCHAR2(32767);
    
    CURSOR C_COLS(P_LIST IN VARCHAR2) IS
     WITH
            REG AS (SELECT '[^,]*,?' R, ',' DEL FROM   DUAL), 
            DAT AS (SELECT  P_LIST S  FROM DUAL)
            SELECT 
             LEVEL, 
             --regexp_count (dat.s, reg.r),
             REPLACE(REGEXP_SUBSTR(DAT.S, REG.R, 1, LEVEL),REG.DEL) COLS
               FROM   DAT 
              CROSS JOIN REG 
            CONNECT BY LEVEL <= REGEXP_COUNT(DAT.S, REG.DEL) + 1;
BEGIN

    IF P_RET_TYPE = 'KEY' THEN
        L_RET := P_KEY;
    END IF;
    --
    --
    --
    IF P_RET_TYPE = 'KEY_QUOTES' THEN
        L_RET := ''''||REPLACE(P_KEY,',',''',''')||'''';
    END IF;        
    --
    --
    --
    IF P_RET_TYPE IN ('ON','CONCAT') THEN
        FOR REC IN C_COLS(P_TABS) LOOP              
                   IF REC.LEVEL = 1 THEN
                    L_TAB1 := REC.COLS;
                   ELSE
                    L_TAB2 := REC.COLS;
                   END IF;                   
                   --L_RET := L_RET||REC.TABS||'.'||REC.COLS||' = ';
                   --L_RET := L_RET||REC.COLS||' = ';                             
        END LOOP;
        
        IF P_RET_TYPE = 'ON' THEN
            FOR REC IN C_COLS(P_KEY) LOOP
                L_RET := L_RET||L_TAB1||'.'||REC.COLS||' = '||L_TAB2||'.'||REC.COLS||' AND ';
            END LOOP;
        ELSIF P_RET_TYPE = 'CONCAT' THEN
            FOR REC IN C_COLS(P_KEY) LOOP
                L_RET := L_RET||L_TAB1||'.'||REC.COLS||' ||''-''|| ';
            END LOOP;
        END IF;
    END IF;
    
    IF P_RET_TYPE = 'KEY' THEN
            L_RET := SUBSTR(L_RET,1,LENGTH(L_RET)-3);
    ELSIF P_RET_TYPE = 'ON' THEN
            L_RET := SUBSTR(L_RET,1,LENGTH(L_RET)-5);
    ELSIF P_RET_TYPE = 'CONCAT' THEN
            L_RET := SUBSTR(L_RET,1,LENGTH(L_RET)-9);
    END IF;
    
    RETURN L_rET;
END;
   
BEGIN

   
  FOR R_TABS  IN C_TABS LOOP
      
    L_SQL :=  L_SQL ||  
   ' SELECT * FROM   (
    WITH '; 
        
    L_SQL := L_SQL ||    
    R_TABS.TAB||'_CURR AS
        (
        SELECT  '||F_COLS(P_COLS =>R_TABS.COLS,P_ALIAS => R_TABS.ALIAS)||','||F_COLS(P_COLS =>R_TABS.key,P_ALIAS => R_TABS.ALIAS)||'
          FROM '||R_TABS.OWNER||'.'||R_TABS.TAB||' '||R_TABS.ALIAS||'               
         WHERE 1 = 1 
         --AND '||R_TABS.ALIAS||'.'||R_TABS.KEY||' = 2051973
        ), 
        --
        --
        --
        '||R_TABS.TAB||'_BEFORE AS
        (
        SELECT '||F_COLS(P_COLS =>R_TABS.COLS,P_ALIAS => R_TABS.ALIAS)||','||F_COLS(P_COLS =>R_TABS.key,P_ALIAS => R_TABS.ALIAS)||'
         FROM '||R_TABS.OWNER||'.'||R_TABS.TAB||' '||R_TABS.ALIAS||'
              JOIN '||R_TABS.TAB||'_CURR ON '
              ||F_KEY_TRANS(R_TABS.ALIAS||','||R_TABS.TAB||'_CURR',R_TABS.KEY,'ON')||' 
        WHERE 1=1 
        ),
        --
        --
        --
         cols as
            (
            SELECT * 
               FROM ALL_TAB_COLUMNS C 
               WHERE C.TABLE_NAME = '''||R_TABS.TAB||''' 
               and  C.OWNER = '''||R_TABS.OWNER||'''
               --AND C.COLUMN_NAME IN (''POS_ADDRESS'',''REGION_DESC'') 
               AND C.COLUMN_NAME NOT IN (''DATE_FROM'',''DATE_UNTIL'',''GNUM'',''HISTORY_INDICATOR'')
               --AND C.COLUMN_NAME NOT IN ('||F_KEY_TRANS(R_TABS.TAB,R_TABS.KEY,'KEY_QUOTES')||')
               AND C.COLUMN_NAME IN ('||F_KEY_TRANS(R_TABS.TAB,R_TABS.COLS,'KEY_QUOTES')||')
               ORDER BY C.COLUMN_ID
               --SELECT * FROM DWHRBA.TMP_CDC_TAB_COLUMNS_'||R_TABS.TAB||'''
            ),COL_VALS AS
            (
             --
             --
             --
             select
             '''||R_TABS.TAB||''' AS TABLE_NAME,
             '''||R_TABS.KEY||''' AS TABLE_KEY,'
             ||F_KEY_TRANS(R_TABS.TAB||'_CURR,'||R_TABS.TAB||'_CURR', R_TABS.KEY, 'CONCAT')||' AS KEY_VALUE, '||' 
             cols.column_name as column_name,
         CASE ' ;
        
         FOR R_TAB_COLS IN C_TAB_COLS( p_OWNER=>R_TABS.OWNER, P_TABLE_NAME => R_TABS.TAB, P_INCLUDE => R_TABS.COLS ) LOOP
             L_SQL := L_SQL ||'
             WHEN  cols.column_name =  '''||R_TAB_COLS.COLUMN_NAME||''' THEN       TO_CHAR('||R_TABS.TAB||'_BEFORE.'||R_TAB_COLS.COLUMN_NAME||')' ;     
         END LOOP;
         L_SQL := L_SQL ||' END BEFORE_VALUE, 
         CASE ';         
         
         FOR R_TAB_COLS IN C_TAB_COLS( p_OWNER=>R_TABS.OWNER, P_TABLE_NAME => R_TABS.TAB, P_INCLUDE => R_TABS.COLS) LOOP
             L_SQL := L_SQL ||'
             WHEN  cols.column_name ='''||R_TAB_COLS.COLUMN_NAME||''' THEN       TO_CHAR('||R_TABS.TAB||'_CURR.'||R_TAB_COLS.COLUMN_NAME||')' ;     
         END LOOP;
         
         L_SQL := L_SQL ||' END CURR_VALUE';                       
         L_SQL := L_SQL ||' FROM  '||R_TABS.TAB||'_CURR LEFT join  '||R_TABS.TAB||'_BEFORE on  '||F_KEY_TRANS(R_TABS.TAB||'_CURR,'||R_TABS.TAB||'_BEFORE',R_TABS.KEY,'ON' )||'
                  cross join cols
            )
            SELECT * 
              FROM COL_VALS 
             WHERE NVL(COL_VALS.CURR_VALUE,''-X'') != NVL(BEFORE_VALUE,''-X'')
             ORDER BY 1,2,3';       
         L_SQL := L_SQL ||') union all ';
  END LOOP;
   
  L_SQL := substr(L_SQL,1, length(l_sql) - length('union all ')); 
  DBMS_OUTPUT.PUT_LINE(L_SQL );
 -- DBMS_OUTPUT.PUT_LINE(length(l_sql)||' - '||(length(l_sql) - 2000 ));
  --DBMS_OUTPUT.PUT_LINE(substr(L_SQL,length(l_sql)-9) );   
  
END;