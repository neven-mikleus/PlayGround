SELECT C.CURRENCY_ISO_CODE,
       SR.MID_REVAL_RATE,
       TO_CHAR (SR.FIXING_DATE, 'yyyy-mm-dd')
  FROM DWHCO.TB0_CURRENCY_SPOT_RATE sr
       join DWHCO.TB0_CURRENCY c on sr.TO_CURRENCY_UNID = C.UNID 
 WHERE 1=1   
       AND SR.FIXING_DATE = date'2023-05-31' 
       and C.CURRENCY_ISO_CODE = 'HUF'
       
       
       
