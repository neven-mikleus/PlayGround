DECLARE
    L_SQL VARCHAR2(32767);
    L_CNT NUMBER;

   CURSOR C IS
       with tabs 
        as
        (
        SELECT  'DSA_ACC_TRANS' table_name  FROM dual   A    union all
        SELECT  'DSA_BEVENT'                FROM dual   A    union all
        SELECT  'DSA_CLIENT'                FROM dual   A    union all
        SELECT  'DSA_CLIENT_CUSTOM'         FROM dual   A    union all
        SELECT  'DSA_COLLATERAL'            FROM dual   A    union all
        SELECT  'DSA_COLLATERAL_CUSTOM'     FROM dual   A    union all
        SELECT  'DSA_COLLATERAL_LINK'       FROM dual   A    union all
        SELECT  'DSA_CONTRACT'              FROM dual   A    union all
        SELECT  'DSA_CONTRACT_CUSTOM'       FROM dual   A    union all
        SELECT  'DSA_CONTRACT_ORIG'         FROM dual   A    union all
        SELECT  'DSA_EIR'                   FROM dual   A    union all
        SELECT  'DSA_EIR_MIGRATION'         FROM dual   A    union all
        SELECT  'DSA_FEE'                   FROM dual   A    union all
        SELECT  'DSA_FEE_SCHEDULE_DEF'      FROM dual   A    union all
        SELECT  'DSA_FIXED_PERCENTAGE'      FROM dual   A    union all
        SELECT  'DSA_FX_RATE'               FROM dual   A    union all
        SELECT  'DSA_GL_BALANCE'            FROM dual   A    union all
        SELECT  'DSA_GL_MAPPING'            FROM dual   A    union all
        SELECT  'DSA_MATRIX'                FROM dual   A    union all
        SELECT  'DSA_OPENING_BALANCE'       FROM dual   A    union all
        SELECT  'DSA_PAYMENT_SCHEDULE'      FROM dual   A    union all
        SELECT  'DSA_PAYMENT_SCHEDULE_ADDMODE' FROM dual A    union all
        SELECT  'DSA_PAYMENT_SCHEDULE_DEF'  FROM dual   A    union all
        SELECT  'DSA_RECOVERY'              FROM dual   A    union all
        SELECT  'DSA_RECOVERY_SCENARIOS'    FROM dual   A    union all
        SELECT  'DSA_REFERENCE_RATE'        FROM dual   A    union all
        SELECT  'DSA_WRITE_OFF'             FROM dual   A    union all
        SELECT  'DSA_ZERO_COUPON'           FROM dual   A   
        )
        , col as
        (
        select column_id,c.column_name,owner,t.table_name  from   all_tab_columns c
        join tabs t on t.table_name = c.table_name
        where column_name !='ID_EXPORT'
        ),exports as
        (
        select 2023113050 id_export1,2023113051 id_export2 from   dual
        )
    SELECT 
        table_name AS table_name,
        ' (select '||LISTAGG(column_name, ', ')     WITHIN GROUP (ORDER BY column_id)||' from '||owner||'.'||table_name||' a where ID_EXPORT = '||E.ID_EXPORT1   AS a
        ,' minus select '||LISTAGG(column_name, ', ')    WITHIN GROUP (ORDER BY column_id)||' from '||owner||'.'||table_name||' a where ID_EXPORT = '||E.ID_EXPORT2||')'  AS b
        ,' union all ' AS c
        ,' (select '||LISTAGG(column_name, ', ')     WITHIN GROUP (ORDER BY column_id)||' from '||owner||'.'||table_name||' a where  ID_EXPORT = '||E.ID_EXPORT2   D
        ,' minus select '||LISTAGG(column_name, ', ')    WITHIN GROUP (ORDER BY column_id)||' from '||owner||'.'||table_name||' a where  ID_EXPORT = '||E.ID_EXPORT1||')'  E 
      FROM col c
           CROSS JOIN EXPORTS E
     WHERE     1 = 1
           --AND c.table_name = 'DSA_CLIENT'
           --AND c.owner = 'FV_DSA_PROD'
    group by owner     ,table_name, E.ID_EXPORT1 ,E.ID_EXPORT2;

   
BEGIN


 FOR REC IN C LOOP
 
    L_SQL := 
        'select count(*) from ('||REC.A||' '||REC.B||' '||REC.C||' '||REC.D||' '||REC.E||') WHERE ROWNUM <2';
    
    EXECUTE IMMEDIATE L_SQL INTO L_CNT;

    IF L_CNT > 0 THEN
        DBMS_OUTPUT.PUT_LINE('RAZLIKA ZA TABLICU: '||REC.TABLE_NAME); 
        DBMS_OUTPUT.PUT_LINE(L_SQL);
        DBMS_OUTPUT.PUT_LINE(''); 
        DBMS_OUTPUT.PUT_LINE(''); 
    END IF;
    
 END LOOP;
 
  
END;

