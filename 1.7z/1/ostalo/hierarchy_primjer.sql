with emp
as(
select 1 id, 'Mng. Zvonko' name, null manager_id  from dual union all
select 2 id, 'Mng. �una' name, null manager_id  from dual union all
select 3 id, 'Aleks' name, 1 manager_id  from dual union all
select 4 id, 'Tomo' name, 1 manager_id  from dual union all
select 5 id, 'Luka' name, 2 manager_id  from dual union all
select 6 id, 'Luce' name, 2 manager_id  from dual union all
select 7 id, 'Iva od Aleksa' name, 2 manager_id  from dual    union all
select 7 id, 'Iva' name, 3 manager_id  from dual      
)
select emp.*
,level
,lpad(' ', level*6, '    ')||name nam2
,LPAD(' ', 2*level-1)||SYS_CONNECT_BY_PATH(name, '/') "Path"
  from  emp
connect by prior  id = manager_id
start with  manager_id is null 
order by id