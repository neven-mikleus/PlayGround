with jbxc as (
  select 'AccountPreJobNonRetail_New_test_naknade' as job_name from dual union all 
  select 'AccountPreJobRetail_New_test_def_naknade' as job_name from dual union all 
  select 'Bevent_KRD' as job_name from dual union all 
  select 'Bevent_KRD_NRT' as job_name from dual union all 
  select 'Bevent_PKR_NRT' as job_name from dual union all 
  select 'ContractPreJobNonRetail' as job_name from dual union all 
  select 'ContractPreJobRetail_test_Default' as job_name from dual union all 
  select 'CopyExportData' as job_name from dual union all 
  select 'CustomerDsaClientNonRetail' as job_name from dual union all 
  select 'CustomerDsaClientRetail' as job_name from dual union all 
  select 'CustomerPreJob' as job_name from dual union all 
  select 'DSA_DATA_STATUS_Finish' as job_name from dual union all 
  select 'DSA_DATA_STATUS_StartNonRetail' as job_name from dual union all 
  select 'DSA_DATA_STATUS_StartRetail_New' as job_name from dual union all 
  select 'ExportData' as job_name from dual union all 
  select 'ExportData2_imp' as job_name from dual union all 
  select 'ExportDataSeq' as job_name from dual union all 
  select 'Fee_Akreditivi' as job_name from dual union all 
  select 'Fee_FAC' as job_name from dual union all 
  select 'Fee_GAR' as job_name from dual union all 
  select 'Fee_KRD' as job_name from dual union all 
  select 'Fee_Okviri' as job_name from dual union all 
  select 'Fee_Overdraft' as job_name from dual union all 
  select 'Fee_PKR' as job_name from dual union all 
  select 'FXRate' as job_name from dual union all 
  select 'IFRS9_Account_NonRetail_KKR_PPZ_s_nakn' as job_name from dual union all 
  select 'IFRS9_Account_NonRetail_SDR_SDA_prod' as job_name from dual union all 
  select 'IFRS9_Account_Retail_KKR_TRC_PPZ' as job_name from dual union all 
  select 'IFRS9_Account_Retail_KKR_TRC_PPZ_test_naknade' as job_name from dual union all 
  select 'IFRS9_Bevent_Seq' as job_name from dual union all 
  select 'IFRS9_Bevent_Seq_NRT' as job_name from dual union all 
  select 'IFRS9_Collateral_Collateral_Link_NonRetail_New_VER4' as job_name from dual union all 
  select 'IFRS9_Collateral_Collateral_Link_Retail_DONTCutHNBProvisions' as job_name from dual union all 
  select 'IFRS9_Contract_NonRetail_DST_prod' as job_name from dual union all 
  select 'IFRS9_Contract_NonRetail_FAC_prod' as job_name from dual union all 
  select 'IFRS9_Contract_NonRetail_FOR_prod' as job_name from dual union all 
  select 'IFRS9_Contract_NonRetail_FOR_test_def' as job_name from dual union all 
  select 'IFRS9_Contract_NonRetail_GAR_prod' as job_name from dual union all 
  select 'IFRS9_Contract_NonRetail_KRD_prod' as job_name from dual union all 
  select 'IFRS9_Contract_NonRetail_LOC_prod' as job_name from dual union all 
  select 'IFRS9_Contract_NonRetail_LOC_test_def' as job_name from dual union all 
  select 'IFRS9_Contract_NonRetail_OKV_prod' as job_name from dual union all 
  select 'IFRS9_Contract_NonRetail_OKV_test_def' as job_name from dual union all 
  select 'IFRS9_Contract_NonRetail_PKR_prod' as job_name from dual union all 
  select 'IFRS9_Contract_NonRetail_WSS_LORO_prod' as job_name from dual union all 
  select 'IFRS9_Contract_NonRetail_WSS_prod' as job_name from dual union all 
  select 'IFRS9_Contract_Retail_DST' as job_name from dual union all 
  select 'IFRS9_Contract_Retail_GAR_test_def' as job_name from dual union all 
  select 'IFRS9_Contract_Retail_KRD_test_def' as job_name from dual union all 
  select 'IFRS9_Contract_Retail_PKR_test_def' as job_name from dual union all 
  select 'IFRS9_Fee_NonRetail' as job_name from dual union all 
  select 'IFRS9_Fee_Retail' as job_name from dual union all 
  select 'IFRS9_NonRetail_New_prod' as job_name from dual union all 
  select 'IFRS9_NonRetail_WithCopy_PROD' as job_name from dual union all 
  select 'IFRS9_Retail_New' as job_name from dual union all 
  select 'IFRS9_Securities_NonRetail_IN2_prod' as job_name from dual union all 
  select 'IFRS9_Zero_Coupon_NonRetail' as job_name from dual union all 
  select 'NRT' as job_name from dual union all 
  select 'PaymentSchedule_NonRetail' as job_name from dual union all 
  select 'PaymentSchedule_Retail' as job_name from dual union all 
  select 'Retail' as job_name from dual union all 
  select 'WriteOff_NRT' as job_name from dual union all 
  select 'WriteOff_Retail_HNB' as job_name from dual union all 
  select 'WriteOff_Retail_new_20191201' as job_name from dual
),
vw_stages as (
  select
    --jbxc.job_name job_name_excel,
    jb.name_xmeta job_name,
    --jb.XMETA_REPOS_OBJECT_ID_XMETA job_id,
    jb.CATEGORY_XMETA job_folder,
    jb.DSNAMESPACE_XMETA job_project,
    stg.name_XMETA stage_name,
    stg.STAGETYPE_XMETA,
    stg.STAGETYPECLASSNAME_XMETA,
    --stg.HAS_PARAMETERVAL_XMETA,
    --stg.*
    --pvl.*,
    --pvl.PARAMETERNAME_XMETA,
    --pvl.VALUEEXPRESSION_XMETA,
    rtrim(substr(xmltype(pvl.VALUEEXPRESSION_XMETA).EXTRACT('/Properties/Usage/SQL/SelectStatement/text()').getclobval(), 10), ']>') SelectStatement,
    rtrim(substr(xmltype(pvl.VALUEEXPRESSION_XMETA).EXTRACT('/Properties/Usage/TableAction/GenerateCreateStatement/CreateStatement/text()').getclobval(), 10), ']>') CreateStatement,
    rtrim(substr(xmltype(pvl.VALUEEXPRESSION_XMETA).EXTRACT('/Properties/Usage/TableAction/GenerateDropStatement/DropStatement/text()').getclobval(), 10), ']>') DropStatement,
    rtrim(substr(xmltype(pvl.VALUEEXPRESSION_XMETA).EXTRACT('/Properties/Usage/SQL/InsertStatement/text()').getclobval(), 10), ']>') InsertStatement,
    rtrim(substr(xmltype(pvl.VALUEEXPRESSION_XMETA).EXTRACT('/Properties/Usage/BeforeAfter/BeforeSQL/text()').getclobval(), 10), ']>') BeforeSQL,
    rtrim(substr(xmltype(pvl.VALUEEXPRESSION_XMETA).EXTRACT('/Properties/Usage/BeforeAfter/AfterSQL/text()').getclobval(), 10), ']>') AfterSQL,
    
    1 as jedan
  from jbxc
  left join dsxmeta.DATASTAGEX_DSJOBDEF jb
    on jbxc.job_name = jb.name_xmeta
  left join dsxmeta.DATASTAGEX_DSPROJECT dsp
    on jb.DSNAMESPACE_XMETA = dsp.HOSTNAME_XMETA || ':' || dsp.NAME_XMETA
    and dsp.NAME_XMETA = 'IFRS9'
  left join dsxmeta.datastagex_dsstage stg
    on stg.CONTAINER_RID = jb.XMETA_REPOS_OBJECT_ID_XMETA
  left join dsxmeta.DATASTAGEXDSPARAMETRVL pvl
    on instr(stg.HAS_PARAMETERVAL_XMETA, pvl.xmeta_repos_object_id_xmeta) >= 1
    and pvl.PARAMETERNAME_XMETA = 'XMLProperties'
  where 1=1
    --and jb.name_xmeta is not null
    --and jb.name_xmeta = 'CustomerDsaClientNonRetail'
    --and jb.name_xmeta = 'CustomerPreJob'
    --and jb.name_xmeta in ( 'CustomerPreJob','NRT','Retail','IFRS9_Zero_Coupon_NonRetail')
    --and stg.name_xmeta = 'Ifrs9_Write_Off'
    and pvl.PARAMETERNAME_XMETA is not null
  order by 2 nulls first
)
--select * from vw_stages
select jbxc.job_name job_name_excel, vw_stages.* from jbxc
left join vw_stages
  on jbxc.job_name = vw_stages.job_name
order by jbxc.job_name
;