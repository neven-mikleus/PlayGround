-- mapiranje
-- derivation sadrži mapiranje koje nije direktno iz kolone ulaznog linka
-- derivation se spaja na flowvariable - to je kolona u mapingu
-- flowariable se spaja na link - on nosi mapiranje a ne transformer
-- link spajamo na out pin iz transformera
-- out pin spajamo na transformer
-- locking on root je obično job u kojem smo
-- treba još provjeriti stage variable transformera - tamo se isto mogu nalaziti hardkodirane vrijednosti
select
  jb.dsnamespace_xmeta job_project,
--  jb.category_xmeta job_folder,
  jb.name_xmeta job_name,
  der.PARSEDEXPRESSION_XMETA,
  --der.EXPRESSION_XMETA,
  flw.name_xmeta as kolona,
  lnk.name_xmeta link_name,
  stg.name_xmeta transformer_name
from XMETA.DATASTAGEXDSDERIVATION der
left join XMETA.datastagexdsflowvaribl flw
  on flw.XMETA_REPOS_OBJECT_ID_XMETA = der.DERIVES_FLOWVARIABLE_XMETA
left join xmeta.DATASTAGEX_DSLINK lnk
  on lnk.XMETA_REPOS_OBJECT_ID_XMETA = flw.CONTAINER_RID
left join XMETA.DATASTAGEX_DSOUTPUTPIN out_pin
  on out_pin.XMETA_REPOS_OBJECT_ID_XMETA = lnk.FROM_OUTPUTPIN_XMETA
left join XMETA.DATASTAGEX_DSSTAGE stg
  on stg.XMETA_REPOS_OBJECT_ID_XMETA = out_pin.CONTAINER_RID
left join xmeta.DATASTAGEX_DSJOBDEF jb
  on jb.XMETA_REPOS_OBJECT_ID_XMETA = der.XMETA_LOCKINGROOT_XMETA
where 7=7
  and der.expression_xmeta like '%HRK%'
  --and jb.dsnamespace_xmeta = 'RBADWH-P:IFRS9'
;
