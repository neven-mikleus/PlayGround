with job_mapping as(
select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Account_Retail_KKR_TRC_PPZ_test_naknade'    AS TARGET_JOB, 'KKR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
/*
           select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Account_Retail_KKR_TRC_PPZ_test_naknade'    AS TARGET_JOB, 'KKR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Account_Retail_KKR_TRC_PPZ_test_naknade'    AS TARGET_JOB, 'TRC' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Account_Retail_KKR_TRC_PPZ_test_naknade'    AS TARGET_JOB, 'SDR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 --
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Contract_Retail_GAR_test_def'            AS TARGET_JOB, 'GAR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Contract_Retail_KRD_test_def'            AS TARGET_JOB, 'KRD' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Contract_NonRetail_LOC_test_def'         AS TARGET_JOB, 'LOC' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Contract_Retail_PKR_test_def'            AS TARGET_JOB, 'PKR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Contract_NonRetail_OKV_test_def'         AS TARGET_JOB, 'OKV' as APPLICATION_ID, 'RET' as  ret_nrt from dual 
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Contract_NonRetail_FOR_test_def'         AS TARGET_JOB, 'FOR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 -- write off
 union all select 'DSA_WRITE_OFF' AS TARGET_TABLE, 'ToDsa'      AS TARGET_TABLE_LINK, 'WriteOff_Retail_HNB'                          AS TARGET_JOB, 'WOF' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_WRITE_OFF' AS TARGET_TABLE, 'DSLink132'  AS TARGET_TABLE_LINK, 'WriteOff_Retail_HNB'                          AS TARGET_JOB, 'WOF' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 -- Fee
 union all select 'DSA_FEE'       AS TARGET_TABLE, 'DSA_fee'  AS TARGET_TABLE_LINK, 'Fee_GAR'        AS TARGET_JOB, 'GAR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_FEE'       AS TARGET_TABLE, 'DSA_fee'  AS TARGET_TABLE_LINK, 'Fee_KRD'        AS TARGET_JOB, 'KRD' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_FEE'       AS TARGET_TABLE, 'DSA_fee'  AS TARGET_TABLE_LINK, 'Fee_PKR'        AS TARGET_JOB, 'PKR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_FEE'       AS TARGET_TABLE, 'DSA_fee'  AS TARGET_TABLE_LINK, 'Fee_Akreditivi' AS TARGET_JOB, 'AKR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_FEE'       AS TARGET_TABLE, 'DSA_fee'  AS TARGET_TABLE_LINK, 'Fee_Okviri'     AS TARGET_JOB, 'OKV' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_FEE'       AS TARGET_TABLE, 'DSA_fee'  AS TARGET_TABLE_LINK, 'Fee_Overdraft'  AS TARGET_JOB, 'OVD' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 --Bevent
 union all select 'DSA_BEVENT'       AS TARGET_TABLE, 'DSA_bevent'  AS TARGET_TABLE_LINK, 'Bevent_KRD'  AS TARGET_JOB, 'KRD' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_BEVENT'       AS TARGET_TABLE, 'DSA_bevent'  AS TARGET_TABLE_LINK, 'Bevent_PKR'  AS TARGET_JOB, 'PKR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 --DSA_PAYMENT_SCHEDULE
 union all select 'DSA_PAYMENT_SCHEDULE'       AS TARGET_TABLE, 'ToPS'  AS TARGET_TABLE_LINK, 'PaymentSchedule_Retail'  AS TARGET_JOB, null as APPLICATION_ID, 'RET' as  ret_nrt from dual
 --DSA_COLLATERAL
 union all select 'DSA_COLLATERAL'       AS TARGET_TABLE, 'ToCollateral'  AS TARGET_TABLE_LINK, 'IFRS9_Collateral_Collateral_Link_DONTCutHNBProvisions'  AS TARGET_JOB, '' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 */
), 
 tb0 as (
  -- upit dohva�a link i polja iz kojih �emo vaditi kolone i mapiranja koja se nalaze u transformeru
  -- prvo napadamo DSFLOWVARPROPS_XMETA, a kasnije DATASTAGEXDSFLOWVARIBL
  select
    JB.DSNAMESPACE_XMETA JOB_PROJECT,
    jb.name_xmeta job_name,
    --JB_MAP.TARGET_TABLE,
    lnk.XMETA_REPOS_OBJECT_ID_XMETA,
    lnk.name_xmeta ,
    stg.name_xmeta transformer_name,  
    stg.XMETA_REPOS_OBJECT_ID_XMETA  transformer_XMETA_REPOS_OBJECT_ID_XMETA,
    --' -- ## -- ' spacer,
    lnk.CONTAINS_FLOWVARIABLE_XMETA,
    lnk.DSFLOWVARSOURCECOLUMNIDS_XMETA,
    lnk.DSFLOWVARNAMES_XMETA,
    lnk.DSFLOWVARPROPS_XMETA,
    jb.dsnamespace_xmeta,
    --
    lnk.FROM_OUTPUTPIN_XMETA,
    lnk.TO_INPUTPIN_XMETA
    --
    -- JB_MAP.APPLICATION_ID, 
   -- JB_MAP.ret_nrt 
  from xmeta.DATASTAGEX_DSLINK lnk
  left join XMETA.DATASTAGEX_DSOUTPUTPIN out_pin
    on out_pin.XMETA_REPOS_OBJECT_ID_XMETA = lnk.FROM_OUTPUTPIN_XMETA
   left join XMETA.DATASTAGEX_DSOUTPUTPIN in_pin
    on in_pin.XMETA_REPOS_OBJECT_ID_XMETA = lnk.TO_INPUTPIN_XMETA
  left join XMETA.DATASTAGEX_DSSTAGE stg
    on stg.XMETA_REPOS_OBJECT_ID_XMETA = out_pin.CONTAINER_RID
  left join xmeta.DATASTAGEX_DSJOBDEF jb
    on jb.XMETA_REPOS_OBJECT_ID_XMETA = lnk.XMETA_LOCKINGROOT_XMETA
  --JOIN job_mapping JB_MAP ON JB_MAP.TARGET_JOB = jb.name_xmeta --AND JB_MAP.TARGET_TABLE_LINK =lnk.name_xmeta 
  where 7=7
    -- filtriramo link_id (ako imamo id br�e je nego po link_name), job_name, link_name
--    and lnk.XMETA_REPOS_OBJECT_ID_XMETA = 'c2e76d84.78bf4d29.6duo7qlno.b001ar6.ja1fa1.4v74gtdurqjs1oj6fmjmg' -- ApplicationForm
--    and jb.DSNAMESPACE_XMETA = 'RBADWH-PE:RBADWH30'
--    and jb.name_xmeta = 'Applicant�ZahtjeviTRC_SIRIUS'
--    and lnk.name_xmeta = 'ApplicationForm'
 --AND (jb.name_xmeta,lnk.name_xmeta ) IN (SELECT A.TARGET_JOB, A.TARGET_TABLE_LINK FROM  job_mapping A)
    --and jb.name_xmeta = 'IFRS9_Contract_Retail_PKR_test_def'
    --and lnk.name_xmeta = 'ToDsa'
    and jb.DSNAMESPACE_XMETA = 'RBADWH-PE:IFRS9'
),
tb1 as (
  -- razbijamo polje DSFLOWVARNAMES_XMETA u retke, separator je chr(29) - to su nazivi kolona �ija mapiranja se nalaze u DSFLOWVARPROPS_XMETA
  -- ako se mapiranje na nalazi u DSFLOWVARPROPS_XMETA, onda uzimamo vrijednost iz DSFLOWVARSOURCECOLUMNIDS_XMETA
  -- sve kolone koje postoje u mapiranju za zadani link a ne nalazimo u DSFLOWVARNAMES_XMETA biti �e u CONTAINS_FLOWVARIABLE_XMETA
  -- kolone iz CONTAINS_FLOWVARIABLE_XMETA �e imati mapiranje u DATASTAGEXDSDERIVATION tablici
  -- redoslijed kolona je zadan u DSFLOWVARPROPS_XMETA, ali oni redovi u DSFLOWVARPROPS_XMETA koji imaju u sebi q=<broj> prije sebe moraju 
  -- ubaciti onoliki broj kolona iz DSFLOWVARNAMES_XMETA koloko se nalazi iza q
  -- npr. ako je q=2 onda moramo ubaciti 2 kolone
  -- broj redaka u DSFLOWVARNAMES_XMETA odgovara broju redaka u DSFLOWVARPROPS_XMETA, imaju isti separator chr(29)
  -- ponekad se u DSFLOWVARPROPS_XMETA ne�e nalaziti naziv kolone, pa ga uzimamo redoslijedom iz DSFLOWVARNAMES_XMETA
  -- radimo replace "chr(29)" sa "|" kako razbili DSFLOWVARNAMES_XMETA i DSFLOWVARPROPS_XMETA u retke
  -- prvenstveno zato �to DSFLOWVARPROPS_XMETA ima jo� kontrolnih znakova, pa ako bi razbijali po [[:cntrl:]] ne bi i�lo
  select
    lnk.name_xmeta link_name,
    lnk.transformer_name,
    lnk.job_name,
    --LNK.TARGET_TABLE,
    --stg.name_xmeta transformer_name,  
    --' -- ## -- ' spacer,
    lnk.CONTAINS_FLOWVARIABLE_XMETA,
    --lnk.DSFLOWVARNAMES_XMETA,
    --lnk.DSFLOWVARSOURCECOLUMNIDS_XMETA,
    --lnk.DSFLOWVARPROPS_XMETA,
    to_char(regexp_substr(replace(lnk.DSFLOWVARNAMES_XMETA, chr(29), '|'), '[^|]+',1,cjl.lvl)) df_names, -- chr29 je separator retka, vadimo imena kolona
    to_char(regexp_substr(replace(lnk.DSFLOWVARPROPS_XMETA, chr(29), '|'), '[^|]+',1,cjl.lvl)) df_prop,
    to_char(regexp_substr(replace(lnk.DSFLOWVARSOURCECOLUMNIDS_XMETA, chr(29), '| '), '[^|]+',1,cjl.lvl)) df_src_col_id, -- ubacujemo '|;' tako da uhvatimo i prazne
    cjl.lvl,
    lnk.FROM_OUTPUTPIN_XMETA,
    lnk.TO_INPUTPIN_XMETA,
    lnk.transformer_XMETA_REPOS_OBJECT_ID_XMETA,
    --lnk.APPLICATION_ID, 
    --lnk.ret_nrt,
    1 as jedan
    --stg.*
  from tb0 lnk
  cross join lateral (
    -- razbojamo kolonu DSFLOWVARNAMES_XMETA u retke - vadimo nazive kolona
    select
      level lvl,
      to_char(regexp_substr(lnk.DSFLOWVARNAMES_XMETA, '[^[:cntrl:]+]',1,level)) id
    from dual
    connect by level <= regexp_count(lnk.DSFLOWVARNAMES_XMETA, '[^[:cntrl:]]+',1)
  ) cjl
)
--select * From tb1; /
,
tb2 as (
-- vadimo polja iz DSFLOWVARPROPS_XMETA:
  -- 3 - [description]
  -- y - tip kolone
  -- x - [Length]
  -- q - broj kolona koje treba ubacit prije kolone iz danog retka, a nalaze se u DATASTAGEXDSFLOWVARIBL
  -- d - [Display]
  -- o - db tip kolone [SQL type]
  -- R - naziv kolone [Column name]
  -- T - lokacija definicije tablice - iako nisam uspio na�i tu lokaciju u table_definition tablici
  -- K - [Key] - klju� seta podataka
  -- >e - expression - mapiranje
  -- >P - parsed expression - mapiranje
  -- n,f,l,s,i,A,H,G,N,I,O,S,J,U,>1 - ?? - nepoznato zna�enje za sada
  -- ovime smo izvadili sva polja iz dwflowarnames,props, njihova mapiranja, q vrijednosti
  select
    tb1.lvl,
    df_names,
    tb1.transformer_name,
    tb1.link_name,
    tb1.job_name,
    --TB1.TARGET_TABLE,
    tb1.FROM_OUTPUTPIN_XMETA,
    tb1.TO_INPUTPIN_XMETA,
    tb1.transformer_XMETA_REPOS_OBJECT_ID_XMETA,
    --tb1.application_id,
    --tb1.ret_nrt,
    substr(trim(df_src_col_id),2,nvl(length(trim(df_src_col_id)),2)-2) df_src_col_id,
    regexp_substr(tb1.df_prop, '[[:cntrl:]]>P=(.*?)[[:cntrl:]]',1,1,'i',1) p_polje, -- mapiranje, ako nema onda uzimamo iz DSFLOWVARSOURCECOLUMNIDS_XMETA
    regexp_substr(tb1.df_prop, '[[:cntrl:]]q=(.*?)[[:cntrl:]]',1,1,'i',1) q_polje, -- broj polja iz flowars koje treba ubaciti prije ovog polja
    regexp_substr(tb1.df_prop, '[[:cntrl:]]R=(.*?)[[:cntrl:]]',1,1,'i',1) r_polje -- naziv kolone - ne mora postojat, onda uzimamo iz DSFLOWVARNAMES_XMETA tamo je sigurno
  from tb1
)
--select * From tb2; /
,
tb3 as (
  -- detektiramo samo one kolone koje imaju q vrijednosti na sebi i poredavamo ih sa rank
  select
    tb2.*,
    rank() over (partition by case when q_polje is not null then 1 end order by lvl) rnk
  from tb2
)
--select * From tb3; /
,
  tb4 as (
  -- vadimo CONTAINS_FLOWVARIABLE_XMETA kolone i njihova mapiranja, dio je tu koji nismo dodsad uspili izvadit 
  select
    --cjl.id,
    cjl.lvl col_id,
    to_char(flw.name_xmeta) column_name,
    to_char(nvl(der.PARSEDEXPRESSION_XMETA, flw.SOURCECOLUMNID_XMETA)) column_mapping
   ,tb0.name_xmeta link_name
   ,tb0.transformer_name
   ,tb0.job_name
   --,TB0.TARGET_TABLE
   --
    ,tb0.FROM_OUTPUTPIN_XMETA,
    tb0.TO_INPUTPIN_XMETA,
    tb0.transformer_XMETA_REPOS_OBJECT_ID_XMETA
    --tb0.application_id
    --tb0.ret_nrt
   --,'fdf' link_name
  from tb0
  cross join lateral (
    select
      level lvl,
      to_char(regexp_substr(tb0.CONTAINS_FLOWVARIABLE_XMETA, '[^[:cntrl:]]+',1,level)) id
    from dual
    connect by level <= regexp_count(tb0.CONTAINS_FLOWVARIABLE_XMETA, '[^[:cntrl:]]+',1)
  ) cjl
  left join XMETA.DATASTAGEXDSFLOWVARIBL flw
    on flw.XMETA_REPOS_OBJECT_ID_XMETA = cjl.id
  left join XMETA.DATASTAGEXDSDERIVATION der
    on der.XMETA_REPOS_OBJECT_ID_XMETA = to_char(substr(flw.HASVALUE_DERIVATION_XMETA,2,64))
 --where to_char(flw.name_xmeta) = 'ORIGINATION_DATE'
)
--select * From tb4; /
,
tb5 as (
  -- hvatamo samo retke sa q vrijednosti, multipliciramo q+1 puta sa cross join lateral
  -- radimo mjesta da ubacimo ispred svih polja koja imaju q>0 polja iz DATASTAGEXDSFLOWVARIBL 
  select 
    tb3.*,
    lvl1,
    rownum as rn
  from tb3
  cross join lateral (
    select
      level lvl1
    from dual
    connect by level <= q_polje+1
  ) cjl
  --where q_polje is not null
)
--select * From tb5; /
,
TB6 AS (
  -- izbacujemo sve prve, njima �emo ostaviti mapiranje, a na ostale �emo naka�iti iz DATASTAGEXDSFLOWVARIBL
  SELECT
    TB5.*,
    ROWNUM RN_JOIN_FLW
  FROM TB5 WHERE LVL1 > 1
  ORDER BY RN
),
TB7 AS (
  -- SPAJAMO FLOWVARIABLE I MJESTA NAKON Q IZ FLOVARPROPS
  SELECT * FROM TB6
  LEFT JOIN TB4
    ON TB6.RN_JOIN_FLW = TB4.COL_ID
),
TB8 AS (
  -- sajamo nove kolone na pri�irene stare
  SELECT
    NVL(TB7.COLUMN_NAME,TB5.DF_NAMES) AS COLUMN_NAME,
    --TB5.TARGET_TABLE,
    coalesce(TB7.COLUMN_MAPPING, TB5.P_POLJE, tb5.df_src_col_id) AS COLUMN_MAPPING,
    TB7.COL_ID AS FLOWAR_COLID,
    tb5.df_src_col_id,
    tb5.link_name,
    tb5.transformer_name,
    tb5.job_name,
     tb5.FROM_OUTPUTPIN_XMETA,
    tb5.TO_INPUTPIN_XMETA,
    tb5.transformer_XMETA_REPOS_OBJECT_ID_XMETA
    --tb5.application_id,
    --tb5.ret_nrt
  FROM TB5
  LEFT JOIN TB7
    ON TB5.RNK=TB7.RNK
    AND TB5.LVL1=TB7.LVL1
  ORDER BY 
    TB5.LVL, -- redoslijed ide prvo po props
    TB7.COL_ID -- zatim po uba�enim kolonama, ovime �e uba�ene kolone i�i ispred kolone sa q>0
)
, DAT AS
   (   
   select /*+ materialize */
       stage_in.name_xmeta  m1,    
       link_in.name_xmeta  m2,
       stage_OUT.name_xmeta  m3,
       STAGE_IN.STAGETYPE_XMETA    STAGETYPE_m1,
       CAST('LINK' AS NVARCHAR2(4))    STAGETYPE_m2,
       stage_OUT.STAGETYPE_XMETA    STAGETYPE_m3,
       STAGE_IN.XMETA_REPOS_OBJECT_ID_XMETA XMETA_REPOS_OBJECT_ID_XMETA_M1,
       link_in.XMETA_REPOS_OBJECT_ID_XMETA XMETA_REPOS_OBJECT_ID_XMETA_M2,
       stage_OUT.XMETA_REPOS_OBJECT_ID_XMETA XMETA_REPOS_OBJECT_ID_XMETA_M3   
FROM XMETA.datastagex_dsjobdef job
       join XMETA.datastagex_dsstage stage_in     on job.xmeta_repos_object_id_XMETA = stage_in.container_rid
      left join  XMETA.datastagex_dsinputpin pin_id on pin_id.container_rid = stage_in.xmeta_repos_object_id_xmeta
      left  join XMETA.datastagex_dslink link_in on pin_id.xmeta_repos_object_id_xmeta = LINK_IN.TO_INPUTPIN_XMETA 
      left join  XMETA.datastagex_dsoutputpin pout_id on pout_id.xmeta_repos_object_id_xmeta = LINK_IN.FROM_OUTPUTPIN_XMETA    
       LEFT join XMETA.datastagex_dsstage stage_OUT     on pout_id.container_rid = stage_OUT.xmeta_repos_object_id_xmeta
where 1=1  and job.DSNAMESPACE_XMETA = 'RBADWH-PE:IFRS9'
  --and job.NAME_XMETA = 'IFRS9_Contract_NonRetail_DST_prod'
  and job.NAME_XMETA = 'IFRS9_Account_Retail_KKR_TRC_PPZ_test_naknade'  
   and
  ( stage_in.name_xmeta in ('T1','ToT1','TB0_ACCOUNT')
  OR stage_OUT.name_xmeta in ('T1','ToT1','TB0_ACCOUNT')
  or  link_in.name_xmeta in ('T1','ToT1','TB0_ACCOUNT'))  
  and link_in.name_xmeta not in ('CUS','overdraft','balance','dpd','hr_default','prekoracenje','rating','wo','interests')
  and  link_in.name_xmeta not in ('KKR','TRC_PPZ') 
      )
, object_hierarchy as
(
 select 
      LPAD (' ', (LEVEL - 1) * 4, ' ') || child_name AS child_name_lev ,      
      child,
      parent,
      child_name,
      parent_name,
      STAGETYPE,
      child object_id
      from (
      select  XMETA_REPOS_OBJECT_ID_XMETA_M3 child,         null parent,                             M3 child_name, null parent_name, STAGETYPE_m3 STAGETYPE, XMETA_REPOS_OBJECT_ID_XMETA_M1 XMETA_REPOS_OBJECT_ID_XMETA from dat
      union all
      select XMETA_REPOS_OBJECT_ID_XMETA_M2 child,          XMETA_REPOS_OBJECT_ID_XMETA_M3   parent, M2 child_name, m3   parent_name, STAGETYPE_m2 STAGETYPE, XMETA_REPOS_OBJECT_ID_XMETA_M2 XMETA_REPOS_OBJECT_ID_XMETA from dat
      union all
      select XMETA_REPOS_OBJECT_ID_XMETA_M1 child,          XMETA_REPOS_OBJECT_ID_XMETA_M2   parent, M1 child_name, m2   parent_name, STAGETYPE_m1 STAGETYPE, XMETA_REPOS_OBJECT_ID_XMETA_M3 XMETA_REPOS_OBJECT_ID_XMETA from dat 
      )      
    CONNECT BY nocycle PRIOR   CHILD = PARENT
    START WITH child_name = 'TB0_ACCOUNT'
)     
, DAT AS
   (   
   select /*+ materialize */
       stage_in.name_xmeta  m1,    
       link_in.name_xmeta  m2,
       stage_OUT.name_xmeta  m3,
       STAGE_IN.STAGETYPE_XMETA    STAGETYPE_m1,
       CAST('LINK' AS NVARCHAR2(4))    STAGETYPE_m2,
       stage_OUT.STAGETYPE_XMETA    STAGETYPE_m3,
       STAGE_IN.XMETA_REPOS_OBJECT_ID_XMETA XMETA_REPOS_OBJECT_ID_XMETA_M1,
       link_in.XMETA_REPOS_OBJECT_ID_XMETA XMETA_REPOS_OBJECT_ID_XMETA_M2,
       stage_OUT.XMETA_REPOS_OBJECT_ID_XMETA XMETA_REPOS_OBJECT_ID_XMETA_M3   
FROM XMETA.datastagex_dsjobdef job
       join XMETA.datastagex_dsstage stage_in     on job.xmeta_repos_object_id_XMETA = stage_in.container_rid
      left join  XMETA.datastagex_dsinputpin pin_id on pin_id.container_rid = stage_in.xmeta_repos_object_id_xmeta
      left  join XMETA.datastagex_dslink link_in on pin_id.xmeta_repos_object_id_xmeta = LINK_IN.TO_INPUTPIN_XMETA 
      left join  XMETA.datastagex_dsoutputpin pout_id on pout_id.xmeta_repos_object_id_xmeta = LINK_IN.FROM_OUTPUTPIN_XMETA    
       LEFT join XMETA.datastagex_dsstage stage_OUT     on pout_id.container_rid = stage_OUT.xmeta_repos_object_id_xmeta
where 1=1  and job.DSNAMESPACE_XMETA = 'RBADWH-PE:IFRS9'
  --and job.NAME_XMETA = 'IFRS9_Contract_NonRetail_DST_prod'
  and job.NAME_XMETA = 'IFRS9_Account_Retail_KKR_TRC_PPZ_test_naknade'  
   and
  ( stage_in.name_xmeta in ('T1','ToT1','TB0_ACCOUNT')
  OR stage_OUT.name_xmeta in ('T1','ToT1','TB0_ACCOUNT')
  or  link_in.name_xmeta in ('T1','ToT1','TB0_ACCOUNT'))  
  and link_in.name_xmeta not in ('CUS','overdraft','balance','dpd','hr_default','prekoracenje','rating','wo','interests')
  and  link_in.name_xmeta not in ('KKR','TRC_PPZ') 
      )
, object_hierarchy as
(
 select 
      LPAD (' ', (LEVEL - 1) * 4, ' ') || child_name AS child_name_lev ,      
      child,
      parent,
      child_name,
      parent_name,
      STAGETYPE,
      child object_id
      from (
      select  XMETA_REPOS_OBJECT_ID_XMETA_M3 child,         null parent,                             M3 child_name, null parent_name, STAGETYPE_m3 STAGETYPE, XMETA_REPOS_OBJECT_ID_XMETA_M1 XMETA_REPOS_OBJECT_ID_XMETA from dat
      union all
      select XMETA_REPOS_OBJECT_ID_XMETA_M2 child,          XMETA_REPOS_OBJECT_ID_XMETA_M3   parent, M2 child_name, m3   parent_name, STAGETYPE_m2 STAGETYPE, XMETA_REPOS_OBJECT_ID_XMETA_M2 XMETA_REPOS_OBJECT_ID_XMETA from dat
      union all
      select XMETA_REPOS_OBJECT_ID_XMETA_M1 child,          XMETA_REPOS_OBJECT_ID_XMETA_M2   parent, M1 child_name, m2   parent_name, STAGETYPE_m1 STAGETYPE, XMETA_REPOS_OBJECT_ID_XMETA_M3 XMETA_REPOS_OBJECT_ID_XMETA from dat 
      )      
    CONNECT BY nocycle PRIOR   CHILD = PARENT
    START WITH child_name = 'TB0_ACCOUNT'
)     
select 
tb8.* , h.object_id,h.*
 from   object_hierarchy h
 left join tb8 on tb8.transformer_XMETA_REPOS_OBJECT_ID_XMETA = h.object_id
 
 left join  XMETA.datastagex_dsstage stage_in     on h.object_id = stage_in.XMETA_REPOS_OBJECT_ID_XMETA
 

      
      
            
     