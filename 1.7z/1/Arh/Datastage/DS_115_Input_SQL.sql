-- 1. prvo dohvatimo sve linkove koji izlaze iz db2 konektora, njihove kontektore (stageove) i job kome pripadaju - tb_jb_out_links
-- 2. izvadimo parametre od linka i tražimo XMLProperties parametar - u njemu može biti sql - tb_lnk_prms
-- 3. izvadimo parametre od stagea i tražimo XMLProperties parametar - u njemu može biti sql - tb_stg_prms
-- 4. parsiramo sql upit iz XMLProperties parametra linka, stagea - tb_all
-- 5. formiramo završni upit, gledamo sql upit iz 3. ili 4. ovisno di ga nađemo
select * from HRAGSL_IN_DB2_JOB_STAGES_us;
/
--CREATE TABLE HRAGSL_IN_DB2_JOB_STAGES_us AS 
-- 1. --
with tb_jb_out_links as (
  select
    lnk.XMETA_REPOS_OBJECT_ID_XMETA link_id,
    JB.DSNAMESPACE_XMETA ds_project,
    jb.CATEGORY_XMETA job_folder,
    stg.name_xmeta stage_name,
    lnk.name_xmeta link_name,
    jb.name_xmeta job_name,
    stg.stagetype_xmeta,
    stg.HAS_OUTPUTPIN_XMETA,
    OUTPUTPINS_XMETA,
    lnk.HAS_PARAMETERVAL_XMETA link_params,
    stg.HAS_PARAMETERVAL_XMETA stage_params,
    1 as jedan
  from xmeta.DATASTAGEX_DSLINK lnk
  left join XMETA.DATASTAGEX_DSOUTPUTPIN out_pin
    on out_pin.XMETA_REPOS_OBJECT_ID_XMETA = lnk.FROM_OUTPUTPIN_XMETA
  left join XMETA.DATASTAGEX_DSSTAGE stg
    on stg.XMETA_REPOS_OBJECT_ID_XMETA = out_pin.CONTAINER_RID
  left join xmeta.DATASTAGEX_DSJOBDEF jb
    on jb.XMETA_REPOS_OBJECT_ID_XMETA = lnk.XMETA_LOCKINGROOT_XMETA
  where 7=7
    --and jb.name_xmeta = 'CollateralWCVvalue' -- ovdi ako ćeš samo jedan job
    --and STAGETYPE_XMETA = 'DB2Connector' -- ovo je tip konektora
    --and regexp_substr(JB.DSNAMESPACE_XMETA,':(.*)',1,1,'n',1) in ('RBADWH30','RBA_Reporting') --  ovdi filtriraj projekte
    and stg.has_inputpin_xmeta is null -- gledamo samo ulazne stageove
    --and lnk.name_xmeta = 'ApplicationForm'
    --and OUTPUTPINS_XMETA like '%|%' -- ako želimo samo stageove koji imaju više izlaznih linkova
    and jb.name_xmeta in (
      'Contract_Balance_Accruals_Merge_D1_HNB'
    )
),
--select * from tb_jb_out_links
--/
-- 2. --
tb_lnk_prms as (
  select
  --  regexp_substr(JB.DSNAMESPACE_XMETA,':(.*)',1,1,'n',1) ds_proj0,
--    tb_jb_out_links.*,
    link_id,
    PARAMETERNAME_XMETA,
    VALUEEXPRESSION_XMETA
  from tb_jb_out_links 
  cross join lateral (
    select
      level lvl,
      to_char(regexp_substr(link_params, '[^[:cntrl:]]+',1,level)) id
    from dual
    connect by level <= regexp_count(link_params, '[^[:cntrl:]]+',1)
  ) cjl
  left join XMETA.DATASTAGEXDSPARAMETRVL prm
    on prm.XMETA_REPOS_OBJECT_ID_XMETA = cjl.id
  
  where 7=7
    -- sql upit se može nalaziti u XMLProperties parametru od linka
    --and prm.PARAMETERNAME_XMETA in ('XMLProperties','USERSQL')
)
--select * from tb_lnk_prms
--/
,
-- 3. --
tb_stg_prms as (
  select
  --  regexp_substr(JB.DSNAMESPACE_XMETA,':(.*)',1,1,'n',1) ds_proj0,
    link_id,
    PARAMETERNAME_XMETA,
    VALUEEXPRESSION_XMETA
  from tb_jb_out_links
  cross join lateral (
    select
      level lvl,
      to_char(regexp_substr(stage_params, '[^[:cntrl:]]+',1,level)) id
    from dual
    connect by level <= regexp_count(stage_params, '[^[:cntrl:]]+',1)
  ) cjl
  left join XMETA.DATASTAGEXDSPARAMETRVL prm
    on prm.XMETA_REPOS_OBJECT_ID_XMETA = cjl.id
  where 7=7
    -- sql upit se može nalaziti u XMLProperties parametru od stagea
    and prm.PARAMETERNAME_XMETA in ('XMLProperties','USERSQL')
),
-- 4. --
tb_all as (
  select
    jol.link_id,
    jol.ds_project,
    jol.job_folder,
    jol.job_name,
    jol.stage_name,
    jol.link_name,
    jol.stagetype_xmeta,
    jol.OUTPUTPINS_XMETA,
    
    tlp.PARAMETERNAME_XMETA lnk_param_name,
    tlp.VALUEEXPRESSION_XMETA lnk_param_value,
    case when tlp.VALUEEXPRESSION_XMETA is not null then
      rtrim(substr(xmltype(tlp.VALUEEXPRESSION_XMETA).EXTRACT('/Properties/Usage/SQL/SelectStatement/text()').getclobval(), 10), ']>')
    else
      null
    end as SelectStatement_lnk,
    
    tsp.PARAMETERNAME_XMETA stg_param_name,
    tsp.VALUEEXPRESSION_XMETA stg_param_value,
    case when tsp.VALUEEXPRESSION_XMETA is not null then
      rtrim(substr(xmltype(tsp.VALUEEXPRESSION_XMETA).EXTRACT('/Properties/Usage/SQL/SelectStatement/text()').getclobval(), 10), ']>')
    else
      null
    end as SelectStatement_stg,
    tlp1.VALUEEXPRESSION_XMETA LNK_USERSQL,
    tsp1.VALUEEXPRESSION_XMETA STG_USERSQL,
    1 as jedan
  from tb_jb_out_links jol -- dohvaćamo sve linkove od db2 konektora i same kontektore, naziv joba
  left join tb_lnk_prms tlp -- spajamo sa paramerima od linkova
    on jol.link_id = tlp.link_id
    and tlp.PARAMETERNAME_XMETA = 'XMLProperties'
  left join tb_lnk_prms tlp1 -- spajamo sa paramerima od linkova
    on jol.link_id = tlp1.link_id
    and tlp1.PARAMETERNAME_XMETA = 'USERSQL'
  left join tb_stg_prms tsp -- spajamo sa paramerima od stageova
    on jol.link_id = tsp.link_id
    and tsp.PARAMETERNAME_XMETA = 'XMLProperties'
  left join tb_stg_prms tsp1 -- spajamo sa paramerima od stageova
    on jol.link_id = tsp1.link_id
    and tsp1.PARAMETERNAME_XMETA = 'USERSQL'
--   sql upit se može nalaziti u parametrima od linka ili u parametrima od stagea u parametru XMLProperties, može još biti i u USERSQL
)
-- 5. --
select
  tb_all.*,
  nvl(tb_all.SelectStatement_lnk,tb_all.SelectStatement_stg) SelectStatement -- uzet ćemo prvo sql upit sa linka, ako ga nema onda uzimamo sa stagea
from tb_all
--select * from tb_lnk_prms;
; 