---------------------------------------------------
-- Dohvaćanje Svih upita za zadani DataStage job --
---------------------------------------------------
/*
 v1.3
    - dodani joinovi kada u transformer ulazi više linkova i join kolone
    - popravljen redoslijed srednjih viewova koji imaju ulaz i izlaz
      - prvo se svi stavljaju u listu kandidata
      - zatim se za svaki provjerava da li su mu već dohvaćeni preduvijeti
      - u 5 iteracija ne nastoji riješiti svih kandidata
    - TODO: povaditi sve kolone kada imamo join
*/
declare
  
  -- naziv joba
  v_job_name varchar2(255) :='poc_sql_test';
  -- naziv projekta
  v_project_name varchar2(255 char) := 'RBADWH30';
  -- putanja direktorija u kojem se nalazi job
  v_folder_path varchar2(255 char) := '\\Jobs\\GROUP1\\Cataloques';
  
  v_job_id  varchar2(333);

  v_kolone varchar(32000);
  v_br_kolona number;
  v_sql varchar2(32000);

  v_insert_dio_sql varchar(32000);

  v_zadnji_with varchar(32000);
  v_trenutni_stage varchar2(200 char);
  
  l_join_tab_no integer;
  l_from_tablica varchar2(255 char);
  
  -- nazivi svih linkova/viewova koji su obrađeni
  TYPE t_view_done_type IS TABLE OF VARCHAR2(100) INDEX BY VARCHAR2(50);
  t_view_done t_view_done_type;
  l_view_name varchar2(100 char);
  
  -- upiti koji nastaju iz transformera, potrebno provjeriti preduvijete
  -- key:= idtransformera_imeLinkaViewa, value:= sql upit
  TYPE t_view_todo_type IS TABLE OF VARCHAR2(32000) INDEX BY VARCHAR2(150 char);
  t_view_todo t_view_todo_type;
  l_view_name_todo varchar2(150 char);
  
  l_view_sql varchar2(32000 char);
  
  l_deps_ok integer := 0;
begin

  
  --id joba 'c2e76d84.43058877.69l7j7vm6.pbj49l1.298v9a.bpf3vupqsg69u7fr669a4'

  --dohvat joba
  select
  --  jb.DSNAMESPACE_XMETA ds_namespace,
  --  dsp.HOSTNAME_XMETA host_name,
  --  dsp.NAME_XMETA project_name,
  --  jb.NAME_XMETA job_name,
  --  jb.CATEGORY_XMETA job_folder_path,
    jb.XMETA_REPOS_OBJECT_ID_XMETA job_id
  into v_job_id
  -- DS Job --
  from xmeta.DATASTAGEX_DSJOBDEF jb
  -- DS Project --
  left join xmeta.DATASTAGEX_DSPROJECT dsp
    on jb.DSNAMESPACE_XMETA = dsp.HOSTNAME_XMETA || ':' || dsp.NAME_XMETA
  where 1=1
    and jb.NAME_XMETA = v_job_name
    and dsp.NAME_XMETA = v_project_name
    and jb.CATEGORY_XMETA = v_folder_path
  ;
  --dbms_output.put_line(v_job_id);
  
  
  v_sql :='with '||CHR(10);
  
  ---------------------------------------------------
  --1. početni objekti samo ima output, nema input
  -- nemaaju HAS_INPUTPIN_XMETA
  ---------------------------------------------------
  for stg in (
    
    select
      stg.NAME_XMETA,
      stg.HAS_INPUTPIN_XMETA,
      li_out.NAME_XMETA naziv_oupt_linka ,
      nvl (
        case when replace(  TO_CHAR( SUBSTR (prm.VALUEEXPRESSION_XMETA,0,3999)),'',''  ) is not null then
          substr( replace(XMLTYPE(replace(  TO_CHAR( SUBSTR (prm.VALUEEXPRESSION_XMETA,0,3999)),'',''  )).EXTRACT('//Usage/SQL/SelectStatement/text()').getStringVal(),']]>'),10)
        end
        , 'select '|| kol.kolone  ||' from  tmp_HASH_'||stg.NAME_XMETA
      ) select_prvi_dio,
      stg.XMETA_REPOS_OBJECT_ID_XMETA,
      stg.CONTAINS_FLOWVARIABLE_XMETA  ,
      kol.kolone
      -- DS Stage
      from xmeta.DATASTAGEX_DSSTAGE  stg
      -- DS Link
      join XMETA.DATASTAGEX_DSLINK li_out
        on stg.CONTAINER_RID = li_out.CONTAINER_RID
        and replace(  TO_CHAR( SUBSTR (stg.HAS_OUTPUTPIN_XMETA,0,3999)),'',''  )  like '%'||nvl(li_out.FROM_OUTPUTPIN_XMETA,'-1')||'%'
      -- DS Parameter value
      left join xmeta.DATASTAGEXDSPARAMETRVL prm
        ON stg.XMETA_REPOS_OBJECT_ID_XMETA = prm.CONTAINER_RID
        and prm.PARAMETERNAME_XMETA = 'XMLProperties'
        and replace(TO_CHAR( SUBSTR (stg.HAS_OUTPUTPIN_XMETA,0,3999)),'','') like '%'||nvl(li_out.FROM_OUTPUTPIN_XMETA,'-1')||'%'
      -- DS columns
      left join (
        select 
          count(1) br_kolona,
          LISTAGG(a.NAME_XMETA,',') WITHIN GROUP( ORDER BY 1) AS kolone,
          a.CONTAINER_RID
        from  xmeta.DATASTAGEXDSFLOWVARIBL  a
        where 1=1
        group by a.CONTAINER_RID
      ) kol
        on kol.CONTAINER_RID = li_out.XMETA_REPOS_OBJECT_ID_XMETA
      where 1=1 
        and stg.CONTAINER_RID = v_job_id
        and stg.HAS_INPUTPIN_XMETA is null
      order by stg.XMETA_OPTIMISTIC_LOCK_ID_XMETA
      
  ) loop
  
    --za svaki početni objekt
    --dohvati kolone v_kolone varchar(32000);  v_br_kolona number;
    
    v_sql := v_sql || 'vw_'||stg.naziv_oupt_linka || '  as ('
      || replace(CHR(10)||'-- kolone '||stg.kolone||CHR(10)|| stg.select_prvi_dio, chr(10), chr(10) || '  ')
      || CHR(10) || '), '||CHR(10)||CHR(10)
    ;
    
    t_view_done('vw_'||stg.naziv_oupt_linka) := 'ima';
    
    v_zadnji_with :=stg.naziv_oupt_linka;
      
  end loop;
  
  ---------------------------------------------------
  -- 2. srednji objekti input i output
  -- imaju HAS_INPUTPIN_XMETA, HAS_OUTPUTPIN_XMETA
  -- transformeri mogu imati više ulaza
  -- više ulaza se spaja (join) po redoslijedu
  ---------------------------------------------------
  for stg_rec in (
    select 
      stg.NAME_XMETA,
      stg.HAS_INPUTPIN_XMETA,
      li_out.NAME_XMETA naziv_oupt_linka,
      kol.kolone,
      'joinovi 'joins,
      stg.XMETA_REPOS_OBJECT_ID_XMETA stage_id
      --,a.* 
      -- li_out.*
    -- DS Stage
    from xmeta.DATASTAGEX_DSSTAGE  stg
    -- DS Link
    left join XMETA.DATASTAGEX_DSLINK li_out
      on stg.CONTAINER_RID = li_out.CONTAINER_RID
      and replace(TO_CHAR( SUBSTR (stg.HAS_OUTPUTPIN_XMETA,0,3999)),'','') like '%'||nvl(li_out.FROM_OUTPUTPIN_XMETA,'-1')||'%'
    -- DS columns
    join (
      select 
        '  ' || 
        LISTAGG(
          nvl(a.SOURCECOLUMNID_XMETA, TO_CHAR( SUBSTR (b.PARSEDEXPRESSION_XMETA,0,3999)))||' as '||a.NAME_XMETA
          , ',' || CHR(10) || '  '
        ) WITHIN GROUP( ORDER BY 1 ) AS kolone,
        a.CONTAINER_RID
      from xmeta.DATASTAGEXDSFLOWVARIBL a
      left join XMETA.DATASTAGEXDSDERIVATION b 
        on a.XMETA_LOCKINGROOT_XMETA = b.XMETA_LOCKINGROOT_XMETA 
        and replace (TO_CHAR( SUBSTR (a.HASVALUE_DERIVATION_XMETA,0,3999)),'',''  ) = b.XMETA_REPOS_OBJECT_ID_XMETA
      where 1=1 
        and a.XMETA_LOCKINGROOT_XMETA=v_job_id --job id
        -- and a.CONTAINER_RID='c2e76d84.78bf4d29.69l7j7vv5.bbkhj1m.7865ue.cb2k83i2oegoc7mb2fgha' --link id
      group by a.CONTAINER_RID 
    ) kol
      on kol.CONTAINER_RID = li_out.XMETA_REPOS_OBJECT_ID_XMETA
    where 1=1 
      and stg.CONTAINER_RID = v_job_id
      and stg.HAS_INPUTPIN_XMETA is not null  
      and stg.HAS_OUTPUTPIN_XMETA is not null
  ) loop
    
    l_view_sql := '';
    
    l_view_sql := l_view_sql || 'vw_'|| stg_rec.naziv_oupt_linka || '  as (' 
      || replace(CHR(10) || 'select ' || CHR(10) || stg_rec.kolone || CHR(10), chr(10), chr(10) || '  ')
    ;
    
    -- prvo idu tablice koje imaju kolone bez join kolona
    -- zatom idu tablice sa join kolonama
    
    --t_view_done('vw_'||stg_rec.naziv_oupt_linka) := 'ima';
      
    -----------------------------
    -- join tablice i kolone --
    -----------------------------
    l_join_tab_no := 0;
    
    -- from tablica iz joinova
    -- uzimamo prvi link od svih ulaza u transformer
    -- prvi link je prvi ID linka u listi stg.HAS_INPUTPIN_XMETA (prvi znak je SOH/CHR(1) a zatim ide ID od linka)
    select
      ' vw_' || li_from.NAME_XMETA from_table
    into
      l_from_tablica
    from xmeta.DATASTAGEX_DSSTAGE stg
    left join XMETA.DATASTAGEX_DSLINK li_from
      on instr(stg.HAS_INPUTPIN_XMETA, li_from.TO_INPUTPIN_XMETA) = 2
    where 1=1 
      and stg.CONTAINER_RID = v_job_id -- job_id
      and stg.XMETA_REPOS_OBJECT_ID_XMETA = stg_rec.stage_id -- stage_id
    ;
    
    l_view_sql := l_view_sql ||  'from ' || l_from_tablica || chr(10);
    --v_sql := v_sql || l_view_sql;
    --v_sql := v_sql || 'from ' || l_from_tablica || chr(10);
    
    -- TODO: ovdje bi trebali uzeti sve tablice koje nemaju join kolone, tako da ih joinamo sa 1=1
    
    -- sada uzimamo sve tablice koji imaju join kolone
    for jot in (
      select
        'left join vw_' || li_in.NAME_XMETA || /* '_' || stg.INTERNALID_XMETA || */ chr(10) || '    on ' 
        || LISTAGG(
          li_in.NAME_XMETA || '.' || fv.NAME_XMETA || ' = ' || nvl(der.PARSEDEXPRESSION_XMETA, 'null') , chr(10) || '    and '
        ) WITHIN GROUP(ORDER BY 1 ) AS join_statement,
        ' vw_' || li_from.NAME_XMETA from_table
        --|| '_' || stg.INTERNALID_XMETA from_table
      from xmeta.DATASTAGEX_DSSTAGE stg
      left join XMETA.DATASTAGEX_DSLINK li_from
        on instr(stg.HAS_INPUTPIN_XMETA, li_from.TO_INPUTPIN_XMETA) = 2
      left join XMETA.DATASTAGEX_DSLINK li_in
        on instr(stg.HAS_INPUTPIN_XMETA, li_in.TO_INPUTPIN_XMETA) > 2
        --and li_in.XMETA_LOCKINGROOT_XMETA='c2e76d84.43058877.69l7j7vm6.pbj49l1.298v9a.bpf3vupqsg69u7fr669a4'
      left join xmeta.DATASTAGEXDSFLOWVARIBL fv
        on fv.container_rid = li_in.XMETA_REPOS_OBJECT_ID_XMETA
      join xmeta.DATASTAGEXDSDERIVATION der
        on fv.HASLOOKUP_DERIVATION_XMETA is not null
        and instr(fv.HASLOOKUP_DERIVATION_XMETA, der.XMETA_REPOS_OBJECT_ID_XMETA) >= 1 -- HASLOOKUP_DERIVATION_XMETA iz DATASTAGEXDSFLOWVARIBL tablice
      where 1=1 
        --and stg.CONTAINER_RID='c2e76d84.43058877.69l7ufqvf.hj3u43n.of8p56.49nrfaqn9bhjigp1kisdl' -- job_id
        and stg.CONTAINER_RID = v_job_id -- job_id
        --and stg.XMETA_REPOS_OBJECT_ID_XMETA='c2e76d84.9f91cbaf.69l7ufr26.nku319a.7h8jrk.rh6831u8qcu2sf01g84id' -- stage_id
        and stg.XMETA_REPOS_OBJECT_ID_XMETA = stg_rec.stage_id -- stage_id
      group by 
        li_from.NAME_XMETA,
        stg.XMETA_REPOS_OBJECT_ID_XMETA,
        li_in.NAME_XMETA,
        stg.INTERNALID_XMETA
    ) loop
      --l_join_tab_no := l_join_tab_no + 1;
      
      l_view_sql := l_view_sql || '  ' || jot.join_statement || chr(10);
      
      --v_sql := v_sql || l_view_sql;
      --v_sql := v_sql || jot.join_statement || chr(10);
    end loop;
    
    --v_sql := v_sql || '),' || chr(10) || chr(10);
    l_view_sql := l_view_sql || '),' || chr(10) || chr(10);
    
    -- ubaci sql u listu a poslije ćemo ih vaditi ovisno o zadovoljenim preduvijetima
    t_view_todo('vw_'||stg_rec.naziv_oupt_linka || '|' || stg_rec.stage_id) := l_view_sql;
    
    --------------------------------
    -- KRAJ join tablice i kolone --
    --------------------------------
    
    --v_sql := v_sql || l_view_sql;
    
    --v_sql :=rtrim(v_sql,', '||CHR(10)||CHR(10))||CHR(10)||CHR(10) ;
    
    v_zadnji_with :=stg_Rec.naziv_oupt_linka;
    
  end loop;
  
  ---------------------------------------------------
  --3. insert dio - stage nema HAS_OUTPUTPIN_XMETA --
  ---------------------------------------------------
  
  select
    nvl (
      case when replace(TO_CHAR( SUBSTR (prm.VALUEEXPRESSION_XMETA,0,3999)),'','') is not null then
        substr(
          replace(
            XMLTYPE(replace(TO_CHAR( SUBSTR (prm.VALUEEXPRESSION_XMETA,0,3999)),'',''  ))
              .EXTRACT('//Usage/SQL/InsertStatement/text()').getStringVal(),']]>'
          )
          ,10
          ,instr(replace(XMLTYPE(replace(  TO_CHAR( SUBSTR (prm.VALUEEXPRESSION_XMETA,0,3999)),'',''  )).EXTRACT('//Usage/SQL/InsertStatement/text()').getStringVal(),']]>'),'VALUES')-10
        )
      end
      ,'insert into '||stg.NAME_XMETA
    ) insert_prvi_dio,
    stg.XMETA_REPOS_OBJECT_ID_XMETA stage_id
  into 
    v_insert_dio_sql, 
    v_trenutni_stage
  -- DS Stage
  from xmeta.DATASTAGEX_DSSTAGE  stg
  -- DS Stage parameters
  left join xmeta.DATASTAGEXDSPARAMETRVL prm
    ON stg.XMETA_REPOS_OBJECT_ID_XMETA = prm.CONTAINER_RID
    AND prm.PARAMETERNAME_XMETA = 'XMLProperties'
  where 1=1 
    and stg.CONTAINER_RID=v_job_id
    and stg.HAS_OUTPUTPIN_XMETA is null
  ;
  
  -- TODO: zamijeniti from sa nazivom ulaznog linka
  -- tražimo naziv ulaznog linka, to nam je view iz koje radmo select
  select
      ' vw_' || li_from.NAME_XMETA from_table
    into
      l_from_tablica
    from xmeta.DATASTAGEX_DSSTAGE stg
    left join XMETA.DATASTAGEX_DSLINK li_from
      on instr(stg.HAS_INPUTPIN_XMETA, li_from.TO_INPUTPIN_XMETA) = 2
    where 1=1 
      and stg.CONTAINER_RID = v_job_id -- job_id
      and stg.XMETA_REPOS_OBJECT_ID_XMETA = v_trenutni_stage -- stage_id
    ;
  
  
  --dbms_output.put_line(chr(10) || chr(10) || '---------------upitni viewovi---------------');

  for iter in 1 .. 5 loop
    -- ispiši sve linkove/viewove koje smo obradili
    l_view_name_todo := t_view_todo.FIRST;
    
    WHILE l_view_name_todo IS NOT NULL LOOP
      --dbms_output.put_line(l_view_name || ': ' || t_view_done(l_view_name));
      --dbms_output.put_line(l_view_name_todo);
      --dbms_output.put_line(t_view_todo(l_view_name_todo));
      
      -- ako view nije u listi obrađenih vidi da li su mu preduvijeti zadovoljeni da se prebaci
      -- substr vadi samo naziv viewa iz l_view_name_todo koje je spoj view_name|stg_id
      if not t_view_done.exists(substr(l_view_name_todo, 1, instr(l_view_name_todo, '|')-1)) then
        -- provjeravamo da li su svi viewovi iz from dijela već u prethodnom upit
        l_deps_ok := 1;
        
        for rec in (
          select
            stg.NAME_XMETA,
            'vw_' || li_from.NAME_XMETA vw_name
            --LISTAGG('vw_' || li_from.NAME_XMETA, ',') WITHIN GROUP( ORDER BY 1 ) AS chk_links
          from xmeta.DATASTAGEX_DSSTAGE  stg
          left join XMETA.DATASTAGEX_DSLINK li_from
            on instr(stg.HAS_INPUTPIN_XMETA, li_from.TO_INPUTPIN_XMETA) >= 1
          where stg.XMETA_REPOS_OBJECT_ID_XMETA = substr(l_view_name_todo, instr(l_view_name_todo, '|')+1) -- vadimo ID od stagea: view_name|id_stagea
          --group by stg.NAME_XMETA
        ) loop
          
          if not t_view_done.exists(rec.vw_name) then
            --dbms_output.put_line(rec.vw_name || ' - NOK');
            l_deps_ok := 0;
          end if;
        end loop;
        
        if l_deps_ok = 1 then
          v_sql := v_sql || chr(10) || '---- ' || iter || chr(10);
          -- ubaci sql upit u izlaz
          -- vsql := vsql || t_view_todo(instr(l_view_name_todo, '|')-1))
          v_sql := v_sql ||  t_view_todo(l_view_name_todo);
          --dbms_output.put_line(t_view_todo(l_view_name_todo));
          --dbms_output.put_line('ubaci naziv viewa u listu odrađenih: ' || substr(l_view_name_todo, 1, instr(l_view_name_todo, '|')-1));
          -- ubaci naziv viewa u listu odrađenih
          t_view_done(substr(l_view_name_todo, 1, instr(l_view_name_todo, '|')-1)) := 'ima';
          null;
        end if;
      end if;
      
      -- idi na idući view kandidat
      l_view_name_todo := t_view_todo.NEXT(l_view_name_todo);
    
    END LOOP; -- while end
    
  end loop; -- iter end
  
  
  
  --dbms_output.put_line('------------------------------');
  
  --dbms_output.put_line(chr(10) || chr(10) || '---------------obrađeni viewovi---------------');
  -- ispiši sve linkove/viewove koje smo obradili
  l_view_name := t_view_done.FIRST;
  WHILE l_view_name IS NOT NULL LOOP
    --dbms_output.put_line(l_view_name || ': ' || t_view_done(l_view_name));
    --dbms_output.put_line(l_view_name);
    l_view_name := t_view_done.NEXT(l_view_name);
  END LOOP;
  --dbms_output.put_line('------------------------------');
  
  -- nakon što smo dodali sve linkove koji izlaze iz transformera, ubacujemo insert dio
  -- izbaci zadnji zarez
  v_sql := rtrim(v_sql, ',' || chr(10) || chr(10));
  
  -- insert dio
  v_sql := v_sql ||  chr(10) || chr(10) || v_insert_dio_sql ||CHR(10)|| 'select * from '||l_from_tablica;
  
  -- ispiši upite
  dbms_output.put_line(v_sql);
  
end;