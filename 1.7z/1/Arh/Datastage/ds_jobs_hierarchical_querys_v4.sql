with pro as
(
select 'RBADWH-P:IFRS9' project_name  from dual  
),
sqls as
(
SELECT 
   J.NAME_XMETA     JOB_NAME
  , S.NAME_XMETA    STAGE_NAME
  , S.HAS_INPUTPIN_XMETA 
  , S.HAS_OUTPUTPIN_XMETA  
  ,J.DSNAMESPACE_XMETA project_name
  ,S.STAGETYPE_XMETA STAGETYPE
  , substr(XMLTYPE(VALUEEXPRESSION_XMETA).EXTRACT('//Properties/Usage/SQL/SelectStatement/text()').getClobVal(),10) SELECT_STATEMENT   
  , substr(XMLTYPE(VALUEEXPRESSION_XMETA).EXTRACT('//Properties/Usage/SQL/InsertStatement/text()').getClobVal(),10) INSERT_STATEMENT
  , substr(XMLTYPE(VALUEEXPRESSION_XMETA).EXTRACT('//Properties/Usage/SQL/UpdateStatement/text()').getClobVal(),10) UPDATE_STATEMENT
  , substr(XMLTYPE(VALUEEXPRESSION_XMETA).EXTRACT('//Properties/Usage/SQL/DeleteStatement/text()').getClobVal(),10) DELETE_STATEMENT
FROM XMETA.DATASTAGEX_DSSTAGE s
cross join pro
INNER JOIN XMETA.DATASTAGEX_DSJOBDEF J
ON  S.CONTAINER_RID = J.XMETA_REPOS_OBJECT_ID_XMETA
LEFT JOIN XMETA.DATASTAGEXDSPARAMETRVL V
ON  S.XMETA_REPOS_OBJECT_ID_XMETA = V.CONTAINER_RID
    AND V.PARAMETERNAME_XMETA = 'XMLProperties'    
WHERE 
1=1
 and J.DSNAMESPACE_XMETA = pro.project_name
    AND S.STAGETYPE_XMETA like '%Connector'
    AND XMLTYPE(VALUEEXPRESSION_XMETA).EXISTSNODE('//Properties/Usage/SQL/*') = 1
)
--
--
--
, TB1
     AS (SELECT *
           FROM (-- za sve ni�e na�ene kompajle tra�imo zadnje pokretanje
                 SELECT T1.JOBID,
                        T1.JOBNAME,
                        JR.CREATIONTIMESTAMP,
                        JR.RUNSTARTTIMESTAMP,
                        JR.RUNENDTIMESTAMP,
                        JR.ELAPSEDRUNSECS,
                        JR.RUNTYPE,
                        JR.RUNMAJORSTATUS,
                        JR.RUNMINORSTATUS,
                        JR.ISUSERNAME,
                        JR.DSUSERNAME,
                        ROW_NUMBER ()
                        OVER (PARTITION BY JR.JOBID
                              ORDER BY JR.CREATIONTIMESTAMP DESC)
                           RN_RUN,              -- uzimamo samo zadnje vrijeme
                        1 AS JEDAN
                   FROM (-- tra�imo zadnje vrijeme kompaliranja za sve jobove te iz toga dohva�amo jobid
                         SELECT *
                           FROM (SELECT JOBID,
                                        JOBNAME,
                                        COMPILATIONTIMESTAMP,
                                        ROW_NUMBER ()
                                        OVER (
                                           PARTITION BY JOBNAME
                                           ORDER BY COMPILATIONTIMESTAMP DESC)
                                           RN   -- uzimamo samo zadnje vrijeme
                                   FROM DSODB.JOBEXEC
                                        cross join pro
                                   where PROJECTNAME =  pro.project_name
                                   )
                          WHERE RN = 1          -- uzimamo samo zadnje vrijeme
                                      ) T1
                        LEFT JOIN DSODB.JOBRUN JR ON JR.JOBID = T1.JOBID)
          WHERE RN_RUN = 1                            -- uzimamo samo zadnje vrijeme
                          )
    SELECT ROWNUM AS RNO,
           --lpad(JOB_NAME, level*2,' ') JOB_NAME_h,
           LPAD (' ', (LEVEL - 1) * 4, ' ') || dat.JOB_NAME AS JOB_NAME_h,
           --(select ELAPSEDRUNSECS from   TB1 where 1=1 and  TB1.JOBNAME = dat.JOB_NAME) last_job_duration_sec,
           dat.JOB_NAME,
           dat.PAR_JOB_NAME,
           dat.stage_name,
           -- dat.PROJECT_C,
           dat.PAR_PROJECT,
           LEVEL LEV,
           SYS_CONNECT_BY_PATH (dat.PAR_JOB_NAME, '/') PATH1,
           dat.sub_order,
           dat.STAGETYPECLASSNAME_XMETA,
           dat.SHORTDESCRIPTION_XMETA,
           dat.longDESCRIPTION_XMETA
           --
           -- sqls
           --     
           ,sqls.STAGETYPE
           ,sqls.SELECT_STATEMENT
                    ,sqls.INSERT_STATEMENT
                    ,sqls.update_STATEMENT
                    ,sqls.delete_STATEMENT      
      --dat.stage_name
      FROM (
      SELECT 
      COALESCE(OBJ.JOBNAME_XMETA,OBJ.NAME_XMETA) AS JOB_NAME,
      --OBJ.JOBNAME_XMETA AS JOB_NAME,
                   OBJ.NAME_XMETA stage_name,
                   COALESCE(JOBS.NAME_XMETA,OBJ.NAME_XMETA ) AS PAR_JOB_NAME,
                   --JOBS.NAME_XMETA AS PAR_JOB_NAME,
                   JOBS.DSNAMESPACE_XMETA PAR_PROJECT,                 
                   obj.internalid_xmeta sub_order,
                   OBJ.STAGETYPECLASSNAME_XMETA,
                    OBJ.NAME_XMETA,
                    obj.has_inputpin_xmeta,
                    obj.has_outputpin_xmeta,
                    obj.internalid_xmeta,
                    obj.nextid_xmeta,
                    obj.SHORTDESCRIPTION_XMETA,
                    obj.longDESCRIPTION_XMETA
                    --oBJ.STAGETYPECLASSNAME_XMETA                   
                    --obj.inputpin_xmeta
                    --obj.outputpin_xmeta
              FROM XMETA.DATASTAGEX_DSSTAGE OBJ,
                   XMETA.DATASTAGEX_DSJOBDEF JOBS,
                   XMETA.DATASTAGEX_DSJOBDEF JOBS2,
                   pro
             WHERE     OBJ.OF_JOBDEF_XMETA = JOBS.XMETA_REPOS_OBJECT_ID_XMETA
                   --AND OBJ.STAGETYPECLASSNAME_XMETA = 'JSJobActivity'
                   AND OBJ.OF_JOBDEF_XMETA = JOBS2.XMETA_REPOS_OBJECT_ID_XMETA                       
                   AND JOBS.DSNAMESPACE_XMETA = pro.project_name                  
                   ) DAT
             left join sqls on sqls.stage_name = dat.stage_name and sqls.job_name = dat.PAR_JOB_NAME and sqls.project_name= dat.PAR_PROJECT
                   --CONNECT BY NOCYCLE PRIOR DAT.JOB_NAME = DAT.PAR_JOB_NAME
                   --START WITH PAR_JOB_NAME IN ('ExportDataSeq')             
--
--
--             
CONNECT BY NOCYCLE PRIOR dat.JOB_NAME = dat.PAR_JOB_NAME
START WITH PAR_JOB_NAME IN ('IFRS9_Retail_WithCopy_PROD')
--START WITH PAR_JOB_NAME IN ('ExportDataSeq')
order siblings by sub_order desc



