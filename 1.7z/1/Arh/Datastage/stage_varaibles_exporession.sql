WITH ifrs9_jobs
     AS (SELECT DISTINCT JOB_NAME, XMETA_REPOS_OBJECT_ID_XMETA, PATH
           FROM (    SELECT COALESCE (JOBS.XMETA_REPOS_OBJECT_ID_XMETA,
                                      JOBS2.XMETA_REPOS_OBJECT_ID_XMETA)
                               AS XMETA_REPOS_OBJECT_ID_XMETA,
                            COALESCE (OBJ.JOBNAME_XMETA, OBJ.NAME_XMETA)
                               AS JOB_NAME,
                            --OBJ.JOBNAME_XMETA AS JOB_NAME,
                            OBJ.NAME_XMETA stage_name,
                            COALESCE (JOBS.NAME_XMETA, OBJ.NAME_XMETA)
                               AS PAR_JOB_NAME,
                            SYS_CONNECT_BY_PATH (
                               COALESCE (OBJ.JOBNAME_XMETA, OBJ.NAME_XMETA),
                               '/')
                               PATH,
                            --JOBS.NAME_XMETA AS PAR_JOB_NAME,
                            JOBS.DSNAMESPACE_XMETA PAR_PROJECT,
                            obj.internalid_xmeta sub_order,
                            OBJ.STAGETYPECLASSNAME_XMETA,
                            OBJ.NAME_XMETA
                       FROM XMETA.DATASTAGEX_DSSTAGE OBJ,
                            XMETA.DATASTAGEX_DSJOBDEF JOBS,
                            XMETA.DATASTAGEX_DSJOBDEF JOBS2
                      WHERE     OBJ.OF_JOBDEF_XMETA =
                                   JOBS.XMETA_REPOS_OBJECT_ID_XMETA
                            --AND OBJ.STAGETYPECLASSNAME_XMETA = 'JSJobActivity'
                            AND OBJ.OF_JOBDEF_XMETA =
                                   JOBS2.XMETA_REPOS_OBJECT_ID_XMETA
                            AND 'RBADWH-PE:IFRS9' = JOBS.DSNAMESPACE_XMETA
                            AND JOBS.DSNAMESPACE_XMETA = JOBS2.DSNAMESPACE_XMETA
                 --AND JOBS.DSNAMESPACE_XMETA = pro.project_name
                 CONNECT BY NOCYCLE PRIOR COALESCE (OBJ.JOBNAME_XMETA,
                                                    OBJ.NAME_XMETA) =
                                       COALESCE (JOBS.NAME_XMETA,
                                                 OBJ.NAME_XMETA)
                 START WITH COALESCE (JOBS.NAME_XMETA, OBJ.NAME_XMETA) IN ('IFRS9_Retail_WithCopy_PROD',
                                                                           'IFRS9_NonRetail_WithCopy_PROD'))
          WHERE 1 = 1 
            AND STAGETYPECLASSNAME_XMETA IN ('JSJobActivity'))
SELECT J.NAME_XMETA job_name,
       DBMS_LOB.SUBSTR (d.STAGEVARS_XMETA, 500) expression_name,
       DBMS_LOB.SUBSTR (D.EXPRESSION_XMETA, 500) expression_code
  --,D.*
  FROM XMETA.DATASTAGEXDSDERIVATION d
       JOIN XMETA.DATASTAGEX_DSJOBDEF j
          ON J.XMETA_REPOS_OBJECT_ID_XMETA = D.XMETA_LOCKINGROOT_XMETA
 WHERE     1 = 1
       --and dbms_lob.substr(STAGEVARS_XMETA,500) ='LLimitExpiryDate'
       AND DBMS_LOB.SUBSTR (d.STAGEVARS_XMETA, 500) !=
              DBMS_LOB.SUBSTR (D.EXPRESSION_XMETA, 500)
       --WHERE STAGEVARS_XMETA  like 'LAllocationBasis'
       AND J.NAME_XMETA IN (SELECT s.job_name
                              FROM ifrs9_jobs s)