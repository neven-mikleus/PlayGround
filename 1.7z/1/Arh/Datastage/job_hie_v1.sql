
WITH obj
     AS (SELECT CASE
                   WHEN jobs.JOBTYPE_XMETA IN ('2', '3')
                   THEN
                      OBJ.jobNAME_XMETA
                   WHEN jobs.JOBTYPE_XMETA IN ('1')
                   THEN
                      obj.NAME_XMETA
                END
                   AS job_name,
                JOBS.NAME_XMETA AS par_JOB_NAME,
                JOBS.DSNAMESPACE_XMETA AS par_project,
                jobs.JOBTYPE_XMETA,
                obj.NAME_XMETA,
                OBJ.SUBTYPE_XMETA,
                OBJ.STAGETYPE_XMETA,
                V.VALUEEXPRESSION_XMETA VALUEEXPRESSION_XMETA_sql2,
                CASE
                   WHEN     OBJ.STAGETYPE_XMETA IN ('OracleConnector',
                                                    'DB2Connector')
                        AND V.VALUEEXPRESSION_XMETA IS NOT NULL
                   THEN
                      XMLTYPE (V.VALUEEXPRESSION_XMETA)
                   --DBMS_LOB.SUBSTR(V.VALUEEXPRESSION_XMETA,500,1)
                   ELSE
                      xmltype('<a></a>')
                END
                   AS VALUEEXPRESSION_XMETA_sql
           FROM xmeta.DATASTAGEX_DSSTAGE OBJ
                LEFT JOIN xmeta.DATASTAGEX_DSJOBDEF JOBS
                   ON OBJ.OF_JOBDEF_XMETA = JOBS.XMETA_REPOS_OBJECT_ID_XMETA
                LEFT JOIN xmeta.DATASTAGEXDSPARAMETRVL V
                   ON     OBJ.XMETA_REPOS_OBJECT_ID_XMETA = V.CONTAINER_RID
                      AND V.PARAMETERNAME_XMETA = 'XMLProperties'
          --where 1=1 and JOBS.NAME_XMETA = 'IFRS9_Retail_New'
          WHERE     1 = 1
                AND STAGETYPE_XMETA IN ('CJobActivity',
                                        'OracleConnector',
                                        'DB2Connector',
                                        'CHashedFileStage')
         UNION ALL
         SELECT JOBS.NAME_XMETA job_name,
                NULL par_JOB_NAME,
                NULL par_project,
                NULL JOBTYPE_XMETA,
                NULL NAME_XMETA,
                NULL SUBTYPE_XMETA,
                NULL STAGETYPE_XMETA,
                null VALUEEXPRESSION_XMETA_sql2,
                NULL VALUEEXPRESSION_XMETA_sql
           FROM xmeta.DATASTAGEX_DSJOBDEF JOBS--where 1=1 and JOBS.NAME_XMETA = 'IFRS9_Retail_New'
        )
    SELECT obj.par_project,
           obj.par_JOB_NAME as parent_job,
           obj.job_name as name ,
           JOBTYPE_XMETA,
           NAME_XMETA,
           SUBTYPE_XMETA,
           STAGETYPE_XMETA as stage_type,
           VALUEEXPRESSION_XMETA_sql2,
           VALUEEXPRESSION_XMETA_sql,         
           --XMLTYPE(REPLACE(REPLACE(VALUEEXPRESSION_XMETA_sql,'<![CDATA[',''),']]>','')).EXTRACT('/main/Properties/Usage/SQL/SelectStatement/text()').GETSTRINGVAL() XX,
           --XMLTYPE(VALUEEXPRESSION_XMETA_sql).EXTRACT('/main/Properties/Usage/SQL/SelectStatement/text()').GETSTRINGVAL() XX,
           LEVEL lev,
           SYS_CONNECT_BY_PATH (JOB_NAME, '/') PATH
      FROM obj
CONNECT BY NOCYCLE PRIOR job_name = par_job_name
START WITH job_name IN --('IFRS9_Retail_WithCopy_PROD')
           ('IFRS9_Retail_New')