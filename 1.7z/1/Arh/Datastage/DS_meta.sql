SELECT /*+ FULL(v) USE_HASH(v)*/
J.NAME_XMETA    JOB_NAME
  , S.NAME_XMETA    STAGE_NAME
  , S.HAS_INPUTPIN_XMETA
  , S.HAS_OUTPUTPIN_XMETA
  ,VALUEEXPRESSION_XMETA
  ,S.XMETA_REPOS_OBJECT_ID_XMETA
  FROM xmeta.DATASTAGEX_DSSTAGE s
  inner join xmeta.DATASTAGEX_DSJOBDEF j
  on  S.CONTAINER_RID = J.XMETA_REPOS_OBJECT_ID_XMETA
LEFT JOIN xmeta.DATASTAGEXDSPARAMETRVL V
ON  S.XMETA_REPOS_OBJECT_ID_XMETA = V.CONTAINER_RID
 WHERE  1=1
   and upper(VALUEEXPRESSION_XMETA) LIKE '%''HRK''%'
 --and J.NAME_XMETA = 
order by 2;


SELECT /*+ FULL(v) USE_HASH(v)*/
J.NAME_XMETA    JOB_NAME
  , S.NAME_XMETA    STAGE_NAME
  , S.HAS_INPUTPIN_XMETA
  , S.HAS_OUTPUTPIN_XMETA
  ,VALUEEXPRESSION_XMETA
  ,S.XMETA_REPOS_OBJECT_ID_XMETA
  FROM xmeta.DATASTAGEX_DSSTAGE s
  inner join xmeta.DATASTAGEX_DSJOBDEF j
  on  S.CONTAINER_RID = J.XMETA_REPOS_OBJECT_ID_XMETA
LEFT JOIN xmeta.DATASTAGEXDSPARAMETRVL V
ON  S.XMETA_REPOS_OBJECT_ID_XMETA = V.CONTAINER_RID
 WHERE  1=1
   and upper(VALUEEXPRESSION_XMETA) LIKE '%DEDUCT%'
 --and J.NAME_XMETA = 
order by 2;






---- za hasth na 3.0-------------
SELECT OBJ.NAME_XMETA AS OBJECT_NAME,
            OBJ.STAGETYPECLASSNAME_XMETA AS OBJECT_TYPE,
            JOBS.NAME_XMETA AS JOB_NAME,
            case WHEN inputpins_xmeta IS NOT NULL AND  outputpins_xmeta IS NOT NULL THEN 'INPUT / OUTPUT'
            when inputpins_xmeta is not null then 'INPUT'
                    WHEN outputpins_xmeta IS NOT NULL THEN 'OUTOUT'
                                        ELSE 'NEMA PODATAKA' END ,
            OBJ.*
FROM  xmeta.DATASTAGEX_DSSTAGE OBJ, xmeta.DATASTAGEX_DSJOBDEF JOBS
WHERE  OBJ.OF_JOBDEF_XMETA = JOBS.XMETA_REPOS_OBJECT_ID_XMETA
AND upper(OBJ.NAME_XMETA) like '%DSACONTRACTHASH_MATURITYDATE%'
and OBJ.STAGETYPECLASSNAME_XMETA='HashedFileStage'
--and JOBS.NAME_XMETA like '%SIRIUS_LIM_REFERENCE%'
--and OBJ.NAME_XMETA = '%NDR%'
ORDER BY job_name;


--- za 2.4 baza DSPROD------
SELECT JOBS.NAME_XMETA AS JOB_NAME,
                        OBJ.* 
FROM  XMETA.DATASTAGEXDSPARAMETRVLC2E76D84 OBJ, 
      XMETA.DATASTAGEX_DSJOBDEFC2E76D84 JOBS
WHERE  OBJ.xmeta_lockingroot_xmeta = JOBS.XMETA_REPOS_OBJECT_ID_XMETA
--AND upper(OBJ.valueexpression_xmeta) like upper('%ST_INSURANCE%')
and  upper(JOBS.NAME_XMETA) = 'ACCOUNTPREJOBNONRETAIL_NEW_TEST_NAKNADE'
ORDER BY job_name
;


---- za hasth na 24-------------
SELECT OBJ.NAME_XMETA AS OBJECT_NAME,
            OBJ.STAGETYPECLASSNAME_XMETA AS OBJECT_TYPE,
            JOBS.NAME_XMETA AS JOB_NAME,
            case WHEN inputpins_xmeta IS NOT NULL AND  outputpins_xmeta IS NOT NULL THEN 'INPUT / OUTPUT'
            when inputpins_xmeta is not null then 'INPUT'
                    WHEN outputpins_xmeta IS NOT NULL THEN 'OUTOUT'
                                        ELSE 'NEMA PODATAKA' END ,
            OBJ.*
FROM  XMETA.DATASTAGEX_DSSTAGEC2E76D84 obj, xmeta.DATASTAGEX_DSJOBDEFC2E76D84 JOBS
WHERE  OBJ.OF_JOBDEF_XMETA = JOBS.XMETA_REPOS_OBJECT_ID_XMETA
AND upper(OBJ.NAME_XMETA) like '%CUSTOMERRATINGHASH%'
and OBJ.STAGETYPECLASSNAME_XMETA='HashedFileStage'
--and JOBS.NAME_XMETA like '%SIRIUS_LIM_REFERENCE%'
--and OBJ.NAME_XMETA = '%NDR%'
ORDER BY job_name;


---- 24 dohvat default vrijednost parametra-------------
select
  cjl.lvl p_no,
  prm.NAME_XMETA parameter_name,
  prm.DISPLAYCAPTION_XMETA ds_prompt,
  prm.DEFAULTVALUE_XMETA default_value,
  case    when TYPECODE_XMETA = 9 then
      case
        when EXTENDEDTYPE_XMETA = 1 then 'String'
        when EXTENDEDTYPE_XMETA = 2 then 'Encripted'
      end
    when TYPECODE_XMETA = 4 then 'Integer'
  end as ds_type,
  EXTENDEDTYPE_XMETA,
  TYPECODE_XMETA,
  'help text' as help_text,
  1 as jedan
from XMETA.DATASTAGEX_DSJOBDEFC2E76D84 jb
cross join lateral (
  select
    level lvl,
    to_char(regexp_substr(jb.HAS_PARAMETERDEF_XMETA, '[^[:cntrl:]]+',1,level)) id
  from dual
  connect by level <= regexp_count(jb.HAS_PARAMETERDEF_XMETA, '[^[:cntrl:]]+',1)
) cjl
left join XMETA.datastagexdsparametrdfc2e76d84 prm
  on cjl.id = prm.XMETA_REPOS_OBJECT_ID_XMETA
where 1=1
  and jb.name_xmeta = 'st2coAccountTransaction'

;