SELECT DSNAMESPACE_XMETA PROJECT,
       J.NAME_XMETA JOB_NAME,
       S.NAME_XMETA STAGE_NAME,
       v.VALUEEXPRESSION_XMETA EXPRESSION
       ,DBMS_LOB.SUBSTr(v.VALUEEXPRESSION_XMETA,2000,DBMS_LOB.INSTR(v.VALUEEXPRESSION_XMETA,'SELECT')) AS SELECT_STM
       ,DBMS_LOB.SUBSTr(v.VALUEEXPRESSION_XMETA,2000,DBMS_LOB.INSTR(v.VALUEEXPRESSION_XMETA,'INSERT')) AS INSERT_STM
       --S.*
       --,V.*
       --,SUBSTR(v.VALUEEXPRESSION_XMETA, INSTR(v.VALUEEXPRESSION_XMETA,'INSERT')) INSERT_STM,
       --DBMS_LOB.SUBSTr(v.VALUEEXPRESSION_XMETA) AS SELECT_STM
  FROM XMETA.DATASTAGEX_DSSTAGE S
       JOIN XMETA.DATASTAGEX_DSJOBDEF J
          ON S.CONTAINER_RID = J.XMETA_REPOS_OBJECT_ID_XMETA
        JOIN XMETA.DATASTAGEXDSPARAMETRVL V
          ON S.XMETA_REPOS_OBJECT_ID_XMETA = V.CONTAINER_RID
where 1=1 
  --And   V.PARAMETERNAME_XMETA = 'XMLProperties'
  --and j.DSNAMESPACE_XMETA = 'RBADWH-PE:RBA_Reporting' 
 --and j.DSNAMESPACE_XMETA LIKE '%IFRS%' 
  --and J.NAME_XMETA  = 'Zbirna'  
  AND upper(S.NAME_XMETA) LIKE '%%'  
  and
  (
   upper(v.VALUEEXPRESSION_XMETA) like '%TB0_ACCOUNT_INTEREST_RATE%'  
   )
      --and upper(v.VALUEEXPRESSION_XMETA) like '%INSERT%'
    and J.NAME_XMETA not like 'CopyOf%'
    and J.NAME_XMETA not like '%BKP2%'
    and J.NAME_XMETA not like '%BCK2%'
    --and J.NAME_XMETA not like '%_Test'
    --and J.NAME_XMETA not like '%_test_%'
    and J.NAME_XMETA not like '%2021%'
    and J.NAME_XMETA not like '%2019%'
    and J.NAME_XMETA not like '%opuna%'
       --and J.NAME_XMETA   = 'Factoring�LIMIT'
       
       --AND V.PARAMETERNAME_XMETA= 'XMLProperties'
       --AND S.NAME_XMETA = 'aquariusAgreements'   
       
       

-- DataStage 11.5
-- Tra�imo parametre od stej�a i njegovog izlaznog linka
-- Na ovaj na�in dolazimo do SQL upita ako je na stej�u ili ako je na izlaznom linku
with w_job_stg_link as (
  SELECT
    jb.DSNAMESPACE_XMETA job_PROJECT,
    jb.NAME_XMETA JOB_NAME,
    stg.XMETA_REPOS_OBJECT_ID_XMETA stage_id,
    stg.name_xmeta stage_name,
    lnk.XMETA_REPOS_OBJECT_ID_XMETA link_id,
    lnk.name_xmeta link_name,
    out_pin.XMETA_REPOS_OBJECT_ID_XMETA out_pin_id,
    1 as dva
  from XMETA.DATASTAGEX_DSJOBDEF jb -- job
  JOIN XMETA.DATASTAGEX_DSSTAGE stg -- stage
    ON Stg.CONTAINER_RID = Jb.XMETA_REPOS_OBJECT_ID_XMETA
  join XMETA.DATASTAGEX_DSOUTPUTPIN out_pin -- out pin
    on out_pin.OF_JOBCOMPONENT_XMETA = stg.XMETA_REPOS_OBJECT_ID_XMETA
  join xmeta.DATASTAGEX_DSLINK lnk
    on lnk.XMETA_REPOS_OBJECT_ID_XMETA = out_pin.issourceof_link_xmeta
  where 1=1 
    --and upper(v.VALUEEXPRESSION_XMETA) like '%LIMIT_REF%'
    --and upper(v.VALUEEXPRESSION_XMETA) like '%INSERT%'
     and jb.NAME_XMETA   = 'Zbirna'          ----------------<<< -- ovdi ubaci ime Joba
     and jb.DSNAMESPACE_XMETA = 'RBADWH-PE:RBA_Reporting'  ----------------<<< -- ovdi ubaci ime projekta
     --and jb.DSNAMESPACE_XMETA = 'RBADWH-PE:RBA_Reporting'  ----------------<<< -- ovdi ubaci ime projekta
     --AND V.PARAMETERNAME_XMETA= 'XMLProperties'
     --AND stg.NAME_XMETA = 'aquariusAgreements'        ----------------<<< -- ovdi ubaci ime stje�a
),
w_stg_params as (
  select
    jsl.job_project,
    jsl.job_name,
    jsl.stage_name,
    jsl.link_name,
    'stage parameter' param_source,
    prm.PARAMETERNAME_XMETA, 
    prm.VALUEEXPRESSION_XMETA,
    1 as dva
  from w_job_stg_link jsl
  JOIN XMETA.DATASTAGEXDSPARAMETRVL prm
    ON jsl.stage_id = prm.CONTAINER_RID
   where 1=1 and   jsl.job_name  = 'Zbirna'
),
w_lnk_params as (
  select
    jsl.job_project,
    jsl.job_name,
    jsl.stage_name,
    jsl.link_name,
    'link parameter' param_source,
    prm.PARAMETERNAME_XMETA, 
    prm.VALUEEXPRESSION_XMETA,
    1 as dva
  from w_job_stg_link jsl
  JOIN XMETA.DATASTAGEXDSPARAMETRVL prm
    ON jsl.link_id = prm.CONTAINER_RID
),
w_unija as (
  select * from w_stg_params union all
  select * from w_lnk_params
)
select * from   w_stg_params

select * from w_unija a
where 1=1 
and upper(VALUEEXPRESSION_XMETA) like '%HNB_ZBA_B%'



and job_name not like 'CopyOf%'
and job_name not like '%BKP2%'
and job_name not like '%_Test'
and job_name not like '%_test_%'
and job_name not like '%2021%'
and job_name not like '%2019%'
and job_name not like '%opuna%'



        
   