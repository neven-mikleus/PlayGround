-- DS11.5
-- U kojim jobovima se koristi hashica - pretraga po file name hashice
  -- tražimo parametar po hash file name-u
  -- tražimo link po FOR_JOBOBJECT_XMETA
  -- iz linka tražimo in/out pin
  -- iz pina tražimo stage
with prm as (
  select * from XMETA.DATASTAGEXDSPARAMETRVL 
  where 'Gašo' != 'Jurica'
  and to_char(PARAMETERNAME_XMETA) = 'FileName'
  and to_char(VALUEEXPRESSION_XMETA) = 'FleList02_EUR' -- <<-- ovdi ubaci filename hashice
),
links as (
  select 
    jb.DSNAMESPACE_XMETA job_project,
    jb.CATEGORY_XMETA job_folder,
    jb.name_xmeta job_name,  
    lnk.name_xmeta link_name,
    'write' as read_write, --> '' link_arrow1,
    stg.name_xmeta hash_stage_name,
    prm.VALUEEXPRESSION_XMETA hash_file_name,
    lnk.XMETA_REPOS_OBJECT_ID_XMETA link_id,
    1 as jedan
  from prm
  left join XMETA.DATASTAGEX_DSJOBDEF jb
    on jb.XMETA_REPOS_OBJECT_ID_XMETA = prm.XMETA_LOCKINGROOT_XMETA
  left join XMETA.DATASTAGEX_DSLINK lnk
    on lnk.XMETA_REPOS_OBJECT_ID_XMETA = prm.FOR_JOBOBJECT_XMETA
  left join XMETA.DATASTAGEX_DSinPUTPIN in_pin
    on in_pin.XMETA_REPOS_OBJECT_ID_XMETA = lnk.TO_INPUTPIN_XMETA
  left join XMETA.DATASTAGEX_DSSTAGE stg
    on in_pin.CONTAINER_RID = stg.XMETA_REPOS_OBJECT_ID_XMETA
  where 5=5
    --and jb.name_xmeta = 'ContractPreJobRetail'
    and stg.STAGETYPECLASSNAME_XMETA = 'HashedFileStage'  
  union all  
  select 
    jb.DSNAMESPACE_XMETA job_project,
    jb.CATEGORY_XMETA job_folder,
    jb.name_xmeta job_name,  
    lnk.name_xmeta link_name,
    'read' as read_write,
    stg.name_xmeta hash_stage_name,
    prm.VALUEEXPRESSION_XMETA hash_file_name,
    lnk.XMETA_REPOS_OBJECT_ID_XMETA link_id,
    1 as jedan
  from prm
  left join XMETA.DATASTAGEX_DSJOBDEF jb
    on jb.XMETA_REPOS_OBJECT_ID_XMETA = prm.XMETA_LOCKINGROOT_XMETA
  left join XMETA.DATASTAGEX_DSLINK lnk
    on lnk.XMETA_REPOS_OBJECT_ID_XMETA = prm.FOR_JOBOBJECT_XMETA
  left join XMETA.DATASTAGEX_DSoutPUTPIN out_pin
    on out_pin.XMETA_REPOS_OBJECT_ID_XMETA = LNK.FROM_OUTPUTPIN_XMETA
  left join XMETA.DATASTAGEX_DSSTAGE stg
    on out_pin.CONTAINER_RID = stg.XMETA_REPOS_OBJECT_ID_XMETA
  where 5=5
    and stg.STAGETYPECLASSNAME_XMETA = 'HashedFileStage'
)
select * from links
where 1=1 and   upper(job_name) not like '%BCK%'
and   upper(job_name) not like 'COPY%'
order by read_write desc, job_project, job_name
;