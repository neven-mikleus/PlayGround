-- tražimo kolone i mapiranja za link koji izlazi iz transformera
  -- PARAMETRI: linije 42-44
-- mapiranje može biti na flowvariable ili dsflowarprops ili kombinacija oba
-- detektirani ključevi u DSFLOWVARPROPS_XMETA:
-- 3,n,fy,l,x,s,i,q,d,o,A,H,R,G,N,I,O,S,J,T,K,U,>1,>e,P
-- razmak između polja je chr(??)<RS>

-- link koji izlazi iz transfomrera sadrži kolone i mapiranja kolona
-- [tb4] kolone i mapiranja mogu biti u polju CONTAINS_FLOWVARIABLE_XMETA (lista IDjeva za tablicu DATASTAGEXDSFLOWVARIBL)
  -- vrijednosti nalazimo u toj tablici ili tablici DATASTAGEXDSDERIVATION
-- [tb1] kolone i mapiranja mogu biti i u poljima DSFLOWVARPROPS_XMETA,DSFLOWVARNAMES_XMETA,DSFLOWVARSOURCECOLUMNIDS_XMETA
  -- ako se tu nalaze onda se nazivi kolona nalaze u DSFLOWVARNAMES_XMETA, a mapiranja u DSFLOWVARPROPS_XMETA
  -- ako se mapiranje ne nalazi u DSFLOWVARPROPS_XMETA, onda uzimamo iz DSFLOWVARSOURCECOLUMNIDS_XMETA

with 
/*
FUNCTION f_before_sql_select(p_expr IN clob) 
  RETURN nclob
  --RETURN XMLTYPE 
  IS
    v_x XMLTYPE;
    v_TOKEN XMLTYPE;
    v_clob nclob := EMPTY_CLOB();
  BEGIN
   IF p_expr IS NULL THEN
    RETURN v_clob;
   END IF;   
   v_x := XMLTYPE(p_expr);
   v_TOKEN := v_x.EXTRACT('//Properties/Usage/BeforeAfter/BeforeSQL/text()');  
   if v_TOKEN is not null then
    v_clob :=  replace(v_TOKEN.getClobVal(),'<![CDATA[',null);
    v_clob :=  replace(v_clob,']]>',null);
   end if;   
   RETURN v_clob;
  END;
FUNCTION f_sql_select(p_expr IN clob) 
  RETURN nclob
  --RETURN XMLTYPE 
  IS
    v_x XMLTYPE;
    v_TOKEN XMLTYPE;
    v_clob nclob := EMPTY_CLOB();
  BEGIN
   IF p_expr IS NULL THEN
    RETURN v_clob;
   END IF;   
   v_x := XMLTYPE(p_expr);
   v_TOKEN := v_x.EXTRACT('//Properties/Usage/SQL/SelectStatement/text()');  
   if v_TOKEN is not null then
    v_clob :=  replace(v_TOKEN.getClobVal(),'<![CDATA[',null);
    v_clob :=  replace(v_clob,']]>',null);
   end if;   
   RETURN v_clob;
  END;
  */
  --
-- ovdje promjeni jel RET ili NRT
--
project as(
select project, DECODE(dat.ret_nrt,'RET','IFRS9_Retail_WithCopy_PROD','NRT','IFRS9_NonRetail_WithCopy_PROD') STARTING_JOB from  ( 
select 'RBADWH-PE:IFRS9' project, 'RET' as  ret_nrt  from dual  
) dat
),
  job_mapping as(
--select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Contract_Retail_GAR_test_def'            AS TARGET_JOB, 'GAR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
--
-- Retail
--           
           select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Account_Retail_KKR_TRC_PPZ_test_naknade'    AS TARGET_JOB, 'KKR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Account_Retail_KKR_TRC_PPZ_test_naknade'    AS TARGET_JOB, 'TRC' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Account_Retail_KKR_TRC_PPZ_test_naknade'    AS TARGET_JOB, 'SDR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 --
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Contract_Retail_GAR_test_def'            AS TARGET_JOB, 'GAR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Contract_Retail_KRD_test_def'            AS TARGET_JOB, 'KRD' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Contract_NonRetail_LOC_test_def'         AS TARGET_JOB, 'LOC' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Contract_Retail_PKR_test_def'            AS TARGET_JOB, 'PKR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Contract_NonRetail_OKV_test_def'         AS TARGET_JOB, 'OKV' as APPLICATION_ID, 'RET' as  ret_nrt from dual 
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Contract_NonRetail_FOR_test_def'         AS TARGET_JOB, 'FOR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 -- write off
 union all select 'DSA_WRITE_OFF' AS TARGET_TABLE, 'ToDsa'      AS TARGET_TABLE_LINK, 'WriteOff_Retail_HNB'                          AS TARGET_JOB, 'WOF' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_WRITE_OFF' AS TARGET_TABLE, 'DSLink132'  AS TARGET_TABLE_LINK, 'WriteOff_Retail_HNB'                          AS TARGET_JOB, 'WOF' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 -- Fee
 union all select 'DSA_FEE'       AS TARGET_TABLE, 'DSA_fee'  AS TARGET_TABLE_LINK, 'Fee_GAR'        AS TARGET_JOB, 'GAR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_FEE'       AS TARGET_TABLE, 'DSA_fee'  AS TARGET_TABLE_LINK, 'Fee_KRD'        AS TARGET_JOB, 'KRD' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_FEE'       AS TARGET_TABLE, 'DSA_fee'  AS TARGET_TABLE_LINK, 'Fee_PKR'        AS TARGET_JOB, 'PKR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_FEE'       AS TARGET_TABLE, 'DSA_fee'  AS TARGET_TABLE_LINK, 'Fee_Akreditivi' AS TARGET_JOB, 'AKR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_FEE'       AS TARGET_TABLE, 'DSA_fee'  AS TARGET_TABLE_LINK, 'Fee_Okviri'     AS TARGET_JOB, 'OKV' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_FEE'       AS TARGET_TABLE, 'DSA_fee'  AS TARGET_TABLE_LINK, 'Fee_Overdraft'  AS TARGET_JOB, 'OVD' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 --Bevent
 union all select 'DSA_BEVENT'           AS TARGET_TABLE, 'DSA_bevent'  AS TARGET_TABLE_LINK, 'Bevent_KRD'  AS TARGET_JOB, 'KRD' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_BEVENT_VARIABLE'   AS TARGET_TABLE, 'DSA_bevent'  AS TARGET_TABLE_LINK, 'Bevent_KRD'  AS TARGET_JOB, 'KRD' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_BEVENT'           AS TARGET_TABLE, 'DSA_bevent'  AS TARGET_TABLE_LINK, 'Bevent_PKR'  AS TARGET_JOB, 'PKR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_BEVENT_VARIABLE'   AS TARGET_TABLE, 'DSA_bevent'  AS TARGET_TABLE_LINK, 'Bevent_PKR'  AS TARGET_JOB, 'PKR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_BEVENT_VARIABLE_2' AS TARGET_TABLE, 'DSA_bevent'  AS TARGET_TABLE_LINK, 'Bevent_PKR'  AS TARGET_JOB, 'PKR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 --DSA_PAYMENT_SCHEDULE
 union all select 'DSA_PAYMENT_SCHEDULE' AS TARGET_TABLE, 'ToPS'  AS TARGET_TABLE_LINK, 'PaymentSchedule_Retail'  AS TARGET_JOB, null as APPLICATION_ID, 'RET' as  ret_nrt from dual
 --DSA_COLLATERAL
 union all select 'DSA_COLLATERAL'       AS TARGET_TABLE, 'ToCollateral'  AS TARGET_TABLE_LINK, 'IFRS9_Collateral_Collateral_Link_DONTCutHNBProvisions'  AS TARGET_JOB, '' as APPLICATION_ID, 'RET' as  ret_nrt from dual
--
-- Non Retail
--
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Account_NonRetail_KKR_PPZ_s_nakn'    AS TARGET_JOB, 'KKR' as APPLICATION_ID, 'NRT' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Account_NonRetail_KKR_PPZ_s_nakn'    AS TARGET_JOB, 'SDR' as APPLICATION_ID, 'NRT' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Contract_NonRetail_KRD_prod'    AS TARGET_JOB, 'KRD' as APPLICATION_ID, 'NRT' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Contract_NonRetail_GAR_prod'    AS TARGET_JOB, 'GAR' as APPLICATION_ID, 'NRT' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Account_Retail_KKR_TRC_PPZ'    AS TARGET_JOB, 'KKR' as APPLICATION_ID, 'NRT' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Account_Retail_KKR_TRC_PPZ'    AS TARGET_JOB, 'TRC' as APPLICATION_ID, 'NRT' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Account_Retail_KKR_TRC_PPZ'    AS TARGET_JOB, 'SDR' as APPLICATION_ID, 'NRT' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Contract_NonRetail_OKV_prod'    AS TARGET_JOB, 'OKV' as APPLICATION_ID, 'NRT' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Contract_NonRetail_PKR_prod'    AS TARGET_JOB, 'PKR' as APPLICATION_ID, 'NRT' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Contract_NonRetail_LOC_prod'    AS TARGET_JOB, 'LOC' as APPLICATION_ID, 'NRT' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Contract_NonRetail_WSS_prod'    AS TARGET_JOB, 'WSS' as APPLICATION_ID, 'NRT' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Contract_NonRetail_FAC_prod'    AS TARGET_JOB, 'FAC' as APPLICATION_ID, 'NRT' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Account_NonRetail_SDR_SDA_prod'    AS TARGET_JOB, 'SDA' as APPLICATION_ID, 'NRT' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Contract_NonRetail_WSS_LORO_prod'    AS TARGET_JOB, 'WSS_LORO' as APPLICATION_ID, 'NRT' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Contract_NonRetail_FOR_prod'    AS TARGET_JOB, 'FOR' as APPLICATION_ID, 'NRT' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Securities_NonRetail_IN2_prod'    AS TARGET_JOB, 'IN2' as APPLICATION_ID, 'NRT' as  ret_nrt from dual
)
,ifrs9_jobs as
(
select distinct JOB_NAME,XMETA_REPOS_OBJECT_ID_XMETA, PATH from(
SELECT 
 COALESCE(JOBS.XMETA_REPOS_OBJECT_ID_XMETA,JOBS2.XMETA_REPOS_OBJECT_ID_XMETA) AS XMETA_REPOS_OBJECT_ID_XMETA,    
      COALESCE(OBJ.JOBNAME_XMETA,OBJ.NAME_XMETA) AS JOB_NAME,
      --OBJ.JOBNAME_XMETA AS JOB_NAME,
                   OBJ.NAME_XMETA stage_name,
                   COALESCE(JOBS.NAME_XMETA,OBJ.NAME_XMETA ) AS PAR_JOB_NAME,
                    SYS_CONNECT_BY_PATH (COALESCE(OBJ.JOBNAME_XMETA,OBJ.NAME_XMETA), '/') PATH,
                   --JOBS.NAME_XMETA AS PAR_JOB_NAME,
                   JOBS.DSNAMESPACE_XMETA PAR_PROJECT,                 
                   obj.internalid_xmeta sub_order,
                   OBJ.STAGETYPECLASSNAME_XMETA,
                    OBJ.NAME_XMETA
              FROM XMETA.DATASTAGEX_DSSTAGE OBJ,
                   XMETA.DATASTAGEX_DSJOBDEF JOBS,
                   XMETA.DATASTAGEX_DSJOBDEF JOBS2,
                   project
             WHERE     OBJ.OF_JOBDEF_XMETA = JOBS.XMETA_REPOS_OBJECT_ID_XMETA
                   --AND OBJ.STAGETYPECLASSNAME_XMETA = 'JSJobActivity'
                   AND OBJ.OF_JOBDEF_XMETA = JOBS2.XMETA_REPOS_OBJECT_ID_XMETA   
                   and    project.project =  JOBS.DSNAMESPACE_XMETA
                   and    project.project =  JOBS2.DSNAMESPACE_XMETA                
                   --AND JOBS.DSNAMESPACE_XMETA = pro.project_name                  
                   CONNECT BY NOCYCLE PRIOR COALESCE(OBJ.JOBNAME_XMETA,OBJ.NAME_XMETA) = COALESCE(JOBS.NAME_XMETA,OBJ.NAME_XMETA )
START WITH COALESCE(JOBS.NAME_XMETA,OBJ.NAME_XMETA ) = project.STARTING_JOB
)
where 1=1 and   STAGETYPECLASSNAME_XMETA in('JSJobActivity')
),
tb0 as (
  -- upit dohvaća link i polja iz kojih ćemo vaditi kolone i mapiranja koja se nalaze u transformeru
  -- prvo napadamo DSFLOWVARPROPS_XMETA, a kasnije DATASTAGEXDSFLOWVARIBL
  select
    JB.DSNAMESPACE_XMETA JOB_PROJECT,
    lnk.XMETA_REPOS_OBJECT_ID_XMETA,
    lnk.name_xmeta link_name,
    lnk.XMETA_REPOS_OBJECT_ID_XMETA  lnk_XMETA_REPOS_OBJECT_ID_XMETA,
    --stg.name_xmeta transformer_name,  
    --' -- ## -- ' spacer,
    lnk.CONTAINS_FLOWVARIABLE_XMETA,
    lnk.DSFLOWVARSOURCECOLUMNIDS_XMETA,
    lnk.DSFLOWVARNAMES_XMETA,
    lnk.DSFLOWVARPROPS_XMETA,
    jb.dsnamespace_xmeta,
    JB.NAME_XMETA JOB_NAME,
    JB.XMETA_REPOS_OBJECT_ID_XMETA JOB_XMETA_REPOS_OBJECT_ID_XMETA,
    --
    JB_MAP.APPLICATION_ID, 
    JB_MAP.ret_nrt ,
    JB_MAP.target_table
  from xmeta.DATASTAGEX_DSLINK lnk
  left join XMETA.DATASTAGEX_DSOUTPUTPIN out_pin
    on out_pin.XMETA_REPOS_OBJECT_ID_XMETA = lnk.FROM_OUTPUTPIN_XMETA
  left join XMETA.DATASTAGEX_DSSTAGE stg
    on stg.XMETA_REPOS_OBJECT_ID_XMETA = out_pin.CONTAINER_RID
   join xmeta.DATASTAGEX_DSJOBDEF jb
    on jb.XMETA_REPOS_OBJECT_ID_XMETA = lnk.XMETA_LOCKINGROOT_XMETA
   join project on  project.project =  jb.DSNAMESPACE_XMETA
   JOIN job_mapping JB_MAP ON JB_MAP.TARGET_JOB = jb.name_xmeta AND JB_MAP.TARGET_TABLE_LINK =lnk.name_xmeta 
  where 7=7
    -- filtriramo link_id (ako imamo id brže je nego po link_name), job_name, link_name
    --and jb.name_xmeta = 'IFRS9_Contract_NonRetail_KRD_prod'
    --and jb.name_xmeta = 'IFRS9_Contract_NonRetail_KRD_prod'
),
tb1 as (
  -- razbijamo polje DSFLOWVARNAMES_XMETA u retke, separator je chr(29) - to su nazivi kolona čija mapiranja se nalaze u DSFLOWVARPROPS_XMETA
  -- ako se mapiranje na nalazi u DSFLOWVARPROPS_XMETA, onda uzimamo vrijednost iz DSFLOWVARSOURCECOLUMNIDS_XMETA
  -- sve kolone koje postoje u mapiranju za zadani link a ne nalazimo u DSFLOWVARNAMES_XMETA biti će u CONTAINS_FLOWVARIABLE_XMETA
  -- kolone iz CONTAINS_FLOWVARIABLE_XMETA će imati mapiranje u DATASTAGEXDSDERIVATION tablici
  -- redoslijed kolona je zadan u DSFLOWVARPROPS_XMETA, ali oni redovi u DSFLOWVARPROPS_XMETA koji imaju u sebi q=<broj> prije sebe moraju 
  -- ubaciti onoliki broj kolona iz DSFLOWVARNAMES_XMETA koloko se nalazi iza q
  -- npr. ako je q=2 onda moramo ubaciti 2 kolone
  -- broj redaka u DSFLOWVARNAMES_XMETA odgovara broju redaka u DSFLOWVARPROPS_XMETA, imaju isti separator chr(29)
  -- ponekad se u DSFLOWVARPROPS_XMETA neće nalaziti naziv kolone, pa ga uzimamo redoslijedom iz DSFLOWVARNAMES_XMETA
  -- radimo replace "chr(29)" sa "|" kako razbili DSFLOWVARNAMES_XMETA i DSFLOWVARPROPS_XMETA u retke
  -- prvenstveno zato što DSFLOWVARPROPS_XMETA ima još kontrolnih znakova, pa ako bi razbijali po [[:cntrl:]] ne bi išlo
  select
  lnk.JOB_PROJECT,
    lnk.link_name link_name,
    --stg.name_xmeta transformer_name,  
    --' -- ## -- ' spacer,
    lnk.CONTAINS_FLOWVARIABLE_XMETA,
    --lnk.DSFLOWVARNAMES_XMETA,
    --lnk.DSFLOWVARSOURCECOLUMNIDS_XMETA,
    --lnk.DSFLOWVARPROPS_XMETA,
    to_char(regexp_substr(replace(lnk.DSFLOWVARNAMES_XMETA, chr(29), '|'), '[^|]+',1,cjl.lvl)) df_names, -- chr29 je separator retka, vadimo imena kolona
    to_char(regexp_substr(replace(lnk.DSFLOWVARPROPS_XMETA, chr(29), '|'), '[^|]+',1,cjl.lvl)) df_prop,
    to_char(regexp_substr(replace(lnk.DSFLOWVARSOURCECOLUMNIDS_XMETA, chr(29), '| '), '[^|]+',1,cjl.lvl)) df_src_col_id, -- ubacujemo '|;' tako da uhvatimo i prazne
    cjl.lvl,
    lnk.JOB_NAME,
    lnk.JOB_XMETA_REPOS_OBJECT_ID_XMETA,
    lnk.lnk_XMETA_REPOS_OBJECT_ID_XMETA,
    lnk.target_table,
    lnk.application_id,
    lnk.ret_nrt,
    1 as jedan
    --stg.*
  from tb0 lnk
  cross join lateral (
    -- razbojamo kolonu DSFLOWVARNAMES_XMETA u retke - vadimo nazive kolona
    select
      level lvl,
      to_char(regexp_substr(lnk.DSFLOWVARNAMES_XMETA, '[^[:cntrl:]+]',1,level)) id
    from dual
    connect by level <= regexp_count(lnk.DSFLOWVARNAMES_XMETA, '[^[:cntrl:]]+',1)
  ) cjl
)
--select * From tb1; /
,
tb2 as (
-- vadimo polja iz DSFLOWVARPROPS_XMETA:
  -- 3 - [description]
  -- y - tip kolone
  -- x - [Length]
  -- q - broj kolona koje treba ubacit prije kolone iz danog retka, a nalaze se u DATASTAGEXDSFLOWVARIBL
  -- d - [Display]
  -- o - db tip kolone [SQL type]
  -- R - naziv kolone [Column name]
  -- T - lokacija definicije tablice - iako nisam uspio naći tu lokaciju u table_definition tablici
  -- K - [Key] - ključ seta podataka
  -- >e - expression - mapiranje
  -- >P - parsed expression - mapiranje
  -- n,f,l,s,i,A,H,G,N,I,O,S,J,U,>1 - ?? - nepoznato značenje za sada
  -- ovime smo izvadili sva polja iz dwflowarnames,props, njihova mapiranja, q vrijednosti
  select
   tb1.JOB_PROJECT,
    tb1.lvl,
    df_names,
    substr(trim(df_src_col_id),2,nvl(length(trim(df_src_col_id)),2)-2) df_src_col_id,
    regexp_substr(tb1.df_prop, '[[:cntrl:]]>P=(.*?)[[:cntrl:]]',1,1,'i',1) p_polje, -- mapiranje, ako nema onda uzimamo iz DSFLOWVARSOURCECOLUMNIDS_XMETA
    regexp_substr(tb1.df_prop, '[[:cntrl:]]q=(.*?)[[:cntrl:]]',1,1,'i',1) q_polje, -- broj polja iz flowars koje treba ubaciti prije ovog polja
    regexp_substr(tb1.df_prop, '[[:cntrl:]]R=(.*?)[[:cntrl:]]',1,1,'i',1) r_polje, -- naziv kolone - ne mora postojat, onda uzimamo iz DSFLOWVARNAMES_XMETA tamo je sigurno
    TB1.JOB_NAME,
    TB1.JOB_XMETA_REPOS_OBJECT_ID_XMETA,
    tb1.link_name,
    tb1.lnk_XMETA_REPOS_OBJECT_ID_XMETA,
    tb1.target_table,
    tb1.application_id,
    tb1.ret_nrt
  from tb1
)
--select * From tb2; /
,
tb3 as (
  -- detektiramo samo one kolone koje imaju q vrijednosti na sebi i poredavamo ih sa rank
  select
    tb2.*,
    rank() over (partition by case when q_polje is not null then 1 end order by lvl) rnk
  from tb2
)
--select * From tb3; /
,
  tb4 as (
  -- vadimo CONTAINS_FLOWVARIABLE_XMETA kolone i njihova mapiranja, dio je tu koji nismo dodsad uspili izvadit 
  select
    --cjl.id,
    tb0.JOB_PROJECT,
    cjl.lvl col_id,
    to_char(flw.name_xmeta) column_name,
    to_char(nvl(der.PARSEDEXPRESSION_XMETA, flw.SOURCECOLUMNID_XMETA)) column_mapping ,
    tb0.link_name,
    tb0.lnk_XMETA_REPOS_OBJECT_ID_XMETA,
    TB0.JOB_NAME,
    TB0.JOB_XMETA_REPOS_OBJECT_ID_XMETA,
    --
    TB0.target_table, 
     TB0.APPLICATION_ID, 
    TB0.ret_nrt 
  from tb0
  cross join lateral (
    select
      level lvl,
      to_char(regexp_substr(tb0.CONTAINS_FLOWVARIABLE_XMETA, '[^[:cntrl:]]+',1,level)) id
    from dual
    connect by level <= regexp_count(tb0.CONTAINS_FLOWVARIABLE_XMETA, '[^[:cntrl:]]+',1)
  ) cjl
  left join XMETA.DATASTAGEXDSFLOWVARIBL flw
    on flw.XMETA_REPOS_OBJECT_ID_XMETA = cjl.id
  left join XMETA.DATASTAGEXDSDERIVATION der
    on der.XMETA_REPOS_OBJECT_ID_XMETA = to_char(substr(flw.HASVALUE_DERIVATION_XMETA,2,64))
)
--select * From tb4; /
,
tb5 as (
  -- hvatamo samo retke sa q vrijednosti, multipliciramo q+1 puta sa cross join lateral
  -- radimo mjesta da ubacimo ispred svih polja koja imaju q>0 polja iz DATASTAGEXDSFLOWVARIBL 
  select 
    tb3.*,
    lvl1,
    rownum as rn
  from tb3
  cross join lateral (
    select
      level lvl1
    from dual
    connect by level <= q_polje+1
  ) cjl
  --where q_polje is not null
)
--select * From tb5; /
,
TB6 AS (
  -- izbacujemo sve prve, njima ćemo ostaviti mapiranje, a na ostale ćemo nakačiti iz DATASTAGEXDSFLOWVARIBL
  SELECT
    TB5.*,
    ROWNUM RN_JOIN_FLW
  FROM TB5 
  --WHERE LVL1 > 1
  ORDER BY RN
),
TB7 AS (
 -- SPAJAMO FLOWVARIABLE I MJESTA NAKON Q IZ FLOVARPROPS
  SELECT tb6.* 
  ,tb4.COL_ID  
  ,tb4.COLUMN_MAPPINg
  ,tb4.COLUMN_NAME
  FROM TB6
  LEFT JOIN TB4
    ON TB6.RN_JOIN_FLW = TB4.COL_ID  and TB6.job_name = TB4.job_name
),
TB8 AS (
  -- sajamo nove kolone na priširene stare
  SELECT
  tb5.JOB_PROJECT,
    NVL(TB7.COLUMN_NAME,TB5.DF_NAMES) AS COLUMN_NAME,
    coalesce(TB7.COLUMN_MAPPING, TB5.P_POLJE, tb5.df_src_col_id) AS COLUMN_MAPPING,
    TB7.COL_ID AS FLOWAR_COLID,
    tb5.df_src_col_id,
    tb5.link_name,
    tb5.lnk_XMETA_REPOS_OBJECT_ID_XMETA,
    TB5.job_name,
    TB5.JOB_XMETA_REPOS_OBJECT_ID_XMETA,
    tb5.target_table,
    tb5.application_id,
    tb5.ret_nrt
  FROM TB5
  LEFT JOIN TB7
    ON TB5.RNK=TB7.RNK
    AND TB5.LVL1=TB7.LVL1
  ORDER BY 
    TB5.LVL, -- redoslijed ide prvo po props
    TB7.COL_ID -- zatim po ubačenim kolonama, ovime će ubačene kolone ići ispred kolone sa q>0
), prm_hash as (
  select XMETA_LOCKINGROOT_XMETA,FOR_JOBOBJECT_XMETA,to_char(VALUEEXPRESSION_XMETA) hash_filename from XMETA.DATASTAGEXDSPARAMETRVL  p
  where  to_char(PARAMETERNAME_XMETA) = 'FileName'
),
hashFiles as (
  select 
    jb.DSNAMESPACE_XMETA job_project,
    jb.CATEGORY_XMETA job_folder,
    jb.name_xmeta job_name, 
    jb.XMETA_REPOS_OBJECT_ID_XMETA job_XMETA_REPOS_OBJECT_ID_XMETA,  
    lnk.name_xmeta link_name,
    'write' as read_write, --> '' link_arrow1,
    stg.name_xmeta hash_stage_name,
    prm.hash_filename hash_file_name,
    lnk.XMETA_REPOS_OBJECT_ID_XMETA link_id,
    hash_filename,
    stg.XMETA_REPOS_OBJECT_ID_XMETA stg_XMETA_REPOS_OBJECT_ID_XMETA,
    STG.SHORTDESCRIPTION_XMETA,
    1 as jedan
  from prm_hash prm
   join XMETA.DATASTAGEX_DSJOBDEF jb
   join project on  project.project =  jb.DSNAMESPACE_XMETA
    on jb.XMETA_REPOS_OBJECT_ID_XMETA = prm.XMETA_LOCKINGROOT_XMETA
   join XMETA.DATASTAGEX_DSLINK lnk
    on lnk.XMETA_REPOS_OBJECT_ID_XMETA = prm.FOR_JOBOBJECT_XMETA
   join XMETA.DATASTAGEX_DSinPUTPIN in_pin
    on in_pin.XMETA_REPOS_OBJECT_ID_XMETA = lnk.TO_INPUTPIN_XMETA
   join XMETA.DATASTAGEX_DSSTAGE stg
    on in_pin.CONTAINER_RID = stg.XMETA_REPOS_OBJECT_ID_XMETA
  where 5=5
    --and jb.name_xmeta = 'ContractPreJobRetail'
    and stg.STAGETYPECLASSNAME_XMETA = 'HashedFileStage'  
  union all  
  select 
    jb.DSNAMESPACE_XMETA job_project,
    jb.CATEGORY_XMETA job_folder,
    jb.name_xmeta job_name,  
    jb.XMETA_REPOS_OBJECT_ID_XMETA job_XMETA_REPOS_OBJECT_ID_XMETA,  
    lnk.name_xmeta link_name,
    'read' as read_write,
    stg.name_xmeta hash_stage_name,
    prm.hash_filename hash_file_name,
    lnk.XMETA_REPOS_OBJECT_ID_XMETA link_id,
    prm.hash_filename,
    stg.XMETA_REPOS_OBJECT_ID_XMETA stg_XMETA_REPOS_OBJECT_ID_XMETA,
    STG.SHORTDESCRIPTION_XMETA,
    1 as jedan
  from prm_hash prm
   join XMETA.DATASTAGEX_DSJOBDEF jb
   join project on  project.project =  jb.DSNAMESPACE_XMETA
    on jb.XMETA_REPOS_OBJECT_ID_XMETA = prm.XMETA_LOCKINGROOT_XMETA
   join XMETA.DATASTAGEX_DSLINK lnk
    on lnk.XMETA_REPOS_OBJECT_ID_XMETA = prm.FOR_JOBOBJECT_XMETA
   join XMETA.DATASTAGEX_DSoutPUTPIN out_pin
    on out_pin.XMETA_REPOS_OBJECT_ID_XMETA = LNK.FROM_OUTPUTPIN_XMETA
   join XMETA.DATASTAGEX_DSSTAGE stg
    on out_pin.CONTAINER_RID = stg.XMETA_REPOS_OBJECT_ID_XMETA
  where 5=5
    and stg.STAGETYPECLASSNAME_XMETA = 'HashedFileStage'
)
--
--
--
,sqls as
        (
        SELECT 
          s.XMETA_REPOS_OBJECT_ID_XMETA
          , J.NAME_XMETA     JOB_NAME
          ,J.XMETA_REPOS_OBJECT_ID_XMETA job_XMETA_REPOS_OBJECT_ID_XMETA
          , S.NAME_XMETA    STAGE_NAME
          , S.HAS_INPUTPIN_XMETA 
          , S.HAS_OUTPUTPIN_XMETA  
          ,J.DSNAMESPACE_XMETA project_name
          ,S.STAGETYPE_XMETA STAGETYPE   
          --,empty_clob() SELECT_STATEMENT 
          --,f_sql_select(v.VALUEEXPRESSION_XMETA) SELECT_STATEMENT
          --,f_before_sql_select(v.VALUEEXPRESSION_XMETA) BEFORE_STATEMENT          
          ,
          case when dbms_lob.instr(v.VALUEEXPRESSION_XMETA,'SelectStatement')> 0 then
          replace(
          replace(
          XMLTYPE(v.VALUEEXPRESSION_XMETA).EXTRACT('//Properties/Usage/SQL/SelectStatement/text()').getClobVal()
          ,'<![CDATA[',null)
          ,']]>',null)
          end SELECT_STATEMENT
          ,
          case when dbms_lob.instr(v.VALUEEXPRESSION_XMETA,'BeforeSQL')> 0 then
          replace(
          replace(
          XMLTYPE(v.VALUEEXPRESSION_XMETA).EXTRACT('//Properties/Usage/BeforeAfter/BeforeSQL/text()').getClobVal()
          ,'<![CDATA[',null)
          ,']]>',null) 
          end BEFORE_STATEMENT
          FROM XMETA.DATASTAGEX_DSSTAGE s
        INNER JOIN XMETA.DATASTAGEX_DSJOBDEF J
        ON  S.CONTAINER_RID = J.XMETA_REPOS_OBJECT_ID_XMETA
         join project on  project.project =  j.DSNAMESPACE_XMETA
         JOIN XMETA.DATASTAGEXDSPARAMETRVL V
        ON  S.XMETA_REPOS_OBJECT_ID_XMETA = V.CONTAINER_RID
            AND V.PARAMETERNAME_XMETA = 'XMLProperties'    
        WHERE 1=1
            AND S.STAGETYPE_XMETA like '%Connector'            
        )  
--
--
--
, stage_in_out as
(
select job.DSNAMESPACE_XMETA project_name,
       --job.category_xmeta folder_name,
       job.NAME_XMETA AS Job_Name,
       JOB.XMETA_REPOS_OBJECT_ID_XMETA job_XMETA_REPOS_OBJECT_ID_XMETA,
       stage_in.name_xmeta AS StageIn_Name,
       stage_out.name_xmeta AS StageOut_Name   ,
       stage_in.xmeta_repos_object_id_xmeta  AS StageIn_xmeta_repos_object_id_xmeta,
       stage_out.xmeta_repos_object_id_xmeta AS StageOut_xmeta_repos_object_id_xmeta
       ,STAGE_IN.STAGETYPE_XMETA  StageIn_STAGETYPE_XMETA  ,   
       link_in.xmeta_repos_object_id_xmeta lnk_xmeta_repos_object_id_xmeta         
       --,d.*
  FROM XMETA.datastagex_dsjobdef job
   join project on  project.project =  jOB.DSNAMESPACE_XMETA
       join XMETA.datastagex_dsstage stage_in     on job.xmeta_repos_object_id_XMETA = stage_in.container_rid
      left join  XMETA.datastagex_dsoutputpin pout_id on pout_id.container_rid = stage_in.xmeta_repos_object_id_xmeta
      left  join XMETA.datastagex_dslink link_in on pout_id.xmeta_repos_object_id_xmeta = link_in.from_outputpin_xmeta 
       left join  XMETA.datastagex_dsinputpin pin_id on pin_id.xmeta_repos_object_id_xmeta = LINK_IN.TO_INPUTPIN_XMETA
       left join XMETA.datastagex_dsstage stage_out    on pin_id.container_rid = stage_out.xmeta_repos_object_id_xmeta       
where 1=1
)
--
--
--
,stage_in_out_recursive as
(
select 
 level,
 SYS_CONNECT_BY_PATH (a.StageIn_Name, '/') PATH ,
 connect_by_root(a.StageIn_Name) as root,
 a.StageIn_xmeta_repos_object_id_xmeta--SYS_CONNECT_BY_PATH (a.StageOut_Name, '/') PATH1  
 ,a.Job_Name  
 ,a.job_XMETA_REPOS_OBJECT_ID_XMETA
 ,a.StageIn_STAGETYPE_XMETA
 from   stage_in_out a
connect by nocycle prior   StageIn_xmeta_repos_object_id_xmeta = StageOut_xmeta_repos_object_id_xmeta
START WITH StageOut_Name is null
) ,
stage_links AS
   (   
   select /*+ materialize */
   job.DSNAMESPACE_XMETA PROJECT,
   job.name_xmeta job_name,
   job.XMETA_REPOS_OBJECT_ID_XMETA job_XMETA_REPOS_OBJECT_ID_XMETA,
       stage_in.name_xmeta  m1,    
       link_in.name_xmeta  m2,
       stage_OUT.name_xmeta  m3,
       STAGE_IN.STAGETYPE_XMETA    STAGETYPE_m1,
       CAST('LINK' AS NVARCHAR2(4))    STAGETYPE_m2,
       stage_OUT.STAGETYPE_XMETA    STAGETYPE_m3,       
       STAGE_IN.SHORTDESCRIPTION_XMETA SHORTDESCRIPTION_XMETA_m1,
       stage_OUT.SHORTDESCRIPTION_XMETA SHORTDESCRIPTION_XMETA_m3,       
       TO_NCHAR(substr(STAGE_IN.LONGDESCRIPTION_XMETA,1,2000)) LONGDESCRIPTION_XMETA_m1,
       TO_NCHAR(substr(stage_OUT.LONGDESCRIPTION_XMETA,1,2000)) LONGDESCRIPTION_XMETA_m3, 
       STAGE_IN.XMETA_REPOS_OBJECT_ID_XMETA XMETA_REPOS_OBJECT_ID_XMETA_M1,
       link_in.XMETA_REPOS_OBJECT_ID_XMETA XMETA_REPOS_OBJECT_ID_XMETA_M2,
       stage_OUT.XMETA_REPOS_OBJECT_ID_XMETA XMETA_REPOS_OBJECT_ID_XMETA_M3   
FROM XMETA.datastagex_dsjobdef job
       join project on job.DSNAMESPACE_XMETA = project.project
       join XMETA.datastagex_dsstage stage_in     on job.xmeta_repos_object_id_XMETA = stage_in.container_rid
      left join  XMETA.datastagex_dsinputpin pin_id on pin_id.container_rid = stage_in.xmeta_repos_object_id_xmeta
      left  join XMETA.datastagex_dslink link_in on pin_id.xmeta_repos_object_id_xmeta = LINK_IN.TO_INPUTPIN_XMETA 
      left join  XMETA.datastagex_dsoutputpin pout_id on pout_id.xmeta_repos_object_id_xmeta = LINK_IN.FROM_OUTPUTPIN_XMETA    
       LEFT join XMETA.datastagex_dsstage stage_OUT     on pout_id.container_rid = stage_OUT.xmeta_repos_object_id_xmeta
where 1=1 
  --and job.NAME_XMETA = 'IFRS9_Contract_NonRetail_DST_prod'
  --and job.NAME_XMETA = 'IFRS9_Contract_NonRetail_KRD_prod'  
      ),
object_hierarchy as
(
select b.*,
 (
        SELECT min( STAGE.STAGETYPE_XMETA)  
             FROM   XMETA.datastagex_dsjobdef job       
               join XMETA.datastagex_dsstage stage  on job.xmeta_repos_object_id_XMETA = stage.container_rid
            WHERE job.DSNAMESPACE_XMETA = b.PROJECT
               AND STAGE.NAME_XMETA = b.root_name
               AND job.NAME_XMETA =  b.job_name
       ) root_STAGE_TYPE
       /*
       ,(
        SELECT min( TO_NCHAR(substr(stage.LONGDESCRIPTION_XMETA,1,2000)))  
             FROM   XMETA.datastagex_dsjobdef job       
               join XMETA.datastagex_dsstage stage  on job.xmeta_repos_object_id_XMETA = stage.container_rid
            WHERE job.DSNAMESPACE_XMETA = b.PROJECT
               AND STAGE.NAME_XMETA = b.child_name
               AND job.NAME_XMETA =  b.job_name
               and TO_NCHAR(substr(stage.LONGDESCRIPTION_XMETA,1,2000)) is not null
       ) STAGE_DESC
       */
from (
 select 
 job_name,
 job_XMETA_REPOS_OBJECT_ID_XMETA,
      LPAD (' ', (LEVEL - 1) * 4, ' ') || child_name AS child_name_lev ,  
      SYS_CONNECT_BY_PATH (child_name, '/') PATH ,    
      connect_by_root(child_name) as root_name,
      connect_by_root(child) as root_id,
       --'Connector' root_STAGE_TYPE, 
       --f_STAGE_TYPE(p_STAGE_NAME => connect_by_root(child_name), P_JOB_NAME=> job_name, P_PROJECT => a.PROJECT) root_STAGE_TYPE,
       --f_STAGE_TYPE(cast('TB0_CONTRACT' as nvarchar2(200)), cast('IFRS9_Contract_NonRetail_WSS_prod' as nvarchar2(200)),  cast('RBADWH-PE:IFRS9' as nvarchar2(200))) root_STAGE_TYPE,       
      --child,
      --parent,
      child_name,
      parent_name,
      STAGETYPE,
      sHORTDESCRIPTION_XMETA,
      LONGDESCRIPTION_XMETA,
      a.PROJECT,
      child object_id
      from (
      --select  XMETA_REPOS_OBJECT_ID_XMETA_M3 child,         null parent,                             M3 child_name, null parent_name, STAGETYPE_m3 STAGETYPE, XMETA_REPOS_OBJECT_ID_XMETA_M1 XMETA_REPOS_OBJECT_ID_XMETA,job_name,job_XMETA_REPOS_OBJECT_ID_XMETA,PROJECT  from stage_links
      --union all
      select XMETA_REPOS_OBJECT_ID_XMETA_M2 child,          XMETA_REPOS_OBJECT_ID_XMETA_M3   parent, M2 child_name, m3   parent_name, STAGETYPE_m2 STAGETYPE, XMETA_REPOS_OBJECT_ID_XMETA_M2 XMETA_REPOS_OBJECT_ID_XMETA,job_name,job_XMETA_REPOS_OBJECT_ID_XMETA,SHORTDESCRIPTION_XMETA_m1 sHORTDESCRIPTION_XMETA,LONGDESCRIPTION_XMETA_m1 LONGDESCRIPTION_XMETA,PROJECT  from stage_links
      union all
      select XMETA_REPOS_OBJECT_ID_XMETA_M1 child,          XMETA_REPOS_OBJECT_ID_XMETA_M2   parent, M1 child_name, m2   parent_name, STAGETYPE_m1 STAGETYPE, XMETA_REPOS_OBJECT_ID_XMETA_M3 XMETA_REPOS_OBJECT_ID_XMETA,job_name,job_XMETA_REPOS_OBJECT_ID_XMETA,SHORTDESCRIPTION_XMETA_m3 sHORTDESCRIPTION_XMETA,LONGDESCRIPTION_XMETA_m3 LONGDESCRIPTION_XMETA,PROJECT  from stage_links 
      )      a
    CONNECT BY nocycle PRIOR   CHILD = PARENT
    --START WITH child_name = 'TB0_CONTRACT'
    START WITH parent  is null
    ) b   
)  
--
-- Main SQL
--
select * from   (
select 'Da li se radi u RET- Retail ili NRT - NonRetail' ret_nrt,
'Šifra applikacije: OVD - Overdraft, OKV - okviri,...' APPLICATION_ID,
'Finevare DSA tablica u koju se upisuje vrijednost ' TARGET_TABLE,
'Finevare DSA kolona u koju se upisuje vrijednost' TARGET_column_name,
'Izraz za mapiranje vrijednosti' column_mapping,
'Tip izvora podataka, da li dolazi direktno, iz HASHa ili je neka fiksna skalarna vrijednost' DATA_SOURCE_TYPE,
to_clob('SQL za dohvat podataka') SQL_direct,
to_clob('SQL za dohvat podataka koji puni ulazni HASH file') SQL_hash_stage_input,
'--> u desnim kolonama nalaze se tehnički detalji Datastage objekata -->' delim,
 cast('DS job koji puni DSA tablicu'  as nvarchar2(100)) target_job,
 cast('Putanja stageva unutar target joba'  as nvarchar2(100))  TARGET_JOB_STAGE_PATH,
 cast('Ime prvog stage odakle vrijednost dolazi'  as nvarchar2(100))  TARGET_JOB_SOURCE_STAGE_NAME,
 cast('Opis stagea'  as nvarchar2(100))  TARGET_JOB_SOURCE_STAGE_desc,
cast( 'Tip stage prvog izvora vrijednosti'  as nvarchar2(100)) TARGET_JOB_SOURCE_STAGE_TYPE,
 cast('ime HASH datoteke'  as varchar2(100)) TARGET_JOB_SOURCE_HASH_FILE_NAME,
 cast('DS ime joba koji puni ulazni HASH datoteku'  as nvarchar2(100)) source_hash_JOB,
 cast('Ime HASH stage odakle dolazi vrijednost' as nvarchar2(100)) SOURCE_HASH_STAGE_NAME,
 cast('DS HASH ime datoteke koja se koristi za punjenje DSA tablice'  as varchar2(100)) source_hash_file_name,
 cast('DS opis stage-a koji sa SQL koji puni HASH za punjenje DSA tablice'  as nvarchar2(100)) source_hash_stage_description,
 'Interna oznaka izvora vrijednosti' INT_META_DATA_SOURCE,
1 order_by 
  from dual  union all
SELECT 
DAT.RET_NRT         RET_NRT,
DAT.APPLICATION_ID  APPLICATION_ID, 
decode(DAT.TARGET_TABLE
,'Copy_of_DSA_BEVENT','DSA_BEVENT'
,'Copy_2_of_DSA_BEVENT','DSA_BEVENT'
,DAT.TARGET_TABLE
)    TARGET_TABLE,
 DAT.COLUMN_NAME    TARGET_COLUMN_NAME
,DAT.COLUMN_MAPPING COLUMN_MAPPING
,CASE
    WHEN R.ROOT_STAGE_TYPE LIKE '%Connector' THEN
    'direct SQL in target job'
    WHEN R.ROOT_STAGE_TYPE LIKE '%Hash%' THEN
    'From HASH File'
    WHEN INSTR(DAT.COLUMN_MAPPING,'.') != 0THEN
    'Fiksna vrijednost'
    else
    ''
END DATA_SOURCE_TYPE
-- iznimka kada je izvor DWHRBA.IFRS_ACCOUT_DATASET onda se uzima iz pravog izvora jer je DWHRBA.IFRS_ACCOUT_DATASET temporary tablica
,CASE
    WHEN INSTR(SQLS.SELECT_STATEMENT,'DWHRBA.IFRS_ACCOUT_DATASET') >0 THEN    
        (SELECT S.BEFORE_STATEMENT 
        FROM SQLS S
        WHERE  
        (
            (
            S.JOB_NAME = 'AccountPreJobNonRetail_New_test_naknade'
            AND 
            DAT.RET_NRT = 'NRT'
            )
            OR
            (
            S.JOB_NAME = 'AccountPreJobRetail_New_test_def_naknade'
            AND 
            DAT.RET_NRT = 'RET'
            )
        )
        AND S.STAGE_NAME = 'TARGET_DATA_SET')
    ELSE
        SQLS.SELECT_STATEMENT
    END SQL_DIRECT
,SQLS_HASH_FILL.SELECT_STATEMENT    SQL_HASH_STAGE_INPUT
,'--> Tehnički detalji -->' delim
,DAT.JOB_NAME               TARGET_JOB
,R.PATH                         TARGET_JOB_STAGE_PATH
,R.ROOT_NAME                         TARGET_JOB_SOURCE_STAGE_NAME
,(
        SELECT min( TO_NCHAR(substr(stage.LONGDESCRIPTION_XMETA,1,2000)))  
             FROM   XMETA.datastagex_dsjobdef job       
               join XMETA.datastagex_dsstage stage  on job.xmeta_repos_object_id_XMETA = stage.container_rid
            WHERE job.DSNAMESPACE_XMETA = dat.JOB_PROJECT
               AND STAGE.NAME_XMETA =R.ROOT_NAME
               AND job.NAME_XMETA =  DAT.JOB_NAME 
               and TO_NCHAR(substr(stage.LONGDESCRIPTION_XMETA,1,2000)) is not null
       )            TARGET_JOB_SOURCE_STAGE_desc
,R.ROOT_STAGE_TYPE                         TARGET_JOB_SOURCE_STAGE_TYPE  
,HASHFILES.HASH_FILE_NAME  TARGET_JOB_SOURCE_HASH_FILE_NAME
,HASHFILESFILL.JOB_NAME         SOURCE_HASH_JOB
,HASHFILESFILL.HASH_STAGE_NAME  SOURCE_HASH_STAGE_NAME
,HASHFILESFILL.HASH_FILE_NAME   SOURCE_HASH_FILE_NAME
,HASHFILESFILL.SHORTDESCRIPTION_XMETA SOURCE_HASH_STAGE_DESCRIPTION
,DAT.INT_META_DATA_SOURCE
,2 ORDER_BY 
/*
,'*************** lINKS:'
,L.*
,'*************** sqls:'
,SQLS.*
,'*************** hashFiles:'
,HASHFILES.*
,'*************** r_hash_fill:'
,R_HASH_FILL.*
,'*************** sqls_hash_fill:'
,SQLS_HASH_FILL.*
*/
 FROM   (
SELECT 
  DISTINCT 
  tb8.JOB_PROJECT,
  TB8.TARGET_TABLE,
  ROWNUM AS COL_ID, 
  TB8.COLUMN_NAME, 
  TB8.COLUMN_MAPPING,  
  TB8.LNK_XMETA_REPOS_OBJECT_ID_XMETA,
  TB8.LINK_NAME,
  TB8.JOB_NAME,
  TB8.JOB_XMETA_REPOS_OBJECT_ID_XMETA,
  'mixed' MAPPING_TYPE,
  CASE 
    WHEN TB8.FLOWAR_COLID IS NOT NULL THEN 'CONTAINS_FLOWVARIABLE_XMETA'
    ELSE 'DSFLOWVARPROPS_XMETA'
  END AS MAPING_SOURCE
  ,TB8.APPLICATION_ID
  ,TB8.RET_NRT
  ,'TB8' INT_META_DATA_SOURCE
FROM TB8
WHERE (SELECT MAX(COLUMN_NAME) FROM TB4  WHERE TB4.JOB_NAME = TB8.JOB_NAME AND TB4.COLUMN_NAME = TB8.COLUMN_NAME) IS NULL
UNION ALL
-- ako nemamo kombinirani maping onda uzimamo samo kolone iz flowvariable
-- ovo uključujemo sa where uvjetom ako u prethodnom upitu dobijemo da je vijrednost column_name null, samo ima jedan redak
SELECT 
 tb4.JOB_PROJECT,
  TB4.TARGET_TABLE,
  TB4.COL_ID,
  TB4.COLUMN_NAME,
  TB4.COLUMN_MAPPING,
  TB4.LNK_XMETA_REPOS_OBJECT_ID_XMETA,
  TB4.LINK_NAME,
  TB4.JOB_NAME,
  TB4.JOB_XMETA_REPOS_OBJECT_ID_XMETA,
  'clean' MAPPING_TYPE,
  'CONTAINS_FLOWVARIABLE_XMETA' AS MAPING_SOURCE
  ,TB4.APPLICATION_ID
  ,TB4.RET_NRT
  ,'TB4' INT_META_DATA_SOURCE
FROM TB4
--where 1=1 and   not exists (select 2  FROM TB8 where 1=1 and   tb8.job_name = tb4.job_name  and tb8.column_name = TB4.column_name)
--where (SELECT max(tb8_2.column_name) FROM TB8 tb8_2 where tb8_2.job_name = tb4.job_name  and tb8_2.column_name = TB4.column_name) is  null
) DAT
  JOIN STAGE_IN_OUT STAGE_OUT ON   STAGE_OUT.LNK_XMETA_REPOS_OBJECT_ID_XMETA = DAT.LNK_XMETA_REPOS_OBJECT_ID_XMETA -- <<<------ ovo je početni link ToDsa
  LEFT JOIN OBJECT_HIERARCHY R 
        ON R.CHILD_NAME = dat.target_table--'DSA_CONTRACT' 
       AND R.ROOT_STAGE_TYPE IN( 'CHashedFileStage','OracleConnector','DB2Connector')
       AND R.JOB_XMETA_REPOS_OBJECT_ID_XMETA = DAT.JOB_XMETA_REPOS_OBJECT_ID_XMETA
       --
       AND STAGE_OUT.STAGEOUT_NAME = dat.target_table   
       AND INSTR(DAT.COLUMN_MAPPING,'.') != 0
  LEFT JOIN STAGE_LINKS L 
        ON DAT.JOB_NAME = L.JOB_NAME 
        AND  
        (
            (
            DAT.JOB_NAME NOT IN ('IFRS9_Account_NonRetail_KKR_PPZ_s_nakn','IFRS9_Account_Retail_KKR_TRC_PPZ_test_naknade')
            AND 
            (INSTR(DAT.COLUMN_MAPPING,NVL(L.M2,'-XXX')||'.' ) > 0 OR (DAT.COLUMN_MAPPING  NOT IN ('LOAD_DATE','0','1') AND INSTR(DAT.COLUMN_MAPPING,NVL(L.M2,'-XXX')||'.' ) = 0)) 
            )
            OR
            (
            DAT.JOB_NAME IN ('IFRS9_Account_NonRetail_KKR_PPZ_s_nakn','IFRS9_Account_Retail_KKR_TRC_PPZ_test_naknade')
            AND L.M3 NOT IN ('TEMP_WRITE_OFF','CARDHOLDER_DETAIL')
            )
        ) 
        AND L.M3 = R.ROOT_NAME
 -- TRAŽIM ILI sql ILI hash
 LEFT JOIN SQLS 
         ON SQLS.XMETA_REPOS_OBJECT_ID_XMETA = L.XMETA_REPOS_OBJECT_ID_XMETA_M3 --and instr(upper(sqls.select_statement),upper(dat.column_mapping)) >0  --SQL od stage koji direktno u jobu za modul 
         AND 
         (
         DAT.JOB_NAME IN ('IFRS9_Account_NonRetail_KKR_PPZ_s_nakn','IFRS9_Account_Retail_KKR_TRC_PPZ_test_naknade')
         AND
         INSTR(DAT.COLUMN_MAPPING,'.') != 0         
         OR
         (
         DAT.JOB_NAME NOT IN ('IFRS9_Account_NonRetail_KKR_PPZ_s_nakn','IFRS9_Account_Retail_KKR_TRC_PPZ_test_naknade')
         AND
         INSTR(DAT.COLUMN_MAPPING,NVL(L.M2,'-XXX')||'.' ) > 0
         )         
         )
     --and instr(upper(sqls.select_statement),upper(dat.column_mapping)) > 0 
     --AND SUBSTR()
 LEFT JOIN HASHFILES 
         ON DAT.JOB_XMETA_REPOS_OBJECT_ID_XMETA = HASHFILES.JOB_XMETA_REPOS_OBJECT_ID_XMETA 
        AND HASHFILES.STG_XMETA_REPOS_OBJECT_ID_XMETA =  L.XMETA_REPOS_OBJECT_ID_XMETA_M3 
        AND HASHFILES.READ_WRITE = 'read' -- hash iz kojega se čita
        AND INSTR(DAT.COLUMN_MAPPING,NVL(L.M2,'-XXX')||'.' ) > 0
 LEFT JOIN HASHFILES HASHFILESFILL 
         ON DAT.JOB_XMETA_REPOS_OBJECT_ID_XMETA != HASHFILESFILL.JOB_XMETA_REPOS_OBJECT_ID_XMETA 
        AND HASHFILESFILL.HASH_FILE_NAME =  HASHFILES.HASH_FILE_NAME 
        AND HASHFILESFILL.READ_WRITE = 'write'  
        AND HASHFILESFILL.JOB_NAME IN (SELECT IFRS9_JOBS.JOB_NAME FROM IFRS9_JOBS )-- hash ¸u kojem se piše
 LEFT JOIN OBJECT_HIERARCHY R_HASH_FILL 
         ON R_HASH_FILL.CHILD_NAME = HASHFILESFILL.HASH_STAGE_NAME
        AND R_HASH_FILL.JOB_NAME = HASHFILESFILL.JOB_NAME   
 LEFT JOIN SQLS SQLS_HASH_FILL 
         ON SQLS_HASH_FILL.JOB_NAME = HASHFILESFILL.JOB_NAME 
        AND SQLS_HASH_FILL.STAGE_NAME = R_HASH_FILL.ROOT_NAME   -- konektor koji puni SQL hash 
WHERE 1=1 
--and dat.column_name = 'ID_PRODUCT'
--AND DAT.COLUMN_NAME = 'ORIGINATION_DATE'
AND DAT.JOB_NAME = 'Fee_GAR' 
--AND DAT.APPLICATION_ID = 'FOR'
AND RET_NRT = 'RET'
--
--and l.m3 = 'TB0_ACCOUNT'
--
-- barem jedan sql mora postojati
--
AND 
(
SQLS.XMETA_REPOS_OBJECT_ID_XMETA           IS NOT NULL
OR
SQLS_HASH_FILL.XMETA_REPOS_OBJECT_ID_XMETA IS NOT NULL
OR
INSTR(DAT.COLUMN_MAPPING,'.') = 0
)
)
ORDER BY 
order_by,
RET_NRT         ,
APPLICATION_ID  , 
TARGET_TABLE,
TARGET_COLUMN_NAME    
