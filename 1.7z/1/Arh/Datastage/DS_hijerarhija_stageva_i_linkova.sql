WITH stage_links AS
   (   
   select /*+ materialize */
       stage_in.name_xmeta  m1,    
       link_in.name_xmeta  m2,
       stage_OUT.name_xmeta  m3,
       STAGE_IN.STAGETYPE_XMETA    STAGETYPE_m1,
       CAST('LINK' AS NVARCHAR2(4))    STAGETYPE_m2,
       stage_OUT.STAGETYPE_XMETA    STAGETYPE_m3,
       STAGE_IN.XMETA_REPOS_OBJECT_ID_XMETA XMETA_REPOS_OBJECT_ID_XMETA_M1,
       link_in.XMETA_REPOS_OBJECT_ID_XMETA XMETA_REPOS_OBJECT_ID_XMETA_M2,
       stage_OUT.XMETA_REPOS_OBJECT_ID_XMETA XMETA_REPOS_OBJECT_ID_XMETA_M3   
FROM XMETA.datastagex_dsjobdef job
       join XMETA.datastagex_dsstage stage_in     on job.xmeta_repos_object_id_XMETA = stage_in.container_rid
      left join  XMETA.datastagex_dsinputpin pin_id on pin_id.container_rid = stage_in.xmeta_repos_object_id_xmeta
      left  join XMETA.datastagex_dslink link_in on pin_id.xmeta_repos_object_id_xmeta = LINK_IN.TO_INPUTPIN_XMETA 
      left join  XMETA.datastagex_dsoutputpin pout_id on pout_id.xmeta_repos_object_id_xmeta = LINK_IN.FROM_OUTPUTPIN_XMETA    
       LEFT join XMETA.datastagex_dsstage stage_OUT     on pout_id.container_rid = stage_OUT.xmeta_repos_object_id_xmeta
where 1=1  and job.DSNAMESPACE_XMETA = 'RBADWH-PE:IFRS9'
  --and job.NAME_XMETA = 'IFRS9_Contract_NonRetail_DST_prod'
  and job.NAME_XMETA = 'IFRS9_Contract_NonRetail_WSS_prod'  
      )
, object_hierarchy as
(
 select 
      LPAD (' ', (LEVEL - 1) * 4, ' ') || child_name AS child_name_lev ,      
      child,
      parent,
      child_name,
      parent_name,
      STAGETYPE,
      child object_id
      from (
      --select  XMETA_REPOS_OBJECT_ID_XMETA_M3 child,         null parent,                             M3 child_name, null parent_name, STAGETYPE_m3 STAGETYPE, XMETA_REPOS_OBJECT_ID_XMETA_M1 XMETA_REPOS_OBJECT_ID_XMETA from dat
      --union all
      select XMETA_REPOS_OBJECT_ID_XMETA_M2 child,          XMETA_REPOS_OBJECT_ID_XMETA_M3   parent, M2 child_name, m3   parent_name, STAGETYPE_m2 STAGETYPE, XMETA_REPOS_OBJECT_ID_XMETA_M2 XMETA_REPOS_OBJECT_ID_XMETA from stage_links
      union all
      select XMETA_REPOS_OBJECT_ID_XMETA_M1 child,          XMETA_REPOS_OBJECT_ID_XMETA_M2   parent, M1 child_name, m2   parent_name, STAGETYPE_m1 STAGETYPE, XMETA_REPOS_OBJECT_ID_XMETA_M3 XMETA_REPOS_OBJECT_ID_XMETA from stage_links 
      )      
    CONNECT BY nocycle PRIOR   CHILD = PARENT
    START WITH child_name = 'TB0_CONTRACT'
    --START WITH parent  is null
)     
select * from   object_hierarchy 
      
      
            
     