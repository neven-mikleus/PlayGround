select * from   
(

    SELECT ROWNUM AS RNO,
           --lpad(JOB_NAME, level*2,' ') JOB_NAME_h,
           LPAD (' ', (LEVEL - 1) * 4, ' ') || JOB_NAME AS JOB_NAME_h,
           JOB_NAME,
           PAR_JOB_NAME,
           PROJECT_C,
           PAR_PROJECT,
           LEVEL LEV,
           SYS_CONNECT_BY_PATH (PAR_JOB_NAME, '/') PATH1 ,
           sub_order,
           stage_name
      FROM (SELECT OBJ.JOBNAME_XMETA AS JOB_NAME,
                   JOBS.NAME_XMETA AS PAR_JOB_NAME,
                   JOBS.DSNAMESPACE_XMETA PAR_PROJECT,
                   JOBS2.DSNAMESPACE_XMETA PROJECT_C,
                   --obj.nextid_xmeta sub_order,
                   --dbms_lob.substr(obj.inputpins_xmeta,200)  sub_order,
                   obj.internalid_xmeta  sub_order,
                   obj.NAME_XMETA stage_name
              FROM XMETA.DATASTAGEX_DSSTAGE OBJ,
                   XMETA.DATASTAGEX_DSJOBDEF JOBS,
                   XMETA.DATASTAGEX_DSJOBDEF JOBS2
             WHERE     OBJ.OF_JOBDEF_XMETA = JOBS.XMETA_REPOS_OBJECT_ID_XMETA
                   AND OBJ.STAGETYPECLASSNAME_XMETA = 'JSJobActivity'
                   AND OBJ.OF_JOBDEF_XMETA = JOBS2.XMETA_REPOS_OBJECT_ID_XMETA)
CONNECT BY NOCYCLE PRIOR JOB_NAME = PAR_JOB_NAME
START WITH PAR_JOB_NAME IN ('IFRS9_Retail_WithCopy_PROD')
order siblings by sub_order desc

) order by 
