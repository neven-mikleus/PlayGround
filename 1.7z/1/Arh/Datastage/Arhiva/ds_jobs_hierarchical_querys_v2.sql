WITH TB1 AS (
        SELECT * 
          FROM (
        -- za sve ni�e na�ene kompajle tra�imo zadnje pokretanje
        SELECT
          T1.JOBID,
          T1.JOBNAME,
          JR.CREATIONTIMESTAMP,
          JR.RUNSTARTTIMESTAMP,
          JR.RUNENDTIMESTAMP,
          JR.ELAPSEDRUNSECS,
          JR.RUNTYPE,
          JR.RUNMAJORSTATUS,
          JR.RUNMINORSTATUS,
          JR.ISUSERNAME,
          JR.DSUSERNAME,
          ROW_NUMBER() OVER (PARTITION BY JR.JOBID ORDER BY JR.CREATIONTIMESTAMP DESC) RN_RUN, -- uzimamo samo zadnje vrijeme
          1 AS JEDAN
        FROM (
          -- tra�imo zadnje vrijeme kompaliranja za sve jobove te iz toga dohva�amo jobid
          SELECT * FROM (
            SELECT
              JOBID,
              JOBNAME,
              COMPILATIONTIMESTAMP,
              ROW_NUMBER() OVER (PARTITION BY JOBNAME ORDER BY COMPILATIONTIMESTAMP DESC) RN -- uzimamo samo zadnje vrijeme
            FROM DSODB.JOBEXEC
          ) WHERE RN = 1 -- uzimamo samo zadnje vrijeme
        ) T1
        LEFT JOIN DSODB.JOBRUN JR
          ON JR.JOBID = T1.JOBID
        ) WHERE RN_RUN = 1 -- uzimamo samo zadnje vrijeme
), stages as
(
  select
    lnk.XMETA_REPOS_OBJECT_ID_XMETA link_id,
    JB.DSNAMESPACE_XMETA ds_project,
    jb.CATEGORY_XMETA job_folder,
    stg.name_xmeta stage_name,
    lnk.name_xmeta link_name,
    jb.name_xmeta job_name,
    stg.stagetype_xmeta,
    stg.HAS_OUTPUTPIN_XMETA,
    OUTPUTPINS_XMETA,
    lnk.HAS_PARAMETERVAL_XMETA link_params,
    stg.HAS_PARAMETERVAL_XMETA stage_params,
    1 as jedan
  from xmeta.DATASTAGEX_DSLINK lnk
  left join XMETA.DATASTAGEX_DSOUTPUTPIN out_pin
    on out_pin.XMETA_REPOS_OBJECT_ID_XMETA = lnk.FROM_OUTPUTPIN_XMETA
  left join XMETA.DATASTAGEX_DSSTAGE stg
    on stg.XMETA_REPOS_OBJECT_ID_XMETA = out_pin.CONTAINER_RID
  left join xmeta.DATASTAGEX_DSJOBDEF jb
    on jb.XMETA_REPOS_OBJECT_ID_XMETA = lnk.XMETA_LOCKINGROOT_XMETA
)
    SELECT ROWNUM AS RNO,
           --lpad(JOB_NAME, level*2,' ') JOB_NAME_h,
           LPAD (' ', (LEVEL - 1) * 4, ' ') || dat.JOB_NAME AS JOB_NAME_h,
           --(select ELAPSEDRUNSECS from   TB1 where 1=1 and  TB1.JOBNAME = dat.JOB_NAME) last_job_duration_sec,
           dat.JOB_NAME,
           dat.PAR_JOB_NAME,
           dat.PROJECT_C,
           dat.PAR_PROJECT,
           LEVEL LEV,
           SYS_CONNECT_BY_PATH (dat.PAR_JOB_NAME, '/') PATH1 ,
           dat.sub_order,
           dat.stage_name
      FROM (SELECT OBJ.JOBNAME_XMETA AS JOB_NAME,
                   JOBS.NAME_XMETA AS PAR_JOB_NAME,
                   JOBS.DSNAMESPACE_XMETA PAR_PROJECT,
                   JOBS2.DSNAMESPACE_XMETA PROJECT_C,
                   --obj.nextid_xmeta sub_order,
                   --dbms_lob.substr(obj.inputpins_xmeta,200)  sub_order,
                   obj.internalid_xmeta  sub_order,
                   obj.NAME_XMETA stage_name
              FROM XMETA.DATASTAGEX_DSSTAGE OBJ,
                   XMETA.DATASTAGEX_DSJOBDEF JOBS,
                   XMETA.DATASTAGEX_DSJOBDEF JOBS2
             WHERE     OBJ.OF_JOBDEF_XMETA = JOBS.XMETA_REPOS_OBJECT_ID_XMETA
                   AND OBJ.STAGETYPECLASSNAME_XMETA = 'JSJobActivity'
                   AND OBJ.OF_JOBDEF_XMETA = JOBS2.XMETA_REPOS_OBJECT_ID_XMETA) dat
CONNECT BY NOCYCLE PRIOR JOB_NAME = PAR_JOB_NAME
START WITH PAR_JOB_NAME IN ('IFRS9_Retail_WithCopy_PROD')
order siblings by sub_order desc

