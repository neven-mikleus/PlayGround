 SELECT ROWNUM AS RNO,
           --lpad(JOB_NAME, level*2,' ') JOB_NAME_h,
           LPAD (' ', (LEVEL - 1) * 4, ' ') || dat.JOB_NAME AS JOB_NAME_h,
           --(select ELAPSEDRUNSECS from   TB1 where 1=1 and  TB1.JOBNAME = dat.JOB_NAME) last_job_duration_sec,
           dat.JOB_NAME,
           dat.PAR_JOB_NAME,
           dat.stage_name,
           -- dat.PROJECT_C,
           dat.PAR_PROJECT,
           LEVEL LEV,
           SYS_CONNECT_BY_PATH (dat.PAR_JOB_NAME, '/') PATH1,
           dat.sub_order,
           dat.STAGETYPECLASSNAME_XMETA,
           dat.SHORTDESCRIPTION_XMETA,
           dat.longDESCRIPTION_XMETA          
      FROM (
      SELECT 
      COALESCE(OBJ.JOBNAME_XMETA,OBJ.NAME_XMETA) AS JOB_NAME,
      --OBJ.JOBNAME_XMETA AS JOB_NAME,
                   OBJ.NAME_XMETA stage_name,
                   COALESCE(JOBS.NAME_XMETA,OBJ.NAME_XMETA ) AS PAR_JOB_NAME,
                   --JOBS.NAME_XMETA AS PAR_JOB_NAME,
                   JOBS.DSNAMESPACE_XMETA PAR_PROJECT,                 
                   obj.internalid_xmeta sub_order,
                   OBJ.STAGETYPECLASSNAME_XMETA,
                    OBJ.NAME_XMETA,
                    obj.has_inputpin_xmeta,
                    obj.has_outputpin_xmeta,
                    obj.internalid_xmeta,
                    obj.nextid_xmeta,
                    obj.SHORTDESCRIPTION_XMETA,
                    obj.longDESCRIPTION_XMETA
                    --oBJ.STAGETYPECLASSNAME_XMETA                   
                    --obj.inputpin_xmeta
                    --obj.outputpin_xmeta
              FROM XMETA.DATASTAGEX_DSSTAGE OBJ,
                   XMETA.DATASTAGEX_DSJOBDEF JOBS,
                   XMETA.DATASTAGEX_DSJOBDEF JOBS2
             WHERE     OBJ.OF_JOBDEF_XMETA = JOBS.XMETA_REPOS_OBJECT_ID_XMETA
                   --AND OBJ.STAGETYPECLASSNAME_XMETA = 'JSJobActivity'
                   AND OBJ.OF_JOBDEF_XMETA = JOBS2.XMETA_REPOS_OBJECT_ID_XMETA                       
                   --AND JOBS.DSNAMESPACE_XMETA = pro.project_name                  
                   ) DAT
            -- left join sqls on sqls.stage_name = dat.stage_name and sqls.job_name = dat.PAR_JOB_NAME and sqls.project_name= dat.PAR_PROJECT
                   --CONNECT BY NOCYCLE PRIOR DAT.JOB_NAME = DAT.PAR_JOB_NAME
                   --START WITH PAR_JOB_NAME IN ('ExportDataSeq')             
--
--
--             
CONNECT BY NOCYCLE PRIOR dat.JOB_NAME = dat.PAR_JOB_NAME
START WITH PAR_JOB_NAME IN ('IFRS9_Retail_WithCopy_PROD')
--START WITH PAR_JOB_NAME IN ('ExportDataSeq')
order siblings by sub_order desc