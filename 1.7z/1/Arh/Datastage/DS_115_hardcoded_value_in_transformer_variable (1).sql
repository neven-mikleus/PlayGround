-- stage variable transformera
-- tražimo transformer, job u kojem se nalazi neka mapirana ili hardkodirana vrijednost u stage varijabli
select
  jb.dsnamespace_xmeta job_project,
  jb.category_xmeta job_folder,
  jb.name_xmeta job_name,
  flw.name_xmeta stage_var_name,
  der.PARSEDEXPRESSION_XMETA stage_Var_expr,
  --der.EXPRESSION_XMETA,
  stg.name_xmeta transformer_name,
  1 as jedan
from XMETA.DATASTAGEXDSDERIVATION der
left join XMETA.datastagexdsflowvaribl flw
  on flw.XMETA_REPOS_OBJECT_ID_XMETA = der.DERIVES_FLOWVARIABLE_XMETA
join XMETA.DATASTAGEX_DSSTAGE stg -- idemo na inner join da maknemo kolone iz linkova, zanimaju nas samo stage varijable
  on stg.XMETA_REPOS_OBJECT_ID_XMETA = flw.CONTAINER_RID
left join xmeta.DATASTAGEX_DSJOBDEF jb
  on jb.XMETA_REPOS_OBJECT_ID_XMETA = der.XMETA_LOCKINGROOT_XMETA
where 5=5
  --and der.expression_xmeta like q'#%IF ToT1.LETTER_OF_CREDIT_ID[1,2] = '82'%#'
  and der.expression_xmeta like '%HRK%'
  --and jb.dsnamespace_xmeta = 'RBADWH-P:IFRS9'
;
