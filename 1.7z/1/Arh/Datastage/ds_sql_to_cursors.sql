/*

SELECT 
DISTINCT A.REFERENCED_OWNER||'.'||A.REFERENCED_NAME
 FROM   USER_DEPENDENCIES A
WHERE NAME = 'P_NMI_IFRS_SQLS'
AND REFERENCED_TYPE = 'TABLE';

*/
DECLARE
   v_clob clob;
   v_cnt number := 1;
    v_lob_image_id NUMBER;

  v_buffer RAW (32767);
  c_buffer VARCHAR2 (32767);
  v_buffer_size BINARY_INTEGER;
  v_amount BINARY_INTEGER;
  v_pos       NUMBER (38) := 1;
  v_clob_size INTEGER;
  v_out_file UTL_FILE.file_type;
BEGIN
 v_clob := empty_clob();
 v_clob := '--'||chr(10);
 DBMS_LOB.APPEND(v_clob,'create or replace procedure p_nmi_ifrs_sqls as ');



for rec in (
with ifrs9_jobs as(
select 'IFRS9_NonRetail_WithCopy_PROD' job_name from dual union all 
select 'ExportData2_imp' job_name from dual union all 
select 'FXRate' job_name from dual union all 
select 'IFRS9_Account_NonRetail_KKR_PPZ_s_nakn' job_name from dual union all 
select 'IFRS9_Account_NonRetail_SDR_SDA_prod' job_name from dual union all 
select 'Bevent_KRD_NRT' job_name from dual union all 
select 'IFRS9_Contract_NonRetail_WSS_prod' job_name from dual union all 
select 'PaymentSchedule_NonRetail' job_name from dual union all 
select 'Chech_Duplicate_Records' job_name from dual union all 
select 'IFRS9_Account_Retail_KKR_TRC_PPZ_test_naknade' job_name from dual union all 
select 'IFRS9_Account_Retail_KKR_TRC_PPZ' job_name from dual union all 
select 'IFRS9_Collateral_Collateral_Link_NonRetail_New_VER4' job_name from dual union all 
select 'IFRS9_Contract_NonRetail_WSS_LORO_prod' job_name from dual union all 
select 'DSA_DATA_STATUS_Finish' job_name from dual union all 
select 'IFRS9_Fee_NonRetail' job_name from dual union all 
select 'IFRS9_Contract_NonRetail_OKV_prod' job_name from dual union all 
select 'IFRS9_Zero_Coupon_NonRetail' job_name from dual union all 
select 'IFRS9_Fee_Retail' job_name from dual union all 
select 'ExportData' job_name from dual union all 
select 'IFRS9_Securities_NonRetail_IN2_prod' job_name from dual union all 
select 'Fee_FAC' job_name from dual union all 
select 'IFRS9_Contract_NonRetail_FOR_test_def' job_name from dual union all 
select 'IFRS9_Contract_NonRetail_PKR_prod' job_name from dual union all 
select 'Chech_WriteOff_Contract_Mismatch' job_name from dual union all 
select 'DSA_DATA_STATUS_StartRetail_New' job_name from dual union all 
select 'IFRS9_Contract_NonRetail_LOC_prod' job_name from dual union all 
select 'IFRS9_Bevent_Seq_NRT' job_name from dual union all 
select 'IFRS9_Retail_WithCopy_PROD' job_name from dual union all 
select 'CustomerDsaClientNonRetail' job_name from dual union all 
select 'IFRS9_Contract_NonRetail_FOR_prod' job_name from dual union all 
select 'Fee_Akreditivi' job_name from dual union all 
select 'AccountPreJobRetail_New_test_def_naknade' job_name from dual union all 
select 'IFRS9_Contract_NonRetail_OKV_test_def' job_name from dual union all 
select 'Fee_GAR' job_name from dual union all 
select 'IFRS9_Contract_NonRetail_GAR_prod' job_name from dual union all 
select 'CustomerPreJob' job_name from dual union all 
select 'ExportDataSeq' job_name from dual union all 
select 'IFRS9_Contract_NonRetail_FAC_prod' job_name from dual union all 
select 'Bevent_PKR_NRT' job_name from dual union all 
select 'IFRS9_Bevent_Seq' job_name from dual union all 
select 'AccountPreJobNonRetail_New_test_naknade' job_name from dual union all 
select 'ContractPreJobRetail_test_Default' job_name from dual union all 
select 'IFRS9_Contract_Retail_GAR_test_def' job_name from dual union all 
select 'DSA_DATA_STATUS_StartNonRetail' job_name from dual union all 
select 'IFRS9_Contract_NonRetail_KRD_prod' job_name from dual union all 
select 'Fee_KRD' job_name from dual union all 
select 'Bevent_PKR' job_name from dual union all 
select 'IFRS9_Contract_NonRetail_LOC_test_def' job_name from dual union all 
select 'Fee_Okviri' job_name from dual union all 
select 'ContractPreJobNonRetail' job_name from dual union all 
select 'IFRS9_Contract_NonRetail_DST_prod' job_name from dual union all 
select 'CustomerDsaClientRetail' job_name from dual union all 
select 'Bevent_KRD' job_name from dual union all 
select 'Fee_PKR' job_name from dual union all 
select 'WriteOff_Retail_new_20191201' job_name from dual union all 
select 'IFRS9_Collateral_Collateral_Link_Retail_DONTCutHNBProvisions' job_name from dual union all 
select 'WriteOff_NRT' job_name from dual union all 
select 'IFRS9_Contract_Retail_PKR_test_def' job_name from dual union all 
select 'IFRS9_NonRetail_New_prod' job_name from dual union all 
select 'IFRS9_Contract_Retail_KRD_test_def' job_name from dual union all 
select 'PaymentSchedule_Retail' job_name from dual union all 
select 'Fee_Overdraft' job_name from dual union all 
select 'IFRS9_Retail_New' job_name from dual union all 
select 'IFRS9_Contract_Retail_DST' job_name from dual union all 
select 'WriteOff_Retail_HNB' job_name from dual 
), tb_jb_out_links as (
  select
    lnk.XMETA_REPOS_OBJECT_ID_XMETA link_id,
    JB.DSNAMESPACE_XMETA ds_project,
    jb.CATEGORY_XMETA job_folder,
    stg.name_xmeta stage_name,
    lnk.name_xmeta link_name,
    jb.name_xmeta job_name,
    stg.stagetype_xmeta,
    stg.HAS_OUTPUTPIN_XMETA,
    OUTPUTPINS_XMETA,
    lnk.HAS_PARAMETERVAL_XMETA link_params,
    stg.HAS_PARAMETERVAL_XMETA stage_params,
    1 as jedan
  from xmeta.DATASTAGEX_DSLINK lnk
  left join XMETA.DATASTAGEX_DSOUTPUTPIN out_pin
    on out_pin.XMETA_REPOS_OBJECT_ID_XMETA = lnk.FROM_OUTPUTPIN_XMETA
  left join XMETA.DATASTAGEX_DSSTAGE stg
    on stg.XMETA_REPOS_OBJECT_ID_XMETA = out_pin.CONTAINER_RID
  left join xmeta.DATASTAGEX_DSJOBDEF jb
    on jb.XMETA_REPOS_OBJECT_ID_XMETA = lnk.XMETA_LOCKINGROOT_XMETA
  where 7=7
    --and jb.name_xmeta = 'CollateralWCVvalue' -- ovdi ako �e� samo jedan job
    and STAGETYPE_XMETA in ('OracleConnector') --,'DB2Connector') -- ovo je tip konektora
    --and regexp_substr(JB.DSNAMESPACE_XMETA,':(.*)',1,1,'n',1) in ('RBADWH30','RBA_Reporting') --  ovdi filtriraj projekte
    and stg.has_inputpin_xmeta is null -- gledamo samo ulazne stageove
    --and lnk.name_xmeta = 'ApplicationForm'
    --and OUTPUTPINS_XMETA like '%|%' -- ako �elimo samo stageove koji imaju vi�e izlaznih linkova
    and jb.name_xmeta in (select a.job_name from ifrs9_jobs a)
),
--select * from tb_jb_out_links
--/
-- 2. --
tb_lnk_prms as (
  select
  --  regexp_substr(JB.DSNAMESPACE_XMETA,':(.*)',1,1,'n',1) ds_proj0,
--    tb_jb_out_links.*,
    link_id,
    PARAMETERNAME_XMETA,
    VALUEEXPRESSION_XMETA
  from tb_jb_out_links 
  cross join lateral (
    select
      level lvl,
      to_char(regexp_substr(link_params, '[^[:cntrl:]]+',1,level)) id
    from dual
    connect by level <= regexp_count(link_params, '[^[:cntrl:]]+',1)
  ) cjl
  left join XMETA.DATASTAGEXDSPARAMETRVL prm
    on prm.XMETA_REPOS_OBJECT_ID_XMETA = cjl.id
  where 7=7
)
,
-- 3. --
tb_stg_prms as (
  select
  --  regexp_substr(JB.DSNAMESPACE_XMETA,':(.*)',1,1,'n',1) ds_proj0,
    link_id,
    PARAMETERNAME_XMETA,
    VALUEEXPRESSION_XMETA
  from tb_jb_out_links
  cross join lateral (
    select
      level lvl,
      to_char(regexp_substr(stage_params, '[^[:cntrl:]]+',1,level)) id
    from dual
    connect by level <= regexp_count(stage_params, '[^[:cntrl:]]+',1)
  ) cjl
  left join XMETA.DATASTAGEXDSPARAMETRVL prm
    on prm.XMETA_REPOS_OBJECT_ID_XMETA = cjl.id
  where 7=7
    -- sql upit se mo�e nalaziti u XMLProperties parametru od stagea
    and prm.PARAMETERNAME_XMETA in ('XMLProperties','USERSQL')
),
-- 4. --
tb_all as (
  select
    jol.link_id,
    jol.ds_project,
    jol.job_folder,
    jol.job_name,
    jol.stage_name,
    jol.link_name,
    jol.stagetype_xmeta,
    jol.OUTPUTPINS_XMETA,    
    tlp.PARAMETERNAME_XMETA lnk_param_name,
    tlp.VALUEEXPRESSION_XMETA lnk_param_value,
    case when tlp.VALUEEXPRESSION_XMETA is not null then
      rtrim(substr(xmltype(tlp.VALUEEXPRESSION_XMETA).EXTRACT('/Properties/Usage/SQL/SelectStatement/text()').getclobval(), 10), ']>')
    else
      null
    end as SelectStatement_lnk,    
    tsp.PARAMETERNAME_XMETA stg_param_name,
    tsp.VALUEEXPRESSION_XMETA stg_param_value,
    case when tsp.VALUEEXPRESSION_XMETA is not null then
      rtrim(substr(xmltype(tsp.VALUEEXPRESSION_XMETA).EXTRACT('/Properties/Usage/SQL/SelectStatement/text()').getclobval(), 10), ']>')
    else
      null
    end as SelectStatement_stg,
    tlp1.VALUEEXPRESSION_XMETA LNK_USERSQL,
    tsp1.VALUEEXPRESSION_XMETA STG_USERSQL,
    1 as jedan
  from tb_jb_out_links jol -- dohva�amo sve linkove od db2 konektora i same kontektore, naziv joba
  left join tb_lnk_prms tlp -- spajamo sa paramerima od linkova
    on jol.link_id = tlp.link_id
    and tlp.PARAMETERNAME_XMETA = 'XMLProperties'
  left join tb_lnk_prms tlp1 -- spajamo sa paramerima od linkova
    on jol.link_id = tlp1.link_id
    and tlp1.PARAMETERNAME_XMETA = 'USERSQL'
  left join tb_stg_prms tsp -- spajamo sa paramerima od stageova
    on jol.link_id = tsp.link_id
    and tsp.PARAMETERNAME_XMETA = 'XMLProperties'
  left join tb_stg_prms tsp1 -- spajamo sa paramerima od stageova
    on jol.link_id = tsp1.link_id
    and tsp1.PARAMETERNAME_XMETA = 'USERSQL'
--   sql upit se mo�e nalaziti u parametrima od linka ili u parametrima od stagea u parametru XMLProperties, mo�e jo� biti i u USERSQL
where jol.ds_project = 'RBADWH-P:IFRS9'
and 
(
tsp.VALUEEXPRESSION_XMETA not like '%#ID_EXPORT#%'
)
) 
-- 5. --
select
  tb_all.*,
  nvl(tb_all.SelectStatement_lnk,tb_all.SelectStatement_stg) SelectStatement -- uzet �emo prvo sql upit sa linka, ako ga nema onda uzimamo sa stagea
from tb_all

) loop
   
DBMS_LOB.APPEND(v_clob,to_clob('--'||rec.job_name||'-'||rec.stage_name||chr(10)));

if rec.SelectStatement_stg is not null then
    DBMS_LOB.APPEND(v_clob,to_clob('cursor c'||v_cnt||' is'||chr(10)));
    DBMS_LOB.APPEND(v_clob,to_clob(rec.SelectStatement_stg));
    DBMS_LOB.APPEND(v_clob,to_clob(';'||chr(10)||chr(10)));
end if; 


    
    
    v_cnt := v_cnt+1;
end loop;
DBMS_LOB.APPEND(v_clob,to_clob('begin null; end;'));

delete nmi_test;
insert into nmi_test(data) values (v_clob);

commit;
  
  
end;