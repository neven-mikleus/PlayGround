-- DS87 tražimo job koji puni zadanu tablicu
-- za Juricu hragsl@2022-05-17
select
  jb.dsnamespace_xmeta ds_project,
  jb.name_xmeta job_name,
  lnk.name_xmeta link_name,
  stg.name_xmeta stage_name,
  prm.parametername_xmeta param_name,
  prm.valueexpression_xmeta param_value  
-- parametri
from xmeta.DATASTAGEXDSPARAMETRVLC2E76D84 prm -- tražimo parametre tipa 'table'
-- job
left join XMETA.DATASTAGEX_DSJOBDEFC2E76D84 jb -- vežemo parametar na job direktno da vidimo od kojeg je joba
  on jb.XMETA_REPOS_OBJECT_ID_XMETA = XMETA_LOCKINGROOT_XMETA
-- Link
-- parametri se ujedno vežu i na link
-- link nosi sql upit, naziv tablice
-- USERSQL - insert, select stagement - parametar iz prm tablice
-- TABLE - naziv tablice isto parametar na linku
left join xmeta.DATASTAGEX_DSLINKC2E76D84 lnk 
  on lnk.XMETA_REPOS_OBJECT_ID_XMETA = prm.for_jobobject_xmeta
-- izlaz iz linka ide na input pin
left join XMETA.DATASTAGEX_DSINPUTPINC2E76D84 in_pin
  on in_pin.XMETA_REPOS_OBJECT_ID_XMETA = lnk.to_inputpin_xmeta
-- input pin idena stage
left join XMETA.DATASTAGEX_DSSTAGEC2E76D84 stg
  on in_pin.of_jobcomponent_xmeta = stg.XMETA_REPOS_OBJECT_ID_XMETA
where 1=1
  -- tražimo izlazne stageove, imaju input pinove, ali nemaju outpute
  and stg.has_outputpin_xmeta is null
  and (
    lower(prm.parametername_xmeta) like '%table%'
  )
  and lower(prm.valueexpression_xmeta) like '%tb0_contract_accruals%'
;