-- tražimo mapiranje u zadanom transfomreru za zadani link u zadanom jobu
-- inače se kolone i mapiranja nalaze u flowvariable od linka, ali u rijetkim slučajevima nije tako, pa može bit kombinacija flowvariable, dsflowvarnames, props, srccols
with tb_jb as (
  -- navedi job i link za koji tražiš mapiranje
  -- stg_type ostavi ovako, to znači da tražimo link koji izlazi iz transformera, oni sadrže mapiranja
  select 
    'Applicant÷ZahtjeviTRC_SIRIUS' as job_name,
    'TransformerStage' as stg_type,
    'ApplicationForm' as link_name
  from dual
),
tb1 as (
  -- e prvo tražimo kolone i mapiranja tamo di inače nisu
  -- a to je u lnk.DSFLOWVARNAMES_XMETA (clob) - imena kolona
  -- lnk.DSFLOWVARPROPS_XMETA - mapiranja tih kolona, a ako tu nema mapiranje 
  -- onda je mapiranje iz kolone lnk.DSFLOWVARSOURCECOLUMNIDS_XMETA
  select
    jb.name_Xmeta job_name,
    lnk.name_xmeta link_name,
    cjl.*,
    to_char(regexp_substr(replace(lnk.DSFLOWVARPROPS_XMETA, chr(29), '|'), '[^|]+',1,cjl.lvl)) df_prop, -- chr29 je separator retka, ima ih onoliko koliko ima i imena u df_names, vadimo redak u kojem imamo mapiranje
    to_char(regexp_substr(replace(lnk.DSFLOWVARNAMES_XMETA, chr(29), '|'), '[^|]+',1,cjl.lvl)) df_names, -- chr29 je separator retka, vadimo imena kolona
    trim(to_char(regexp_substr(replace(lnk.DSFLOWVARSOURCECOLUMNIDS_XMETA, chr(29), '| '), '[^|]+',1,cjl.lvl))) df_srccol, -- vadimo mapiranje iz kolona
    stg.name_xmeta stg_name,
    stg.STAGETYPECLASSNAME_XMETA,
    1 as jedan
  from xmeta.DATASTAGEX_DSLINK lnk
  left join xmeta.DATASTAGEX_DSJOBDEF jb
    on jb.XMETA_REPOS_OBJECT_ID_XMETA = lnk.XMETA_LOCKINGROOT_XMETA
  left join XMETA.DATASTAGEX_DSOUTPUTPIN out_pin
    on lnk.FROM_OUTPUTPIN_XMETA = out_pin.XMETA_REPOS_OBJECT_ID_XMETA
  left join xmeta.DATASTAGEX_DSSTAGE stg
    on stg.XMETA_REPOS_OBJECT_ID_XMETA = out_pin.CONTAINER_RID
  cross join lateral (
    select
      level lvl,
      to_char(regexp_substr(lnk.DSFLOWVARNAMES_XMETA, '[^[:cntrl:]]+',1,level)) id
    from dual
    connect by level <= regexp_count(lnk.DSFLOWVARNAMES_XMETA, '[^[:cntrl:]]+',1)
  ) cjl
  join tb_jb 
    on tb_jb.job_name = jb.name_xmeta
    and tb_jb.link_name = lnk.name_xmeta
    and tb_jb.stg_type = stg.STAGETYPECLASSNAME_XMETA
  where 7=7
    --and lnk.XMETA_REPOS_OBJECT_ID_XMETA = 'c2e76d84.78bf4d29.69l5q706h.8u6nmem.07ribt.li9up5ihve4ocepfg4b8e'
--    and jb.name_xmeta = 'Applicant÷ZahtjeviTRC_SIRIUS'
--    and stg.STAGETYPECLASSNAME_XMETA = 'TransformerStage'
--    and lnk.name_xmeta = 'ApplicationForm'
)
select
  --tb1.lvl,
  tb1.job_name,
  tb1.stg_name,
  tb1.link_name,
  to_char(tb1.id) as column_name,
  to_char(nvl(regexp_substr(tb1.df_prop, '[[:cntrl:]]>P=(.*?)[[:cntrl:]]',1,1,'i',1),replace(tb1.df_srccol,';'))) col_mapping, -- ovo je mapiranje koje nema u derivation tablici, P je maping, ako nema onda je df_scrrol
--  regexp_substr(tb1.df_prop, '[[:cntrl:]]>P=(.*?)[[:cntrl:]]',1,1,'i',1) lnk_flw_cols_col_value,
--  regexp_substr(tb1.df_prop, '[[:cntrl:]]K=(.*?)[[:cntrl:]]',1,1,'i',1) is_key,
--  regexp_substr(tb1.df_prop, '[[:cntrl:]]x=(.*?)[[:cntrl:]]',1,1,'i',1) data_length,
--  regexp_substr(tb1.df_prop, '[[:cntrl:]]o=(.*?)[[:cntrl:]]',1,1,'i',1) data_type,
--  --tb1.df_prop
--  tb1.df_names,
--  tb1.df_srccol,
  1 as jedan
from tb1

union all

-- tražimo kolone koje se nalaze u flowvariable tablici, inače su samo tu, ali rijetko ponegad se nađu i gore
select
    jb.name_Xmeta job_name,
    stg.name_xmeta stg_name,
    lnk.name_xmeta link_name,
    --stg.STAGETYPECLASSNAME_XMETA,
    to_char(flw.name_xmeta) column_name,
    to_char(nvl(der.PARSEDEXPRESSION_XMETA, flw.SOURCECOLUMNID_XMETA)) column_mapping,
    --flw.*,
    1 as jedan
  from xmeta.DATASTAGEX_DSLINK lnk
  left join xmeta.DATASTAGEX_DSJOBDEF jb
    on jb.XMETA_REPOS_OBJECT_ID_XMETA = lnk.XMETA_LOCKINGROOT_XMETA
  left join XMETA.DATASTAGEX_DSOUTPUTPIN out_pin
    on lnk.FROM_OUTPUTPIN_XMETA = out_pin.XMETA_REPOS_OBJECT_ID_XMETA
  left join xmeta.DATASTAGEX_DSSTAGE stg
    on stg.XMETA_REPOS_OBJECT_ID_XMETA = out_pin.CONTAINER_RID
  cross join lateral (
    select
      level lvl,
      to_char(regexp_substr(lnk.CONTAINS_FLOWVARIABLE_XMETA, '[^[:cntrl:]]+',1,level)) id
    from dual
    connect by level <= regexp_count(lnk.CONTAINS_FLOWVARIABLE_XMETA, '[^[:cntrl:]]+',1)
  ) cjl
  left join XMETA.datastagexdsflowvaribl flw
    on flw.XMETA_REPOS_OBJECT_ID_XMETA = cjl.id
  left join XMETA.DATASTAGEXDSDERIVATION der
    on der.XMETA_REPOS_OBJECT_ID_XMETA = to_char(substr(flw.HASVALUE_DERIVATION_XMETA,2,64))
  join tb_jb 
    on tb_jb.job_name = jb.name_xmeta
    and tb_jb.link_name = lnk.name_xmeta
    and tb_jb.stg_type = stg.STAGETYPECLASSNAME_XMETA
  where 7=7
    --and lnk.XMETA_REPOS_OBJECT_ID_XMETA = 'c2e76d84.78bf4d29.69l5q706h.8u6nmem.07ribt.li9up5ihve4ocepfg4b8e'
--    and jb.name_xmeta = 'Applicant÷ZahtjeviTRC_SIRIUS'
--    and stg.STAGETYPECLASSNAME_XMETA = 'TransformerStage'
--    and lnk.name_xmeta = 'ApplicationForm'
;