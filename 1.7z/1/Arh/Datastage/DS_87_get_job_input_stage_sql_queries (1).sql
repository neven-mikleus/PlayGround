-- DS 8.7
-- Get job input stage sql queryes
select
  jb.name_xmeta job_name,
  jb.CATEGORY_XMETA job_folder,
  jb.DSNAMESPACE_XMETA job_project,
  --' #stg# ' spacer,
  stg.name_xmeta stage_name,
--  stg.STAGETYPECLASSNAME_XMETA, 
  stg.STAGETYPE_XMETA,
  --stg.CONTAINS_FLOWVARIABLE_XMETA,
  --stg.HAS_PARAMETERVAL_XMETA,
  --stg.HAS_INPUTPIN_XMETA, 
  --stg.HAS_OUTPUTPIN_XMETA,
  --stg.SHORTDESCRIPTION_XMETA,
  --cjl.id out_pin_id,
--  ' #prm# ' spacer,
  --lnk.STAGEINFO_XMETA link_stage_info,
  lnk.name_xmeta link_name,
--  lnk.CONTAINS_FLOWVARIABLE_XMETA, -- kolone
--  lnk.HAS_PARAMETERVAL_XMETA, -- parametri
  prm.PARAMETERNAME_XMETA,
  prm.VALUEEXPRESSION_XMETA,
  --cjl1.id,
  1
from XMETA.DATASTAGEX_DSJOBDEFC2E76D84 jb
left join XMETA.DATASTAGEX_DSSTAGEC2E76D84 stg
  on jb.XMETA_REPOS_OBJECT_ID_XMETA = stg.container_rid
cross join lateral (
  select
    level lvl,
    to_char(regexp_substr(stg.HAS_OUTPUTPIN_XMETA, '[^[:cntrl:]]+',1,level)) id
  from dual
  connect by level <= regexp_count(stg.HAS_OUTPUTPIN_XMETA, '[^[:cntrl:]]+',1)
) cjl
left join XMETA.DATASTAGEX_DSOUTPUTPINC2E76D84 out_pin
  on out_pin.XMETA_REPOS_OBJECT_ID_XMETA = cjl.id
left join xmeta.DATASTAGEX_DSLINKC2E76D84 lnk
  on lnk.XMETA_REPOS_OBJECT_ID_XMETA = out_pin.ISSOURCEOF_LINK_XMETA
cross join lateral (
  select
    level lvl,
    to_char(regexp_substr(lnk.HAS_PARAMETERVAL_XMETA, '[^[:cntrl:]]+',1,level)) id
  from dual
  connect by level <= regexp_count(lnk.HAS_PARAMETERVAL_XMETA, '[^[:cntrl:]]+',1)
) cjl1
left join xmeta.DATASTAGEXDSPARAMETRVLC2E76D84 prm
  on prm.XMETA_REPOS_OBJECT_ID_XMETA = cjl1.id
where jb.DSNAMESPACE_XMETA = 'HRADWH04:IFRS9'
  and jb.name_xmeta in (
    'AccountPreJobNonRetail_New_test_naknade', 'AccountPreJobRetail_New_test_def_naknade', 'Bevent_KRD', 'Bevent_KRD_NRT', 'Bevent_PKR_NRT',
    'ContractPreJobNonRetail', 'ContractPreJobRetail_test_Default', 'CopyExportData', 'CustomerDsaClientNonRetail', 'CustomerDsaClientRetail',
    'CustomerPreJob', 'DSA_DATA_STATUS_Finish', 'DSA_DATA_STATUS_StartNonRetail', 'DSA_DATA_STATUS_StartRetail_New', 'ExportData',
    'ExportData2_imp', 'ExportDataSeq', 'Fee_Akreditivi', 'Fee_FAC', 'Fee_GAR',
    'Fee_KRD', 'Fee_Okviri', 'Fee_Overdraft', 'Fee_PKR', 'FXRate',
    'IFRS9_Account_NonRetail_KKR_PPZ_s_nakn', 'IFRS9_Account_NonRetail_SDR_SDA_prod', 'IFRS9_Account_Retail_KKR_TRC_PPZ', 'IFRS9_Account_Retail_KKR_TRC_PPZ_test_naknade', 'IFRS9_Bevent_Seq',
    'IFRS9_Bevent_Seq_NRT', 'IFRS9_Collateral_Collateral_Link_NonRetail_New_VER4', 'IFRS9_Collateral_Collateral_Link_Retail_DONTCutHNBProvisions', 'IFRS9_Contract_NonRetail_DST_prod', 'IFRS9_Contract_NonRetail_FAC_prod',
    'IFRS9_Contract_NonRetail_FOR_prod', 'IFRS9_Contract_NonRetail_FOR_test_def', 'IFRS9_Contract_NonRetail_GAR_prod', 'IFRS9_Contract_NonRetail_KRD_prod', 'IFRS9_Contract_NonRetail_LOC_prod',
    'IFRS9_Contract_NonRetail_LOC_test_def', 'IFRS9_Contract_NonRetail_OKV_prod', 'IFRS9_Contract_NonRetail_OKV_test_def', 'IFRS9_Contract_NonRetail_PKR_prod', 'IFRS9_Contract_NonRetail_WSS_LORO_prod',
    'IFRS9_Contract_NonRetail_WSS_prod', 'IFRS9_Contract_Retail_DST', 'IFRS9_Contract_Retail_GAR_test_def', 'IFRS9_Contract_Retail_KRD_test_def', 'IFRS9_Contract_Retail_PKR_test_def',
    'IFRS9_Fee_NonRetail', 'IFRS9_Fee_Retail', 'IFRS9_NonRetail_New_prod', 'IFRS9_NonRetail_WithCopy_PROD', 'IFRS9_Retail_New',
    'IFRS9_Securities_NonRetail_IN2_prod', 'IFRS9_Zero_Coupon_NonRetail', 'NRT', 'PaymentSchedule_NonRetail', 'PaymentSchedule_Retail',
    'Retail', 'WriteOff_NRT', 'WriteOff_Retail_HNB', 'WriteOff_Retail_new_20191201'
  )
  --and jb.name_xmeta = 'CustomerPreJob'
  and stg.HAS_INPUTPIN_XMETA is null
  and stg.STAGETYPECLASSNAME_XMETA not in ('TransformerStage')
  and prm.parametername_xmeta in (
    'SqlRef',
    'SqlWhere',
    'SqlPrimary',
    'AFTERSQL',
    --'DESCRIPTION',
    'BEFORESQL',
    'XMLProperties',
    'USERSQL'
  )
  --and upper(prm.VALUEEXPRESSION_XMETA) like '%SELECT%'
  and prm.VALUEEXPRESSION_XMETA is not null
order by job_name, job_folder, job_project, stage_name
;