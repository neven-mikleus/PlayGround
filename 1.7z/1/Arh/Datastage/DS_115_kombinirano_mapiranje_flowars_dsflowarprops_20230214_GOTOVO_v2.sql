-- tražimo kolone i mapiranja za link koji izlazi iz transformera
  -- PARAMETRI: linije 42-44
-- mapiranje može biti na flowvariable ili dsflowarprops ili kombinacija oba
-- detektirani ključevi u DSFLOWVARPROPS_XMETA:
-- 3,n,fy,l,x,s,i,q,d,o,A,H,R,G,N,I,O,S,J,T,K,U,>1,>e,P
-- razmak između polja je chr(??)<RS>

-- link koji izlazi iz transfomrera sadrži kolone i mapiranja kolona
-- [tb4] kolone i mapiranja mogu biti u polju CONTAINS_FLOWVARIABLE_XMETA (lista IDjeva za tablicu DATASTAGEXDSFLOWVARIBL)
  -- vrijednosti nalazimo u toj tablici ili tablici DATASTAGEXDSDERIVATION
-- [tb1] kolone i mapiranja mogu biti i u poljima DSFLOWVARPROPS_XMETA,DSFLOWVARNAMES_XMETA,DSFLOWVARSOURCECOLUMNIDS_XMETA
  -- ako se tu nalaze onda se nazivi kolona nalaze u DSFLOWVARNAMES_XMETA, a mapiranja u DSFLOWVARPROPS_XMETA
  -- ako se mapiranje ne nalazi u DSFLOWVARPROPS_XMETA, onda uzimamo iz DSFLOWVARSOURCECOLUMNIDS_XMETA

with job_mapping as(
select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Account_Retail_KKR_TRC_PPZ_test_naknade'    AS TARGET_JOB, 'KKR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
/*
           select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Account_Retail_KKR_TRC_PPZ_test_naknade'    AS TARGET_JOB, 'KKR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Account_Retail_KKR_TRC_PPZ_test_naknade'    AS TARGET_JOB, 'TRC' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Account_Retail_KKR_TRC_PPZ_test_naknade'    AS TARGET_JOB, 'SDR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 --
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Contract_Retail_GAR_test_def'            AS TARGET_JOB, 'GAR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Contract_Retail_KRD_test_def'            AS TARGET_JOB, 'KRD' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Contract_NonRetail_LOC_test_def'         AS TARGET_JOB, 'LOC' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Contract_Retail_PKR_test_def'            AS TARGET_JOB, 'PKR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Contract_NonRetail_OKV_test_def'         AS TARGET_JOB, 'OKV' as APPLICATION_ID, 'RET' as  ret_nrt from dual 
 union all select 'DSA_CONTRACT' AS TARGET_TABLE, 'ToDsa' AS TARGET_TABLE_LINK, 'IFRS9_Contract_NonRetail_FOR_test_def'         AS TARGET_JOB, 'FOR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 -- write off
 union all select 'DSA_WRITE_OFF' AS TARGET_TABLE, 'ToDsa'      AS TARGET_TABLE_LINK, 'WriteOff_Retail_HNB'                          AS TARGET_JOB, 'WOF' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_WRITE_OFF' AS TARGET_TABLE, 'DSLink132'  AS TARGET_TABLE_LINK, 'WriteOff_Retail_HNB'                          AS TARGET_JOB, 'WOF' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 -- Fee
 union all select 'DSA_FEE'       AS TARGET_TABLE, 'DSA_fee'  AS TARGET_TABLE_LINK, 'Fee_GAR'        AS TARGET_JOB, 'GAR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_FEE'       AS TARGET_TABLE, 'DSA_fee'  AS TARGET_TABLE_LINK, 'Fee_KRD'        AS TARGET_JOB, 'KRD' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_FEE'       AS TARGET_TABLE, 'DSA_fee'  AS TARGET_TABLE_LINK, 'Fee_PKR'        AS TARGET_JOB, 'PKR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_FEE'       AS TARGET_TABLE, 'DSA_fee'  AS TARGET_TABLE_LINK, 'Fee_Akreditivi' AS TARGET_JOB, 'AKR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_FEE'       AS TARGET_TABLE, 'DSA_fee'  AS TARGET_TABLE_LINK, 'Fee_Okviri'     AS TARGET_JOB, 'OKV' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_FEE'       AS TARGET_TABLE, 'DSA_fee'  AS TARGET_TABLE_LINK, 'Fee_Overdraft'  AS TARGET_JOB, 'OVD' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 --Bevent
 union all select 'DSA_BEVENT'       AS TARGET_TABLE, 'DSA_bevent'  AS TARGET_TABLE_LINK, 'Bevent_KRD'  AS TARGET_JOB, 'KRD' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 union all select 'DSA_BEVENT'       AS TARGET_TABLE, 'DSA_bevent'  AS TARGET_TABLE_LINK, 'Bevent_PKR'  AS TARGET_JOB, 'PKR' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 --DSA_PAYMENT_SCHEDULE
 union all select 'DSA_PAYMENT_SCHEDULE'       AS TARGET_TABLE, 'ToPS'  AS TARGET_TABLE_LINK, 'PaymentSchedule_Retail'  AS TARGET_JOB, null as APPLICATION_ID, 'RET' as  ret_nrt from dual
 --DSA_COLLATERAL
 union all select 'DSA_COLLATERAL'       AS TARGET_TABLE, 'ToCollateral'  AS TARGET_TABLE_LINK, 'IFRS9_Collateral_Collateral_Link_DONTCutHNBProvisions'  AS TARGET_JOB, '' as APPLICATION_ID, 'RET' as  ret_nrt from dual
 */
)
,ifrs9_jobs as
(
select distinct JOB_NAME,XMETA_REPOS_OBJECT_ID_XMETA, PATH from(
SELECT 
 COALESCE(JOBS.XMETA_REPOS_OBJECT_ID_XMETA,JOBS2.XMETA_REPOS_OBJECT_ID_XMETA) AS XMETA_REPOS_OBJECT_ID_XMETA,    
      COALESCE(OBJ.JOBNAME_XMETA,OBJ.NAME_XMETA) AS JOB_NAME,
      --OBJ.JOBNAME_XMETA AS JOB_NAME,
                   OBJ.NAME_XMETA stage_name,
                   COALESCE(JOBS.NAME_XMETA,OBJ.NAME_XMETA ) AS PAR_JOB_NAME,
                    SYS_CONNECT_BY_PATH (COALESCE(OBJ.JOBNAME_XMETA,OBJ.NAME_XMETA), '/') PATH,
                   --JOBS.NAME_XMETA AS PAR_JOB_NAME,
                   JOBS.DSNAMESPACE_XMETA PAR_PROJECT,                 
                   obj.internalid_xmeta sub_order,
                   OBJ.STAGETYPECLASSNAME_XMETA,
                    OBJ.NAME_XMETA
              FROM XMETA.DATASTAGEX_DSSTAGE OBJ,
                   XMETA.DATASTAGEX_DSJOBDEF JOBS,
                   XMETA.DATASTAGEX_DSJOBDEF JOBS2
             WHERE     OBJ.OF_JOBDEF_XMETA = JOBS.XMETA_REPOS_OBJECT_ID_XMETA
                   --AND OBJ.STAGETYPECLASSNAME_XMETA = 'JSJobActivity'
                   AND OBJ.OF_JOBDEF_XMETA = JOBS2.XMETA_REPOS_OBJECT_ID_XMETA                       
                   --AND JOBS.DSNAMESPACE_XMETA = pro.project_name                  
                   CONNECT BY NOCYCLE PRIOR COALESCE(OBJ.JOBNAME_XMETA,OBJ.NAME_XMETA) = COALESCE(JOBS.NAME_XMETA,OBJ.NAME_XMETA )
START WITH COALESCE(JOBS.NAME_XMETA,OBJ.NAME_XMETA ) = 'IFRS9_Retail_WithCopy_PROD'
--,'IFRS9_NonRetail_WithCopy_PROD'
)
where 1=1 and   STAGETYPECLASSNAME_XMETA in('JSJobActivity')
),
 tb0 as (
  -- upit dohvaća link i polja iz kojih ćemo vaditi kolone i mapiranja koja se nalaze u transformeru
  -- prvo napadamo DSFLOWVARPROPS_XMETA, a kasnije DATASTAGEXDSFLOWVARIBL
  select
    JB.DSNAMESPACE_XMETA JOB_PROJECT,
    jb.name_xmeta job_name,
    JB_MAP.TARGET_TABLE,
    lnk.XMETA_REPOS_OBJECT_ID_XMETA,
    lnk.name_xmeta ,
    stg.name_xmeta transformer_name,  
    stg.XMETA_REPOS_OBJECT_ID_XMETA  transformer_XMETA_REPOS_OBJECT_ID_XMETA,
    --' -- ## -- ' spacer,
    lnk.CONTAINS_FLOWVARIABLE_XMETA,
    lnk.DSFLOWVARSOURCECOLUMNIDS_XMETA,
    lnk.DSFLOWVARNAMES_XMETA,
    lnk.DSFLOWVARPROPS_XMETA,
    jb.dsnamespace_xmeta,
    --
    lnk.FROM_OUTPUTPIN_XMETA,
    lnk.TO_INPUTPIN_XMETA,
    --
     JB_MAP.APPLICATION_ID, 
    JB_MAP.ret_nrt 
  from xmeta.DATASTAGEX_DSLINK lnk
  left join XMETA.DATASTAGEX_DSOUTPUTPIN out_pin
    on out_pin.XMETA_REPOS_OBJECT_ID_XMETA = lnk.FROM_OUTPUTPIN_XMETA
   left join XMETA.DATASTAGEX_DSOUTPUTPIN in_pin
    on in_pin.XMETA_REPOS_OBJECT_ID_XMETA = lnk.TO_INPUTPIN_XMETA
  left join XMETA.DATASTAGEX_DSSTAGE stg
    on stg.XMETA_REPOS_OBJECT_ID_XMETA = out_pin.CONTAINER_RID
  left join xmeta.DATASTAGEX_DSJOBDEF jb
    on jb.XMETA_REPOS_OBJECT_ID_XMETA = lnk.XMETA_LOCKINGROOT_XMETA
  JOIN job_mapping JB_MAP ON JB_MAP.TARGET_JOB = jb.name_xmeta AND JB_MAP.TARGET_TABLE_LINK =lnk.name_xmeta 
  where 7=7
    -- filtriramo link_id (ako imamo id brže je nego po link_name), job_name, link_name
--    and lnk.XMETA_REPOS_OBJECT_ID_XMETA = 'c2e76d84.78bf4d29.6duo7qlno.b001ar6.ja1fa1.4v74gtdurqjs1oj6fmjmg' -- ApplicationForm
--    and jb.DSNAMESPACE_XMETA = 'RBADWH-PE:RBADWH30'
--    and jb.name_xmeta = 'Applicant÷ZahtjeviTRC_SIRIUS'
--    and lnk.name_xmeta = 'ApplicationForm'
 --AND (jb.name_xmeta,lnk.name_xmeta ) IN (SELECT A.TARGET_JOB, A.TARGET_TABLE_LINK FROM  job_mapping A)
    --and jb.name_xmeta = 'IFRS9_Contract_Retail_PKR_test_def'
    --and lnk.name_xmeta = 'ToDsa'
    and jb.DSNAMESPACE_XMETA = 'RBADWH-PE:IFRS9'
),
tb1 as (
  -- razbijamo polje DSFLOWVARNAMES_XMETA u retke, separator je chr(29) - to su nazivi kolona čija mapiranja se nalaze u DSFLOWVARPROPS_XMETA
  -- ako se mapiranje na nalazi u DSFLOWVARPROPS_XMETA, onda uzimamo vrijednost iz DSFLOWVARSOURCECOLUMNIDS_XMETA
  -- sve kolone koje postoje u mapiranju za zadani link a ne nalazimo u DSFLOWVARNAMES_XMETA biti će u CONTAINS_FLOWVARIABLE_XMETA
  -- kolone iz CONTAINS_FLOWVARIABLE_XMETA će imati mapiranje u DATASTAGEXDSDERIVATION tablici
  -- redoslijed kolona je zadan u DSFLOWVARPROPS_XMETA, ali oni redovi u DSFLOWVARPROPS_XMETA koji imaju u sebi q=<broj> prije sebe moraju 
  -- ubaciti onoliki broj kolona iz DSFLOWVARNAMES_XMETA koloko se nalazi iza q
  -- npr. ako je q=2 onda moramo ubaciti 2 kolone
  -- broj redaka u DSFLOWVARNAMES_XMETA odgovara broju redaka u DSFLOWVARPROPS_XMETA, imaju isti separator chr(29)
  -- ponekad se u DSFLOWVARPROPS_XMETA neće nalaziti naziv kolone, pa ga uzimamo redoslijedom iz DSFLOWVARNAMES_XMETA
  -- radimo replace "chr(29)" sa "|" kako razbili DSFLOWVARNAMES_XMETA i DSFLOWVARPROPS_XMETA u retke
  -- prvenstveno zato što DSFLOWVARPROPS_XMETA ima još kontrolnih znakova, pa ako bi razbijali po [[:cntrl:]] ne bi išlo
  select
    lnk.name_xmeta link_name,
    lnk.transformer_name,
    lnk.job_name,
    LNK.TARGET_TABLE,
    --stg.name_xmeta transformer_name,  
    --' -- ## -- ' spacer,
    lnk.CONTAINS_FLOWVARIABLE_XMETA,
    --lnk.DSFLOWVARNAMES_XMETA,
    --lnk.DSFLOWVARSOURCECOLUMNIDS_XMETA,
    --lnk.DSFLOWVARPROPS_XMETA,
    to_char(regexp_substr(replace(lnk.DSFLOWVARNAMES_XMETA, chr(29), '|'), '[^|]+',1,cjl.lvl)) df_names, -- chr29 je separator retka, vadimo imena kolona
    to_char(regexp_substr(replace(lnk.DSFLOWVARPROPS_XMETA, chr(29), '|'), '[^|]+',1,cjl.lvl)) df_prop,
    to_char(regexp_substr(replace(lnk.DSFLOWVARSOURCECOLUMNIDS_XMETA, chr(29), '| '), '[^|]+',1,cjl.lvl)) df_src_col_id, -- ubacujemo '|;' tako da uhvatimo i prazne
    cjl.lvl,
    lnk.FROM_OUTPUTPIN_XMETA,
    lnk.TO_INPUTPIN_XMETA,
    lnk.transformer_XMETA_REPOS_OBJECT_ID_XMETA,
    lnk.APPLICATION_ID, 
    lnk.ret_nrt,
    1 as jedan
    --stg.*
  from tb0 lnk
  cross join lateral (
    -- razbojamo kolonu DSFLOWVARNAMES_XMETA u retke - vadimo nazive kolona
    select
      level lvl,
      to_char(regexp_substr(lnk.DSFLOWVARNAMES_XMETA, '[^[:cntrl:]+]',1,level)) id
    from dual
    connect by level <= regexp_count(lnk.DSFLOWVARNAMES_XMETA, '[^[:cntrl:]]+',1)
  ) cjl
)
--select * From tb1; /
,
tb2 as (
-- vadimo polja iz DSFLOWVARPROPS_XMETA:
  -- 3 - [description]
  -- y - tip kolone
  -- x - [Length]
  -- q - broj kolona koje treba ubacit prije kolone iz danog retka, a nalaze se u DATASTAGEXDSFLOWVARIBL
  -- d - [Display]
  -- o - db tip kolone [SQL type]
  -- R - naziv kolone [Column name]
  -- T - lokacija definicije tablice - iako nisam uspio naći tu lokaciju u table_definition tablici
  -- K - [Key] - ključ seta podataka
  -- >e - expression - mapiranje
  -- >P - parsed expression - mapiranje
  -- n,f,l,s,i,A,H,G,N,I,O,S,J,U,>1 - ?? - nepoznato značenje za sada
  -- ovime smo izvadili sva polja iz dwflowarnames,props, njihova mapiranja, q vrijednosti
  select
    tb1.lvl,
    df_names,
    tb1.transformer_name,
    tb1.link_name,
    tb1.job_name,
    TB1.TARGET_TABLE,
    tb1.FROM_OUTPUTPIN_XMETA,
    tb1.TO_INPUTPIN_XMETA,
    tb1.transformer_XMETA_REPOS_OBJECT_ID_XMETA,
    tb1.application_id,
    tb1.ret_nrt,
    substr(trim(df_src_col_id),2,nvl(length(trim(df_src_col_id)),2)-2) df_src_col_id,
    regexp_substr(tb1.df_prop, '[[:cntrl:]]>P=(.*?)[[:cntrl:]]',1,1,'i',1) p_polje, -- mapiranje, ako nema onda uzimamo iz DSFLOWVARSOURCECOLUMNIDS_XMETA
    regexp_substr(tb1.df_prop, '[[:cntrl:]]q=(.*?)[[:cntrl:]]',1,1,'i',1) q_polje, -- broj polja iz flowars koje treba ubaciti prije ovog polja
    regexp_substr(tb1.df_prop, '[[:cntrl:]]R=(.*?)[[:cntrl:]]',1,1,'i',1) r_polje -- naziv kolone - ne mora postojat, onda uzimamo iz DSFLOWVARNAMES_XMETA tamo je sigurno
  from tb1
)
--select * From tb2; /
,
tb3 as (
  -- detektiramo samo one kolone koje imaju q vrijednosti na sebi i poredavamo ih sa rank
  select
    tb2.*,
    rank() over (partition by case when q_polje is not null then 1 end order by lvl) rnk
  from tb2
)
--select * From tb3; /
,
  tb4 as (
  -- vadimo CONTAINS_FLOWVARIABLE_XMETA kolone i njihova mapiranja, dio je tu koji nismo dodsad uspili izvadit 
  select
    --cjl.id,
    cjl.lvl col_id,
    to_char(flw.name_xmeta) column_name,
    to_char(nvl(der.PARSEDEXPRESSION_XMETA, flw.SOURCECOLUMNID_XMETA)) column_mapping
   ,tb0.name_xmeta link_name
   ,tb0.transformer_name
   ,tb0.job_name
   ,TB0.TARGET_TABLE
   --
    ,tb0.FROM_OUTPUTPIN_XMETA,
    tb0.TO_INPUTPIN_XMETA,
    tb0.transformer_XMETA_REPOS_OBJECT_ID_XMETA,
    tb0.application_id,
    tb0.ret_nrt
   --,'fdf' link_name
  from tb0
  cross join lateral (
    select
      level lvl,
      to_char(regexp_substr(tb0.CONTAINS_FLOWVARIABLE_XMETA, '[^[:cntrl:]]+',1,level)) id
    from dual
    connect by level <= regexp_count(tb0.CONTAINS_FLOWVARIABLE_XMETA, '[^[:cntrl:]]+',1)
  ) cjl
  left join XMETA.DATASTAGEXDSFLOWVARIBL flw
    on flw.XMETA_REPOS_OBJECT_ID_XMETA = cjl.id
  left join XMETA.DATASTAGEXDSDERIVATION der
    on der.XMETA_REPOS_OBJECT_ID_XMETA = to_char(substr(flw.HASVALUE_DERIVATION_XMETA,2,64))
 --where to_char(flw.name_xmeta) = 'ORIGINATION_DATE'
)
--select * From tb4; /
,
tb5 as (
  -- hvatamo samo retke sa q vrijednosti, multipliciramo q+1 puta sa cross join lateral
  -- radimo mjesta da ubacimo ispred svih polja koja imaju q>0 polja iz DATASTAGEXDSFLOWVARIBL 
  select 
    tb3.*,
    lvl1,
    rownum as rn
  from tb3
  cross join lateral (
    select
      level lvl1
    from dual
    connect by level <= q_polje+1
  ) cjl
  --where q_polje is not null
)
--select * From tb5; /
,
TB6 AS (
  -- izbacujemo sve prve, njima ćemo ostaviti mapiranje, a na ostale ćemo nakačiti iz DATASTAGEXDSFLOWVARIBL
  SELECT
    TB5.*,
    ROWNUM RN_JOIN_FLW
  FROM TB5 WHERE LVL1 > 1
  ORDER BY RN
),
TB7 AS (
  -- SPAJAMO FLOWVARIABLE I MJESTA NAKON Q IZ FLOVARPROPS
  SELECT * FROM TB6
  LEFT JOIN TB4
    ON TB6.RN_JOIN_FLW = TB4.COL_ID
),
TB8 AS (
  -- sajamo nove kolone na priširene stare
  SELECT
    NVL(TB7.COLUMN_NAME,TB5.DF_NAMES) AS COLUMN_NAME,
    TB5.TARGET_TABLE,
    coalesce(TB7.COLUMN_MAPPING, TB5.P_POLJE, tb5.df_src_col_id) AS COLUMN_MAPPING,
    TB7.COL_ID AS FLOWAR_COLID,
    tb5.df_src_col_id,
    tb5.link_name,
    tb5.transformer_name,
    tb5.job_name,
     tb5.FROM_OUTPUTPIN_XMETA,
    tb5.TO_INPUTPIN_XMETA,
    tb5.transformer_XMETA_REPOS_OBJECT_ID_XMETA,
    tb5.application_id,
    tb5.ret_nrt
  FROM TB5
  LEFT JOIN TB7
    ON TB5.RNK=TB7.RNK
    AND TB5.LVL1=TB7.LVL1
  ORDER BY 
    TB5.LVL, -- redoslijed ide prvo po props
    TB7.COL_ID -- zatim po ubačenim kolonama, ovime će ubačene kolone ići ispred kolone sa q>0
)
, prm_hash as (
  select XMETA_LOCKINGROOT_XMETA,FOR_JOBOBJECT_XMETA,to_char(VALUEEXPRESSION_XMETA) hash_filename from XMETA.DATASTAGEXDSPARAMETRVL  p
  where  to_char(PARAMETERNAME_XMETA) = 'FileName'
),
hashFiles as (
  select 
    jb.DSNAMESPACE_XMETA job_project,
    jb.CATEGORY_XMETA job_folder,
    jb.name_xmeta job_name, 
    jb.XMETA_REPOS_OBJECT_ID_XMETA job_XMETA_REPOS_OBJECT_ID_XMETA,  
    lnk.name_xmeta link_name,
    'write' as read_write, --> '' link_arrow1,
    stg.name_xmeta hash_stage_name,
    prm.hash_filename hash_file_name,
    lnk.XMETA_REPOS_OBJECT_ID_XMETA link_id,
    hash_filename,
    stg.XMETA_REPOS_OBJECT_ID_XMETA stg_XMETA_REPOS_OBJECT_ID_XMETA,
    STG.SHORTDESCRIPTION_XMETA,
    1 as jedan
  from prm_hash prm
  left join XMETA.DATASTAGEX_DSJOBDEF jb
    on jb.XMETA_REPOS_OBJECT_ID_XMETA = prm.XMETA_LOCKINGROOT_XMETA
  left join XMETA.DATASTAGEX_DSLINK lnk
    on lnk.XMETA_REPOS_OBJECT_ID_XMETA = prm.FOR_JOBOBJECT_XMETA
  left join XMETA.DATASTAGEX_DSinPUTPIN in_pin
    on in_pin.XMETA_REPOS_OBJECT_ID_XMETA = lnk.TO_INPUTPIN_XMETA
  left join XMETA.DATASTAGEX_DSSTAGE stg
    on in_pin.CONTAINER_RID = stg.XMETA_REPOS_OBJECT_ID_XMETA
  where 5=5
    --and jb.name_xmeta = 'ContractPreJobRetail'
    and stg.STAGETYPECLASSNAME_XMETA = 'HashedFileStage'  
  union all  
  select 
    jb.DSNAMESPACE_XMETA job_project,
    jb.CATEGORY_XMETA job_folder,
    jb.name_xmeta job_name,  
    jb.XMETA_REPOS_OBJECT_ID_XMETA job_XMETA_REPOS_OBJECT_ID_XMETA,  
    lnk.name_xmeta link_name,
    'read' as read_write,
    stg.name_xmeta hash_stage_name,
    prm.hash_filename hash_file_name,
    lnk.XMETA_REPOS_OBJECT_ID_XMETA link_id,
    prm.hash_filename,
    stg.XMETA_REPOS_OBJECT_ID_XMETA stg_XMETA_REPOS_OBJECT_ID_XMETA,
    STG.SHORTDESCRIPTION_XMETA,
    1 as jedan
  from prm_hash prm
  left join XMETA.DATASTAGEX_DSJOBDEF jb
    on jb.XMETA_REPOS_OBJECT_ID_XMETA = prm.XMETA_LOCKINGROOT_XMETA
  left join XMETA.DATASTAGEX_DSLINK lnk
    on lnk.XMETA_REPOS_OBJECT_ID_XMETA = prm.FOR_JOBOBJECT_XMETA
  left join XMETA.DATASTAGEX_DSoutPUTPIN out_pin
    on out_pin.XMETA_REPOS_OBJECT_ID_XMETA = LNK.FROM_OUTPUTPIN_XMETA
  left join XMETA.DATASTAGEX_DSSTAGE stg
    on out_pin.CONTAINER_RID = stg.XMETA_REPOS_OBJECT_ID_XMETA
  where 5=5
    and stg.STAGETYPECLASSNAME_XMETA = 'HashedFileStage'
)
--
--
--
,sqls as
        (
        SELECT 
          s.XMETA_REPOS_OBJECT_ID_XMETA
          , J.NAME_XMETA     JOB_NAME
          , S.NAME_XMETA    STAGE_NAME
          , S.HAS_INPUTPIN_XMETA 
          , S.HAS_OUTPUTPIN_XMETA  
          ,J.DSNAMESPACE_XMETA project_name
          ,S.STAGETYPE_XMETA STAGETYPE
          , 
          case when VALUEEXPRESSION_XMETA is not null then
          replace(
          substr(XMLTYPE(VALUEEXPRESSION_XMETA).EXTRACT('//Properties/Usage/SQL/SelectStatement/text()').getClobVal(),10)
          ,']]>',null)
          else
          null
          end SELECT_STATEMENT   
          --, substr(XMLTYPE(VALUEEXPRESSION_XMETA).EXTRACT('//Properties/Usage/SQL/InsertStatement/text()').getClobVal(),10) INSERT_STATEMENT
          --, substr(XMLTYPE(VALUEEXPRESSION_XMETA).EXTRACT('//Properties/Usage/SQL/UpdateStatement/text()').getClobVal(),10) UPDATE_STATEMENT
          --, substr(XMLTYPE(VALUEEXPRESSION_XMETA).EXTRACT('//Properties/Usage/SQL/DeleteStatement/text()').getClobVal(),10) DELETE_STATEMENT
        FROM XMETA.DATASTAGEX_DSSTAGE s
        INNER JOIN XMETA.DATASTAGEX_DSJOBDEF J
        ON  S.CONTAINER_RID = J.XMETA_REPOS_OBJECT_ID_XMETA
        LEFT JOIN XMETA.DATASTAGEXDSPARAMETRVL V
        ON  S.XMETA_REPOS_OBJECT_ID_XMETA = V.CONTAINER_RID
            AND V.PARAMETERNAME_XMETA = 'XMLProperties'    
        WHERE 
        1=1
            AND S.STAGETYPE_XMETA like '%Connector'
            AND 
            case when VALUEEXPRESSION_XMETA is not null then
                XMLTYPE(VALUEEXPRESSION_XMETA).EXISTSNODE('//Properties/Usage/SQL/*')
            else
                0
            end = 1
        )  
--
--
--
, stage_in_out as
(
select job.DSNAMESPACE_XMETA project_name,
       --job.category_xmeta folder_name,
       job.NAME_XMETA AS Job_Name,
       JOB.XMETA_REPOS_OBJECT_ID_XMETA job_XMETA_REPOS_OBJECT_ID_XMETA,
       stage_in.name_xmeta AS StageIn_Name,
       stage_out.name_xmeta AS StageOut_Name   ,
       stage_in.xmeta_repos_object_id_xmeta  AS StageIn_xmeta_repos_object_id_xmeta,
       stage_out.xmeta_repos_object_id_xmeta AS StageOut_xmeta_repos_object_id_xmeta
       ,STAGE_IN.STAGETYPE_XMETA  StageIn_STAGETYPE_XMETA              
       --,d.*
  FROM XMETA.datastagex_dsjobdef job
       join XMETA.datastagex_dsstage stage_in     on job.xmeta_repos_object_id_XMETA = stage_in.container_rid
      left join  XMETA.datastagex_dsoutputpin pout_id on pout_id.container_rid = stage_in.xmeta_repos_object_id_xmeta
      left  join XMETA.datastagex_dslink link_in on pout_id.xmeta_repos_object_id_xmeta = link_in.from_outputpin_xmeta 
       left join  XMETA.datastagex_dsinputpin pin_id on pin_id.xmeta_repos_object_id_xmeta = LINK_IN.TO_INPUTPIN_XMETA
       left join XMETA.datastagex_dsstage stage_out    on pin_id.container_rid = stage_out.xmeta_repos_object_id_xmeta       
where 1=1
and  job.DSNAMESPACE_XMETa = 'RBADWH-PE:IFRS9' 
)
--
--
--
,stage_in_out_recursive as
(
select 
 level,
 SYS_CONNECT_BY_PATH (a.StageIn_Name, '/') PATH ,
 connect_by_root(a.StageIn_Name) as root,
 a.StageIn_xmeta_repos_object_id_xmeta--SYS_CONNECT_BY_PATH (a.StageOut_Name, '/') PATH1  
 ,a.Job_Name  
 ,a.job_XMETA_REPOS_OBJECT_ID_XMETA
 ,a.StageIn_STAGETYPE_XMETA
 from   stage_in_out a
connect by nocycle prior   StageIn_xmeta_repos_object_id_xmeta = StageOut_xmeta_repos_object_id_xmeta
START WITH StageOut_Name is null
--START WITH StageIn_Name = 'RatingGrade'
--START WITH StageIn_STAGETYPE_XMETA like 'CHashedFileStage'
)  
--select * From tb8; /
-- ako imamo kombinirani maping onda imamo kolone koje nisu null
-- uzimamo prvi upit
select * from   (
select
dat.ret_nrt         ret_nrt,
dat.APPLICATION_ID  APPLICATION_ID, 
DAT.TARGET_TABLE    TARGET_TABLE,
 dat.column_name    TARGET_column_name
,dat.column_mapping column_mapping
,sqls.SELECT_STATEMENT              SQL_direct
,sqls_hash_fill.SELECT_STATEMENT    SQL_hash_stage_input
,'--> Tehnički detalji -->' "-"
,dat.job_name               target_job
--,LNK.NAME_XMETA             target_link_name
--,r_main_job.NAME_XMETA          target_stage_name
--,r_main_job.SHORTDESCRIPTION_XMETA              target_stage_description
,r_main_job.StageIn_STAGETYPE_XMETA    target_stage_type
--
,hashFilesfILL.job_name         source_hash_JOB
,hashFilesfILL.hash_file_name   source_hash_file_name
--,hashFilesfILL.hash_stage_name  hash_stage_name_fill
,hashFilesfILL.SHORTDESCRIPTION_XMETA source_hash_stage_description
,stage_in_out.StageOut_Name     source_hash_stage, --koji konektor puni HASH
2 order_by 
from   (
SELECT 
  ROWNUM AS COL_ID, 
  TB8.TARGET_TABLE,
  TB8.column_name, 
  tb8.column_mapping,
  'mixed' mapping_type,
  case 
    when tb8.FLOWAR_COLID is not null then 'CONTAINS_FLOWVARIABLE_XMETA'
    else 'DSFLOWVARPROPS_XMETA'
  end as maping_source,
  tb8.link_name,
  tb8.transformer_name,
  tb8.job_name
--  tb8.FROM_OUTPUTPIN_XMETA,
--  tb8.TO_INPUTPIN_XMETA,
,tb8.transformer_XMETA_REPOS_OBJECT_ID_XMETA
,tb8.APPLICATION_ID
,tb8.ret_nrt
FROM TB8
where (SELECT max(column_name) FROM TB8) is not null
union all
-- ako nemamo kombinirani maping onda uzimamo samo kolone iz flowvariable
-- ovo uključujemo sa where uvjetom ako u prethodnom upitu dobijemo da je vijrednost column_name null, samo ima jedan redak
SELECT 
  TB4.col_id,
  TB4.TARGET_TABLE,
  TB4.column_name,
  tb4.column_mapping,
  'clean' mapping_type,
  'CONTAINS_FLOWVARIABLE_XMETA' as maping_source,
  TB4.link_name,
  tb4.transformer_name,
  tb4.job_name
--  tb4.FROM_OUTPUTPIN_XMETA,
--  tb4.TO_INPUTPIN_XMETA,
,tb4.transformer_XMETA_REPOS_OBJECT_ID_XMETA
,TB4.APPLICATION_ID
,TB4.ret_nrt
FROM TB4
where (SELECT max(column_name) FROM TB8) is null
) dat
 join stage_in_out_recursive r_main_job on r_main_job.StageIn_xmeta_repos_object_id_xmeta = dat.transformer_XMETA_REPOS_OBJECT_ID_XMETA
/*
 join xmeta.DATASTAGEX_DSSTAGE stg on stg.XMETA_REPOS_OBJECT_ID_XMETA = dat.transformer_XMETA_REPOS_OBJECT_ID_XMETA -- <--transformer u ovo slučaju središnji transformer
 join XMETA.datastagex_dsinputpin in_pin on in_pin.container_rid = stg.xmeta_repos_object_id_xmeta -- <--inputi prema središnjem transformeru
 join xmeta.DATASTAGEX_DSLINK lnk on  lnk.to_inPUTPIN_XMETA = in_pin.XMETA_REPOS_OBJECT_ID_XMETA   and instr(UPPER(dat.column_mapping),UPPER(LNK.NAME_XMETA||'.') ) > 0   --< -- spajanje mapiranja iz kolone i linka prema stage koji je ulazni tipa connector ili hash
 join  XMETA.datastagex_dsoutputpin out_pin on LNK.FROM_OUTPUTPIN_XMETA = out_pin.XMETA_REPOS_OBJECT_ID_XMETA
 join xmeta.DATASTAGEX_DSSTAGE stg_in on STG_IN.XMETA_REPOS_OBJECT_ID_XMETA = OUT_PIN.container_rid 
 */
 left join hashFiles on hashFiles.stg_XMETA_REPOS_OBJECT_ID_XMETA =  r_main_job.StageIn_xmeta_repos_object_id_xmeta and hashFiles.read_write = 'read' -- hash iz kojega se čita
            and hashFiles.job_name not in (select m.target_job from    job_mapping m) -- iznimke
 left join hashFiles hashFilesfILL on hashFilesfILL.hash_file_name =  hashFiles.hash_file_name and hashFilesfILL.read_write = 'write'  and hashFilesfILL.job_name in (select ifrs9_jobs.JOB_NAME from ifrs9_jobs )-- hash ¸u kojem se piše
 -- 
 left join sqls on sqls.XMETA_REPOS_OBJECT_ID_XMETA =  r_main_job.StageIn_xmeta_repos_object_id_xmeta and r_main_job.StageIn_STAGETYPE_XMETA like '%Connector' --SQL od stage koji direktno u jobu za modul
 left join stage_in_out on stage_in_out.job_XMETA_REPOS_OBJECT_ID_XMETA = hashFilesfILL.job_XMETA_REPOS_OBJECT_ID_XMETA and stage_in_out.StageOut_Name = hashFilesfILL.hash_stage_name
 left join stage_in_out_recursive r on r.root =  hashFilesfILL.hash_stage_name and hashFilesfILL.job_XMETA_REPOS_OBJECT_ID_XMETA = r.job_XMETA_REPOS_OBJECT_ID_XMETA and r.StageIn_STAGETYPE_XMETA like '%Connector'
 left join sqls sqls_hash_fill on sqls_hash_fill.XMETA_REPOS_OBJECT_ID_XMETA = r.STAGEIN_XMETA_REPOS_OBJECT_ID_XMETA -- konektor koji puni SQL hash 
where 1=1 
--and  dat.column_name ='RATING'
)
order by 
order_by,
ret_nrt,
APPLICATION_ID, 
TARGET_TABLE,
TARGET_column_name