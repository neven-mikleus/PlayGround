-- Tražimo zadanu hardkodiranu vrijednost u filteru transformera od nekog linka
-- filter constrainti se nalaze u DATASTAGXDSFLTRCNSTRNT
-- filteri od linka se nalaze u koloni link.HAS_FILTERCONSTRAINT_XMETA u CSV obliku, separator je neki kontrolni znak
-- obrnuti smjer, na filter-constraintu u DATASTAGXDSFLTRCNSTRNT imamo kolonu OF_LINK_XMETA koja je ID od linka
-- dakle tražimo izraz u constraintu
-- spajamo se na link, out_pin, stage(transfomer), job
select
  jb.dsnamespace_xmeta job_project,
  jb.category_xmeta job_folder,
  jb.name_xmeta job_name,
  flt.FILTEREXPRESSION_XMETA,
  --flt.OF_LINK_XMETA,
  --flt.HAS_FUNCTIONCALL_XMETA,
  --flt.PARSEDCONSTRAINT_XMETA,
  --flt.SOURCECOLUMNS_XMETA,
  lnk.name_xmeta link_name,
  stg.name_xmeta transformer_name,
  1 as jedan
from XMETA.DATASTAGXDSFLTRCNSTRNT flt
left join xmeta.DATASTAGEX_DSLINK lnk
  on lnk.XMETA_REPOS_OBJECT_ID_XMETA = flt.OF_LINK_XMETA
left join XMETA.DATASTAGEX_DSOUTPUTPIN out_pin
  on out_pin.XMETA_REPOS_OBJECT_ID_XMETA = lnk.FROM_OUTPUTPIN_XMETA
left join XMETA.DATASTAGEX_DSSTAGE stg
  on stg.XMETA_REPOS_OBJECT_ID_XMETA = out_pin.CONTAINER_RID
left join xmeta.DATASTAGEX_DSJOBDEF jb
  on jb.XMETA_REPOS_OBJECT_ID_XMETA = stg.XMETA_LOCKINGROOT_XMETA
where 6=6
  and flt.FILTEREXPRESSION_XMETA like '%IsNull(SaldoLkp.PARTIJA)%' -- < -- ### OVDI UPIŠI IZRAZ KOJI TRAŽIŠ U FILTERU ###
;