with tb1 as (
        select * 
          from (
        -- za sve ni�e na�ene kompajle tra�imo zadnje pokretanje
        select
          t1.jobid,
          t1.jobname,
          jr.CREATIONTIMESTAMP,
          jr.RUNSTARTTIMESTAMP,
          jr.RUNENDTIMESTAMP,
          jr.ELAPSEDRUNSECS,
          jr.RUNTYPE,
          jr.RUNMAJORSTATUS,
          jr.RUNMINORSTATUS,
          jr.ISUSERNAME,
          jr.DSUSERNAME,
          ROW_NUMBER() OVER (PARTITION BY jr.jobid ORDER BY jr.CREATIONTIMESTAMP desc) rn_run, -- uzimamo samo zadnje vrijeme
          1 as jedan
        from (
          -- tra�imo zadnje vrijeme kompaliranja za sve jobove te iz toga dohva�amo jobid
          select * from (
            select
              jobid,
              jobname,
              COMPILATIONTIMESTAMP,
              ROW_NUMBER() OVER (PARTITION BY jobname ORDER BY COMPILATIONTIMESTAMP desc) rn -- uzimamo samo zadnje vrijeme
            from DSODB.JOBEXEC
          ) where rn = 1 -- uzimamo samo zadnje vrijeme
        ) t1
        left join dsodb.JOBRUN jr
          on jr.jobid = t1.jobid
        ) where rn_run = 1 -- uzimamo samo zadnje vrijeme
)
--
-- MAIN
--
select
  t1.*,
  decode(jbc.JOBTYPE_XMETA, 3, 'Sequence', 1, 'ServerJob') job_type,
  tb1.RUNSTARTTIMESTAMP,
  tb1.RUNENDTIMESTAMP,
  tb1.ELAPSEDRUNSECS,
  to_char(to_date(tb1.ELAPSEDRUNSECS,'sssss'),'hh24:mi:ss')  ELAPSED_RUN_time,
  tb1.RUNTYPE,
  tb1.RUNMAJORSTATUS,
  tb1.RUNMINORSTATUS
from (
      select
        rownum as rno,
        job_name,
        par_job_name,
        project_c,
        par_project,
        level lev,
        SYS_CONNECT_BY_PATH(par_job_name, '/') Path1 /*,CONNECT_BY_ISCYCLE krug*/
      from (
        SELECT
          OBJ.jobNAME_XMETA AS job_name,
          JOBS.NAME_XMETA AS par_JOB_NAME,
          JOBS.DSNAMESPACE_XMETA par_project,
          JOBS2.DSNAMESPACE_XMETA project_c
        FROM  xmeta.DATASTAGEX_DSSTAGE OBJ,
          xmeta.DATASTAGEX_DSJOBDEF JOBS,
          xmeta.DATASTAGEX_DSJOBDEF JOBS2
        WHERE  OBJ.OF_JOBDEF_XMETA = JOBS.XMETA_REPOS_OBJECT_ID_XMETA
          and OBJ.STAGETYPECLASSNAME_XMETA='JSJobActivity'
          and OBJ.OF_JOBDEF_XMETA=jobs2.XMETA_REPOS_OBJECT_ID_XMETA
      )
      connect by NOCYCLE prior  job_name=par_job_name
      start with par_job_name  in
      ('IFRS9_Retail_WithCopy_PROD')
) t1
left join XMETA.DATASTAGEX_DSJOBDEF jbc
  on jbc.name_xmeta = t1.job_name
  and jbc.DSNAMESPACE_XMETA = t1.par_project
left join tb1 on
  tb1.jobname = t1.job_name
order by lev,rno
;