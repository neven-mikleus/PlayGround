select job.DSNAMESPACE_XMETA Projname,
       --job.category_xmeta folder_name,
       job.NAME_XMETA AS Job_Name,
       stage_in.name_xmeta AS StageIn_Name,
       stage_out.name_xmeta AS StageOut_Name               
       --,d.*
  FROM XMETA.datastagex_dsjobdef job
       join XMETA.datastagex_dsstage stage_in     on job.xmeta_repos_object_id_XMETA = stage_in.container_rid
      left join  XMETA.datastagex_dsoutputpin pout_id on pout_id.container_rid = stage_in.xmeta_repos_object_id_xmeta
      left  join XMETA.datastagex_dslink link_in on pout_id.xmeta_repos_object_id_xmeta = link_in.from_outputpin_xmeta 
       left join  XMETA.datastagex_dsinputpin pin_id on pin_id.xmeta_repos_object_id_xmeta = LINK_IN.TO_INPUTPIN_XMETA
       left join XMETA.datastagex_dsstage stage_out    on pin_id.container_rid = stage_out.xmeta_repos_object_id_xmeta       
where 1=1
  and job.DSNAMESPACE_XMETA = 'RBADWH-PE:IFRS9'
  --and job.NAME_XMETA = 'IFRS9_Contract_NonRetail_DST_prod'
  and job.NAME_XMETA = 'CustomerPreJob'  
  --and stage_in.name_xmeta = 'T1'      
  connect by NOCYCLE prior  stage_in.name_xmeta = stage_out.name_xmeta
START WITH stage_out.name_xmeta is null
   


with  dat as(
select job.DSNAMESPACE_XMETA Projname,
       --job.category_xmeta folder_name,
       job.NAME_XMETA AS Job_Name,
       stage_in.name_xmeta AS StageIn_Name,
       stage_out.name_xmeta AS StageOut_Name  ,
       stage_in.inputpins_xmeta,
       pout_id.*             
       --,d.*
  FROM XMETA.datastagex_dsjobdef job
       left join XMETA.datastagex_dsstage stage_in     on job.xmeta_repos_object_id_XMETA = stage_in.container_rid
      left join  XMETA.datastagex_dsoutputpin pout_id on pout_id.container_rid = stage_in.xmeta_repos_object_id_xmeta
      left  join XMETA.datastagex_dslink link_in on pout_id.xmeta_repos_object_id_xmeta = link_in.from_outputpin_xmeta 
       left join  XMETA.datastagex_dsinputpin pin_id on pin_id.xmeta_repos_object_id_xmeta = LINK_IN.TO_INPUTPIN_XMETA
       left join XMETA.datastagex_dsstage stage_out    on pin_id.container_rid = stage_out.xmeta_repos_object_id_xmeta       
where 1=1
  and job.DSNAMESPACE_XMETA = 'RBADWH-PE:IFRS9'
  --and job.NAME_XMETA = 'IFRS9_Contract_NonRetail_DST_prod'
 -- and job.NAME_XMETA = 'CustomerPreJob'  
  )   
  select 
    LEVEL,
    LPAD (' ', (LEVEL - 1) * 4, ' ') || StageIn_Name AS StageIn_Name_lev,
  StageIn_Name,StageOut_Name
   from dat  
    connect by NOCYCLE prior     StageOut_Name= StageIn_Name
 START WITH inputpins_xmeta is null
