with tb1 as (
        select * 
          from (
        -- za sve ni�e na�ene kompajle tra�imo zadnje pokretanje
        select
          t1.jobid,
          t1.jobname,
          jr.CREATIONTIMESTAMP,
          jr.RUNSTARTTIMESTAMP,
          jr.RUNENDTIMESTAMP,
          jr.ELAPSEDRUNSECS,
          jr.RUNTYPE,
          jr.RUNMAJORSTATUS,
          jr.RUNMINORSTATUS,
          jr.ISUSERNAME,
          jr.DSUSERNAME,
          ROW_NUMBER() OVER (PARTITION BY jr.jobid ORDER BY jr.CREATIONTIMESTAMP desc) rn_run, -- uzimamo samo zadnje vrijeme
          1 as jedan
        from (
          -- tra�imo zadnje vrijeme kompaliranja za sve jobove te iz toga dohva�amo jobid
          select * from (
            select
              jobid,
              jobname,
              COMPILATIONTIMESTAMP,
              ROW_NUMBER() OVER (PARTITION BY jobname ORDER BY COMPILATIONTIMESTAMP desc) rn -- uzimamo samo zadnje vrijeme
            from DSODB.JOBEXEC
          ) where rn = 1 -- uzimamo samo zadnje vrijeme
        ) t1
        left join dsodb.JOBRUN jr
          on jr.jobid = t1.jobid
          where  jr.RUNENDTIMESTAMP >=CAST (sysdate - 120 AS TIMESTAMP)
        ) where rn_run = 1 -- uzimamo samo zadnje vrijeme
)
, ifrs9_jobs as(
select tb1.jobname as job_name, RUNENDTIMESTAMP from   tb1
where 1=1   
/*
select 'IFRS9_NonRetail_WithCopy_PROD' job_name from dual union all 
select 'ExportData2_imp' job_name from dual union all 
select 'FXRate' job_name from dual union all 
select 'IFRS9_Account_NonRetail_KKR_PPZ_s_nakn' job_name from dual union all 
select 'IFRS9_Account_NonRetail_SDR_SDA_prod' job_name from dual union all 
select 'Bevent_KRD_NRT' job_name from dual union all 
select 'IFRS9_Contract_NonRetail_WSS_prod' job_name from dual union all 
select 'PaymentSchedule_NonRetail' job_name from dual union all 
select 'Chech_Duplicate_Records' job_name from dual union all 
select 'IFRS9_Account_Retail_KKR_TRC_PPZ_test_naknade' job_name from dual union all 
select 'IFRS9_Account_Retail_KKR_TRC_PPZ' job_name from dual union all 
select 'IFRS9_Collateral_Collateral_Link_NonRetail_New_VER4' job_name from dual union all 
select 'IFRS9_Contract_NonRetail_WSS_LORO_prod' job_name from dual union all 
select 'DSA_DATA_STATUS_Finish' job_name from dual union all 
select 'IFRS9_Fee_NonRetail' job_name from dual union all 
select 'IFRS9_Contract_NonRetail_OKV_prod' job_name from dual union all 
select 'IFRS9_Zero_Coupon_NonRetail' job_name from dual union all 
select 'IFRS9_Fee_Retail' job_name from dual union all 
select 'ExportData' job_name from dual union all 
select 'IFRS9_Securities_NonRetail_IN2_prod' job_name from dual union all 
select 'Fee_FAC' job_name from dual union all 
select 'IFRS9_Contract_NonRetail_FOR_test_def' job_name from dual union all 
select 'IFRS9_Contract_NonRetail_PKR_prod' job_name from dual union all 
select 'Chech_WriteOff_Contract_Mismatch' job_name from dual union all 
select 'DSA_DATA_STATUS_StartRetail_New' job_name from dual union all 
select 'IFRS9_Contract_NonRetail_LOC_prod' job_name from dual union all 
select 'IFRS9_Bevent_Seq_NRT' job_name from dual union all 
select 'IFRS9_Retail_WithCopy_PROD' job_name from dual union all 
select 'CustomerDsaClientNonRetail' job_name from dual union all 
select 'IFRS9_Contract_NonRetail_FOR_prod' job_name from dual union all 
select 'Fee_Akreditivi' job_name from dual union all 
select 'AccountPreJobRetail_New_test_def_naknade' job_name from dual union all 
select 'IFRS9_Contract_NonRetail_OKV_test_def' job_name from dual union all 
select 'Fee_GAR' job_name from dual union all 
select 'IFRS9_Contract_NonRetail_GAR_prod' job_name from dual union all 
select 'CustomerPreJob' job_name from dual union all 
select 'ExportDataSeq' job_name from dual union all 
select 'IFRS9_Contract_NonRetail_FAC_prod' job_name from dual union all 
select 'Bevent_PKR_NRT' job_name from dual union all 
select 'IFRS9_Bevent_Seq' job_name from dual union all 
select 'AccountPreJobNonRetail_New_test_naknade' job_name from dual union all 
select 'ContractPreJobRetail_test_Default' job_name from dual union all 
select 'IFRS9_Contract_Retail_GAR_test_def' job_name from dual union all 
select 'DSA_DATA_STATUS_StartNonRetail' job_name from dual union all 
select 'IFRS9_Contract_NonRetail_KRD_prod' job_name from dual union all 
select 'Fee_KRD' job_name from dual union all 
select 'Bevent_PKR' job_name from dual union all 
select 'IFRS9_Contract_NonRetail_LOC_test_def' job_name from dual union all 
select 'Fee_Okviri' job_name from dual union all 
select 'ContractPreJobNonRetail' job_name from dual union all 
select 'IFRS9_Contract_NonRetail_DST_prod' job_name from dual union all 
select 'CustomerDsaClientRetail' job_name from dual union all 
select 'Bevent_KRD' job_name from dual union all 
select 'Fee_PKR' job_name from dual union all 
select 'WriteOff_Retail_new_20191201' job_name from dual union all 
select 'IFRS9_Collateral_Collateral_Link_Retail_DONTCutHNBProvisions' job_name from dual union all 
select 'WriteOff_NRT' job_name from dual union all 
select 'IFRS9_Contract_Retail_PKR_test_def' job_name from dual union all 
select 'IFRS9_NonRetail_New_prod' job_name from dual union all 
select 'IFRS9_Contract_Retail_KRD_test_def' job_name from dual union all 
select 'PaymentSchedule_Retail' job_name from dual union all 
select 'Fee_Overdraft' job_name from dual union all 
select 'IFRS9_Retail_New' job_name from dual union all 
select 'IFRS9_Contract_Retail_DST' job_name from dual union all 
select 'WriteOff_Retail_HNB' job_name from dual 
*/
)
--
-- Main SQL
--
SELECT 
    DAT.PROJECT
  , dat.JOB_NAME
  , DAT.STAGE_NAME
  , case when type = 'SQL' then 
        DBMS_LOB.SUBSTR(DAT.EXPRESSION, 2000,DBMS_LOB.instr(DAT.EXPRESSION,'<SelectStatement')+50)  
    else
        DBMS_LOB.SUBSTR(DAT.EXPRESSION,2000,1)
    end as EXPRESSION
  ,   type
  , CASE WHEN UPPER(EXPRESSION) LIKE '%''HRK''%' THEN 'DA' ELSE 'NE' END IMA_HRK
  , CASE WHEN UPPER(EXPRESSION) LIKE '%''191''%' THEN 'DA' ELSE 'NE' END IMA_191
  , CASE WHEN UPPER(EXPRESSION) LIKE '%TECAJNADAN%' THEN 'DA' ELSE 'NE' END IMA_TECAJNADAN
  , CASE WHEN UPPER(EXPRESSION) LIKE '%SPOT_RATE%' THEN 'DA' ELSE 'NE' END IMA_SPOTRATE
  , CASE WHEN UPPER(EXPRESSION) LIKE '%GDWH24%' THEN 'DA' ELSE 'NE' END IMA_24BAZU
  , CASE WHEN type = 'HASH' THEN 'DA' ELSE 'NE' END IMA_HASH_NOT_CLEAR
  , IFRS9_JOBS.RUNENDTIMESTAMP
 FROM   
(
   --
   -- SQLovi
   --
   SELECT DSNAMESPACE_XMETA PROJECT,
       J.NAME_XMETA JOB_NAME,
       S.NAME_XMETA STAGE_NAME,
       v.VALUEEXPRESSION_XMETA EXPRESSION,
       'SQL' TYPE
  FROM XMETA.DATASTAGEX_DSSTAGE S
       JOIN XMETA.DATASTAGEX_DSJOBDEF J
          ON S.CONTAINER_RID = J.XMETA_REPOS_OBJECT_ID_XMETA
       LEFT JOIN XMETA.DATASTAGEXDSPARAMETRVL V
          ON S.XMETA_REPOS_OBJECT_ID_XMETA = V.CONTAINER_RID
  union all
  --
  -- HASH koji se NE kliraju
  --
  SELECT 
      JB.DSNAMESPACE_XMETA PROJECT,  
      JB.NAME_XMETA JOB_NAME,  
      STG.NAME_XMETA STAGE_NAME,
      PRM.VALUEEXPRESSION_XMETA EXPRESSION,
      'HASH' TYPE
    FROM XMETA.DATASTAGEXDSPARAMETRVL PRM
    LEFT JOIN XMETA.DATASTAGEX_DSJOBDEF JB
      ON JB.XMETA_REPOS_OBJECT_ID_XMETA = PRM.XMETA_LOCKINGROOT_XMETA
    LEFT JOIN XMETA.DATASTAGEX_DSLINK LNK
      ON LNK.XMETA_REPOS_OBJECT_ID_XMETA = PRM.FOR_JOBOBJECT_XMETA
    LEFT JOIN XMETA.DATASTAGEX_DSINPUTPIN IN_PIN
      ON IN_PIN.XMETA_REPOS_OBJECT_ID_XMETA = LNK.TO_INPUTPIN_XMETA
    LEFT JOIN XMETA.DATASTAGEX_DSSTAGE STG
      ON IN_PIN.CONTAINER_RID = STG.XMETA_REPOS_OBJECT_ID_XMETA
    WHERE 5=5
      --AND JB.NAME_XMETA = 'ContractPreJobRetail'
      AND STG.STAGETYPECLASSNAME_XMETA = 'HashedFileStage'
      --and to_char(prm.PARAMETERNAME_XMETA) not in ('ClearFile','DeleteFile','CreateFileOptions')
      --and stg.name_xmeta = 'ContractInterestKRD'
      AND TO_CHAR(PRM.PARAMETERNAME_XMETA) = 'ClearFile'
      AND NVL(DBMS_LOB.SUBSTR(PRM.VALUEEXPRESSION_XMETA,100),'0') = '0'
  union all
  --
  -- Filteri
  --
  SELECT JB.DSNAMESPACE_XMETA AS PROJECT,
       JB.NAME_XMETA AS JOB_NAME,
       STG.NAME_XMETA AS STAGE_NAME,
       FLT.FILTEREXPRESSION_XMETA AS EXPRESSION,
       'FILTER' TYPE
  FROM XMETA.DATASTAGXDSFLTRCNSTRNT FLT
       LEFT JOIN XMETA.DATASTAGEX_DSLINK LNK
          ON LNK.XMETA_REPOS_OBJECT_ID_XMETA = FLT.OF_LINK_XMETA
       LEFT JOIN XMETA.DATASTAGEX_DSOUTPUTPIN OUT_PIN
          ON OUT_PIN.XMETA_REPOS_OBJECT_ID_XMETA = LNK.FROM_OUTPUTPIN_XMETA
       LEFT JOIN XMETA.DATASTAGEX_DSSTAGE STG
          ON STG.XMETA_REPOS_OBJECT_ID_XMETA = OUT_PIN.CONTAINER_RID
       LEFT JOIN XMETA.DATASTAGEX_DSJOBDEF JB ON JB.XMETA_REPOS_OBJECT_ID_XMETA = STG.XMETA_LOCKINGROOT_XMETA
  UNION ALL
  --
  -- Transformeri
  --
    SELECT DSNAMESPACE_XMETA PROJECT,
       JB.NAME_XMETA JOB_NAME,
       STG.NAME_XMETA STAGE_NAME,
       DER.EXPRESSION_XMETA EXPRESSION,
       'TRANSFORMER' TYPE
  FROM XMETA.DATASTAGEXDSDERIVATION DER
       LEFT JOIN XMETA.DATASTAGEXDSFLOWVARIBL FLW
          ON FLW.XMETA_REPOS_OBJECT_ID_XMETA = DER.DERIVES_FLOWVARIABLE_XMETA
       LEFT JOIN XMETA.DATASTAGEX_DSLINK LNK
          ON LNK.XMETA_REPOS_OBJECT_ID_XMETA = FLW.CONTAINER_RID
       LEFT JOIN XMETA.DATASTAGEX_DSOUTPUTPIN OUT_PIN
          ON OUT_PIN.XMETA_REPOS_OBJECT_ID_XMETA = LNK.FROM_OUTPUTPIN_XMETA
       LEFT JOIN XMETA.DATASTAGEX_DSSTAGE STG
          ON STG.XMETA_REPOS_OBJECT_ID_XMETA = OUT_PIN.CONTAINER_RID
       LEFT JOIN XMETA.DATASTAGEX_DSJOBDEF JB
          ON JB.XMETA_REPOS_OBJECT_ID_XMETA = DER.XMETA_LOCKINGROOT_XMETA
) DAT
  JOIN IFRS9_JOBS ON IFRS9_JOBS.JOB_NAME = DAT.JOB_NAME
 WHERE 1=1 
   --AND DAT.PROJECT = 'RBADWH-P:IFRS9' -- <-- koji projekt pretra�uje�
   AND DAT.PROJECT = 'RBADWH-P:RBADWH30' -- <-- koji projekt pretra�uje�
   AND
   (
       -- upi�i listi pojmova koje pretra�uje� u expresionima
       UPPER(EXPRESSION) LIKE '%''HRK''%'
       OR
       UPPER(EXPRESSION) LIKE '%''191''%'
       OR
       UPPER(EXPRESSION) LIKE '%TECAJNADAN%'
       OR
       UPPER(EXPRESSION) LIKE '%SPOT_RATE%'
       OR
       UPPER(EXPRESSION) LIKE '%@GDWH24%'
       or
       (
       EXPRESSION like '0'
       and type = 'HASH'
       )
   )
   --
   --and  dat.JOB_NAME = 'WriteOff_Retail_new_20191201'