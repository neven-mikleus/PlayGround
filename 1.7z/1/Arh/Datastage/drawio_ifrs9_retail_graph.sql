DECLARE
  l_cnt number(30) := 0; 
   l_fill_color varchar2(20);
   l_text varchar2(32767) := 
'##
## Example CSV import. Use ## for comments and # for configuration. Paste CSV below.
## The following names are reserved and should not be used (or ignored):
## id, tooltip, placeholder(s), link and label (see below)
##
#
## Node label with placeholders and HTML.
## Default is ''%name_of_first_column%''.
#
# label: %name%<br><i style="color:gray;">%stage_type%</i>
#
## Node style (placeholders are replaced once).
## Default is the current style for nodes.
#
# style: label;image=%image%;whiteSpace=wrap;html=1;rounded=1;fillColor=%fill%;strokeColor=%stroke%;
#
## Parent style for nodes with child nodes (placeholders are replaced once).
#
# parentstyle: swimlane;whiteSpace=wrap;html=1;childLayout=stackLayout;horizontal=1;horizontalStack=0;resizeParent=1;resizeLast=0;collapsible=1;
#
## Style to be used for objects not in the CSV. If this is - then such objects are ignored,
## else they are created using this as their style, eg. whiteSpace=wrap;html=1;
#
# unknownStyle: -
#
## Optional column name that contains a reference to a named style in styles.
## Default is the current style for nodes.
#
# stylename: -
#
## JSON for named styles of the form {"name": "style", "name": "style"} where style is a cell style with
## placeholders that are replaced once.
#
# styles: -
#
## JSON for variables in styles of the form {"name": "value", "name": "value"} where name is a string
## that will replace a placeholder in a style.
#
# vars: -
#
## Optional column name that contains a reference to a named label in labels.
## Default is the current label.
#
# labelname: -
#
## JSON for named labels of the form {"name": "label", "name": "label"} where label is a cell label with
## placeholders.
#
# labels: -
#
## Uses the given column name as the identity for cells (updates existing cells).
## Default is no identity (empty value or -).
#
# identity: -
#
## Uses the given column name as the parent reference for cells. Default is no parent (empty or -).
## The identity above is used for resolving the reference so it must be specified.
#
# parent: -
#
## Adds a prefix to the identity of cells to make sure they do not collide with existing cells (whose
## IDs are numbers from 0..n, sometimes with a GUID prefix in the context of realtime collaboration).
## Default is csvimport-.
#
# namespace: csvimport-
#
## Connections between rows ("from": source colum, "to": target column).
## Label, style and invert are optional. Defaults are '', current style and false.
## If placeholders are used in the style, they are replaced with data from the source.
## An optional placeholders can be set to target to use data from the target instead.
## In addition to label, an optional fromlabel and tolabel can be used to name the column
## that contains the text for the label in the edges source or target (invert ignored).
## In addition to those, an optional source and targetlabel can be used to specify a label
## that contains placeholders referencing the respective columns in the source or target row.
## The label is created in the form fromlabel + sourcelabel + label + tolabel + targetlabel.
## Additional labels can be added by using an optional labels array with entries of the
## form {"label": string, "x": number, "y": number, "dx": number, "dy": number} where
## x is from -1 to 1 along the edge, y is orthogonal, and dx/dy are offsets in pixels.
## An optional placeholders with the string value "source" or "target" can be specified
## to replace placeholders in the additional label with data from the source or target.
## The target column may contain a comma-separated list of values.
## Multiple connect entries are allowed.
#
# connect: {"from": "parent_job", "to": "name", "invert": true, "label": "calls", \
#          "style": "curved=1;endArrow=blockThin;endFill=1;fontSize=11;"}
# connect: {"from": "refs", "to": "id", "style": "curved=1;fontSize=11;"}
#
## Node x-coordinate. Possible value is a column name. Default is empty. Layouts will
## override this value.
#
# left: 
#
## Node y-coordinate. Possible value is a column name. Default is empty. Layouts will
## override this value.
#
# top: 
#
## Node width. Possible value is a number (in px), auto or an @ sign followed by a column
## name that contains the value for the width. Default is auto.
#
# width: auto
#
## Node height. Possible value is a number (in px), auto or an @ sign followed by a column
## name that contains the value for the height. Default is auto.
#
# height: auto
#
## Collapsed state for vertices. Possible values are true or false. Default is false.
#
# collapsed: false
#
## Padding for autosize. Default is 0.
#
# padding: -12
#
## Comma-separated list of ignored columns for metadata. (These can be
## used for connections and styles but will not be added as metadata.)
#
# ignore: id,image,fill,stroke,refs,manager
#
## Column to be renamed to link attribute (used as link).
#
# link: url
#
## Spacing between nodes. Default is 40.
#
# nodespacing: 40
#
## Spacing between levels of hierarchical layouts. Default is 100.
#
# levelspacing: 100
#
## Spacing between parallel edges. Default is 40. Use 0 to disable.
#
# edgespacing: 40
#
## Name or JSON of layout. Possible values are auto, none, verticaltree, horizontaltree,
## verticalflow, horizontalflow, organic, circle, orgchart or a JSON string as used in
## Layout, Apply. Default is auto.
#
# layout: auto
#
## ---- CSV below this line. First line are column names. ----
name,stage_type,id,location,parent_job,sql,fill,stroke,refs,url,image';
BEGIN

dbms_output.put_line(l_text);
--dbms_output.put_line('name,stage_type,id,location,parent_job,email,fill,stroke,refs,url,image');

for rec in (
WITH obj
     AS (SELECT CASE
                   WHEN jobs.JOBTYPE_XMETA IN ('2', '3')
                   THEN
                      OBJ.jobNAME_XMETA
                   WHEN jobs.JOBTYPE_XMETA IN ('1')
                   THEN
                      obj.NAME_XMETA
                END
                   AS job_name,
                JOBS.NAME_XMETA AS par_JOB_NAME,
                JOBS.DSNAMESPACE_XMETA AS par_project,
                jobs.JOBTYPE_XMETA,
                obj.NAME_XMETA,
                OBJ.SUBTYPE_XMETA,
                OBJ.STAGETYPE_XMETA,
                CASE
                   WHEN     OBJ.STAGETYPE_XMETA IN ('OracleConnector',
                                                    'DB2Connector')
                        AND V.VALUEEXPRESSION_XMETA IS NOT NULL
                   THEN
                      XMLTYPE (V.VALUEEXPRESSION_XMETA)
                   --DBMS_LOB.SUBSTR(V.VALUEEXPRESSION_XMETA,500,1)
                   ELSE
                      xmltype('<a></a>')
                END
                   AS VALUEEXPRESSION_XMETA_sql
           FROM xmeta.DATASTAGEX_DSSTAGE OBJ
                LEFT JOIN xmeta.DATASTAGEX_DSJOBDEF JOBS
                   ON OBJ.OF_JOBDEF_XMETA = JOBS.XMETA_REPOS_OBJECT_ID_XMETA
                LEFT JOIN xmeta.DATASTAGEXDSPARAMETRVL V
                   ON     OBJ.XMETA_REPOS_OBJECT_ID_XMETA = V.CONTAINER_RID
                      AND V.PARAMETERNAME_XMETA = 'XMLProperties'
          --where 1=1 and JOBS.NAME_XMETA = 'IFRS9_Retail_New'
          WHERE     1 = 1
                AND STAGETYPE_XMETA IN ('CJobActivity'
                                        ,'OracleConnector'
                                        ,'DB2Connector'
                                        --,'CHashedFileStage'
                                        )
         UNION ALL
         SELECT JOBS.NAME_XMETA job_name,
                NULL par_JOB_NAME,
                NULL par_project,
                NULL JOBTYPE_XMETA,
                NULL NAME_XMETA,
                NULL SUBTYPE_XMETA,
                NULL STAGETYPE_XMETA,
                NULL VALUEEXPRESSION_XMETA_sql
           FROM xmeta.DATASTAGEX_DSJOBDEF JOBS--where 1=1 and JOBS.NAME_XMETA = 'IFRS9_Retail_New'
        )
    SELECT obj.par_project,
           obj.par_JOB_NAME as parent_job,
           obj.job_name as job_name ,
           JOBTYPE_XMETA,
           NAME_XMETA,
           SUBTYPE_XMETA,
           STAGETYPE_XMETA as stage_type,
           VALUEEXPRESSION_XMETA_sql,
           --XMLTYPE(REPLACE(REPLACE(dbms_lob.substr(VALUEEXPRESSION_XMETA_sql,500,1),'<![CDATA[',''),']]>','')).EXTRACT('/main/Properties/Usage/SQL/SelectStatement/text()').GETSTRINGVAL() connector_sql,
           XMLTYPE(REPLACE(REPLACE(VALUEEXPRESSION_XMETA_sql,'<![CDATA[',''),']]>','')).EXTRACT('/main/Properties/Usage/SQL/SelectStatement/text()').GETSTRINGVAL() connector_sql,           
           --XMLTYPE(REPLACE(REPLACE(VALUEEXPRESSION_XMETA_sql,'<![CDATA[',''),']]>','')).EXTRACT('/main/Properties/Usage/SQL/SelectStatement/text()').GETSTRINGVAL() XX,
           --XMLTYPE(VALUEEXPRESSION_XMETA_sql).EXTRACT('/main/Properties/Usage/SQL/SelectStatement/text()').GETSTRINGVAL() XX,
           LEVEL lev,
           SYS_CONNECT_BY_PATH (JOB_NAME, '/') PATH
      FROM obj
CONNECT BY NOCYCLE PRIOR job_name = par_job_name
START WITH job_name IN --('IFRS9_Retail_WithCopy_PROD')
           ('IFRS9_Retail_New')
) loop
    if rec.stage_type= 'CJobActivity' then
        l_fill_color := '#F9E79F';
    else
        l_fill_color := '#ABEBC6';        
    end if;
    
    dbms_output.put_line(rec.job_name||','||rec.stage_type||','||rec.job_name||',,'||rec.parent_job||','||rec.connector_sql||','||l_fill_color||',#82b366,,,');
    
    
    l_cnt := l_cnt+1;
    
    if l_cnt > 3 then
        exit;
        end if;
end loop;
/*
name,stage_type,id,location,parent_job,sql,fill,stroke,refs,url,image';

name,                                       stage_type,     id,                                         location,parent_job             ,   sql   ,fill           ,stroke,        refs,                               url,image
name,                                       stage_type,     id,                                         location,parent_job             ,   sql   ,fill           ,stroke,        refs,                               url,image
IFRS9_Retail_New,                           SEQUENCE,       IFRS9_Retail_New,                                   ,                       ,           ,#d5e8d4        ,#82b366,                           ,           ,
AccountPreJobRetail_New_test_def_naknade,   SEQUENCE,       AccountPreJobRetail_New_test_def_naknade,           ,IFRS9_Retail_New       ,           ,#d5e8d4        ,#82b366,       AccountPreJobRetail_New_test_def_naknade,,

*/
END;