-- tražimo kolone i mapiranja za link koji izlazi iz transformera
  -- PARAMETRI: linije 42-44
-- mapiranje može biti na flowvariable ili dsflowarprops ili kombinacija oba
-- detektirani ključevi u DSFLOWVARPROPS_XMETA:
-- 3,n,fy,l,x,s,i,q,d,o,A,H,R,G,N,I,O,S,J,T,K,U,>1,>e,P
-- razmak između polja je chr(??)<RS>

-- link koji izlazi iz transfomrera sadrži kolone i mapiranja kolona
-- [tb4] kolone i mapiranja mogu biti u polju CONTAINS_FLOWVARIABLE_XMETA (lista IDjeva za tablicu DATASTAGEXDSFLOWVARIBL)
  -- vrijednosti nalazimo u toj tablici ili tablici DATASTAGEXDSDERIVATION
-- [tb1] kolone i mapiranja mogu biti i u poljima DSFLOWVARPROPS_XMETA,DSFLOWVARNAMES_XMETA,DSFLOWVARSOURCECOLUMNIDS_XMETA
  -- ako se tu nalaze onda se nazivi kolona nalaze u DSFLOWVARNAMES_XMETA, a mapiranja u DSFLOWVARPROPS_XMETA
  -- ako se mapiranje ne nalazi u DSFLOWVARPROPS_XMETA, onda uzimamo iz DSFLOWVARSOURCECOLUMNIDS_XMETA

with tb0 as (
  -- upit dohvaća link i polja iz kojih ćemo vaditi kolone i mapiranja koja se nalaze u transformeru
  -- prvo napadamo DSFLOWVARPROPS_XMETA, a kasnije DATASTAGEXDSFLOWVARIBL
  select
    JB.DSNAMESPACE_XMETA JOB_PROJECT,
    lnk.XMETA_REPOS_OBJECT_ID_XMETA,
    lnk.name_xmeta,
    --stg.name_xmeta transformer_name,  
    --' -- ## -- ' spacer,
    lnk.CONTAINS_FLOWVARIABLE_XMETA,
    lnk.DSFLOWVARSOURCECOLUMNIDS_XMETA,
    lnk.DSFLOWVARNAMES_XMETA,
    lnk.DSFLOWVARPROPS_XMETA,
    jb.dsnamespace_xmeta
  from xmeta.DATASTAGEX_DSLINK lnk
  left join XMETA.DATASTAGEX_DSOUTPUTPIN out_pin
    on out_pin.XMETA_REPOS_OBJECT_ID_XMETA = lnk.FROM_OUTPUTPIN_XMETA
  left join XMETA.DATASTAGEX_DSSTAGE stg
    on stg.XMETA_REPOS_OBJECT_ID_XMETA = out_pin.CONTAINER_RID
  left join xmeta.DATASTAGEX_DSJOBDEF jb
    on jb.XMETA_REPOS_OBJECT_ID_XMETA = lnk.XMETA_LOCKINGROOT_XMETA
  where 7=7
    -- filtriramo link_id (ako imamo id brže je nego po link_name), job_name, link_name
--    and lnk.XMETA_REPOS_OBJECT_ID_XMETA = 'c2e76d84.78bf4d29.6duo7qlno.b001ar6.ja1fa1.4v74gtdurqjs1oj6fmjmg' -- ApplicationForm
--    and jb.DSNAMESPACE_XMETA = 'RBADWH-PE:RBADWH30'
--    and jb.name_xmeta = 'Applicant÷ZahtjeviTRC_SIRIUS'
--    and lnk.name_xmeta = 'ApplicationForm'
    and jb.name_xmeta = 'IFRS9_Contract_NonRetail_WSS_prod'
    and lnk.name_xmeta = 'ToDsa'
    and jb.DSNAMESPACE_XMETA = 'RBADWH-PE:IFRS9'
),
tb1 as (
  -- razbijamo polje DSFLOWVARNAMES_XMETA u retke, separator je chr(29) - to su nazivi kolona čija mapiranja se nalaze u DSFLOWVARPROPS_XMETA
  -- ako se mapiranje na nalazi u DSFLOWVARPROPS_XMETA, onda uzimamo vrijednost iz DSFLOWVARSOURCECOLUMNIDS_XMETA
  -- sve kolone koje postoje u mapiranju za zadani link a ne nalazimo u DSFLOWVARNAMES_XMETA biti će u CONTAINS_FLOWVARIABLE_XMETA
  -- kolone iz CONTAINS_FLOWVARIABLE_XMETA će imati mapiranje u DATASTAGEXDSDERIVATION tablici
  -- redoslijed kolona je zadan u DSFLOWVARPROPS_XMETA, ali oni redovi u DSFLOWVARPROPS_XMETA koji imaju u sebi q=<broj> prije sebe moraju 
  -- ubaciti onoliki broj kolona iz DSFLOWVARNAMES_XMETA koloko se nalazi iza q
  -- npr. ako je q=2 onda moramo ubaciti 2 kolone
  -- broj redaka u DSFLOWVARNAMES_XMETA odgovara broju redaka u DSFLOWVARPROPS_XMETA, imaju isti separator chr(29)
  -- ponekad se u DSFLOWVARPROPS_XMETA neće nalaziti naziv kolone, pa ga uzimamo redoslijedom iz DSFLOWVARNAMES_XMETA
  -- radimo replace "chr(29)" sa "|" kako razbili DSFLOWVARNAMES_XMETA i DSFLOWVARPROPS_XMETA u retke
  -- prvenstveno zato što DSFLOWVARPROPS_XMETA ima još kontrolnih znakova, pa ako bi razbijali po [[:cntrl:]] ne bi išlo
  select
    lnk.name_xmeta link_name,
    --stg.name_xmeta transformer_name,  
    --' -- ## -- ' spacer,
    lnk.CONTAINS_FLOWVARIABLE_XMETA,
    --lnk.DSFLOWVARNAMES_XMETA,
    --lnk.DSFLOWVARSOURCECOLUMNIDS_XMETA,
    --lnk.DSFLOWVARPROPS_XMETA,
    to_char(regexp_substr(replace(lnk.DSFLOWVARNAMES_XMETA, chr(29), '|'), '[^|]+',1,cjl.lvl)) df_names, -- chr29 je separator retka, vadimo imena kolona
    to_char(regexp_substr(replace(lnk.DSFLOWVARPROPS_XMETA, chr(29), '|'), '[^|]+',1,cjl.lvl)) df_prop,
    to_char(regexp_substr(replace(lnk.DSFLOWVARSOURCECOLUMNIDS_XMETA, chr(29), '| '), '[^|]+',1,cjl.lvl)) df_src_col_id, -- ubacujemo '|;' tako da uhvatimo i prazne
    cjl.lvl,
    1 as jedan
    --stg.*
  from tb0 lnk
  cross join lateral (
    -- razbojamo kolonu DSFLOWVARNAMES_XMETA u retke - vadimo nazive kolona
    select
      level lvl,
      to_char(regexp_substr(lnk.DSFLOWVARNAMES_XMETA, '[^[:cntrl:]+]',1,level)) id
    from dual
    connect by level <= regexp_count(lnk.DSFLOWVARNAMES_XMETA, '[^[:cntrl:]]+',1)
  ) cjl
)
--select * From tb1; /
,
tb2 as (
-- vadimo polja iz DSFLOWVARPROPS_XMETA:
  -- 3 - [description]
  -- y - tip kolone
  -- x - [Length]
  -- q - broj kolona koje treba ubacit prije kolone iz danog retka, a nalaze se u DATASTAGEXDSFLOWVARIBL
  -- d - [Display]
  -- o - db tip kolone [SQL type]
  -- R - naziv kolone [Column name]
  -- T - lokacija definicije tablice - iako nisam uspio naći tu lokaciju u table_definition tablici
  -- K - [Key] - ključ seta podataka
  -- >e - expression - mapiranje
  -- >P - parsed expression - mapiranje
  -- n,f,l,s,i,A,H,G,N,I,O,S,J,U,>1 - ?? - nepoznato značenje za sada
  -- ovime smo izvadili sva polja iz dwflowarnames,props, njihova mapiranja, q vrijednosti
  select
    tb1.lvl,
    df_names,
    substr(trim(df_src_col_id),2,nvl(length(trim(df_src_col_id)),2)-2) df_src_col_id,
    regexp_substr(tb1.df_prop, '[[:cntrl:]]>P=(.*?)[[:cntrl:]]',1,1,'i',1) p_polje, -- mapiranje, ako nema onda uzimamo iz DSFLOWVARSOURCECOLUMNIDS_XMETA
    regexp_substr(tb1.df_prop, '[[:cntrl:]]q=(.*?)[[:cntrl:]]',1,1,'i',1) q_polje, -- broj polja iz flowars koje treba ubaciti prije ovog polja
    regexp_substr(tb1.df_prop, '[[:cntrl:]]R=(.*?)[[:cntrl:]]',1,1,'i',1) r_polje -- naziv kolone - ne mora postojat, onda uzimamo iz DSFLOWVARNAMES_XMETA tamo je sigurno
  from tb1
)
--select * From tb2; /
,
tb3 as (
  -- detektiramo samo one kolone koje imaju q vrijednosti na sebi i poredavamo ih sa rank
  select
    tb2.*,
    rank() over (partition by case when q_polje is not null then 1 end order by lvl) rnk
  from tb2
)
--select * From tb3; /
,
  tb4 as (
  -- vadimo CONTAINS_FLOWVARIABLE_XMETA kolone i njihova mapiranja, dio je tu koji nismo dodsad uspili izvadit 
  select
    --cjl.id,
    cjl.lvl col_id,
    to_char(flw.name_xmeta) column_name,
    to_char(nvl(der.PARSEDEXPRESSION_XMETA, flw.SOURCECOLUMNID_XMETA)) column_mapping
  from tb0
  cross join lateral (
    select
      level lvl,
      to_char(regexp_substr(tb0.CONTAINS_FLOWVARIABLE_XMETA, '[^[:cntrl:]]+',1,level)) id
    from dual
    connect by level <= regexp_count(tb0.CONTAINS_FLOWVARIABLE_XMETA, '[^[:cntrl:]]+',1)
  ) cjl
  left join XMETA.DATASTAGEXDSFLOWVARIBL flw
    on flw.XMETA_REPOS_OBJECT_ID_XMETA = cjl.id
  left join XMETA.DATASTAGEXDSDERIVATION der
    on der.XMETA_REPOS_OBJECT_ID_XMETA = to_char(substr(flw.HASVALUE_DERIVATION_XMETA,2,64))
)
--select * From tb4; /
,
tb5 as (
  -- hvatamo samo retke sa q vrijednosti, multipliciramo q+1 puta sa cross join lateral
  -- radimo mjesta da ubacimo ispred svih polja koja imaju q>0 polja iz DATASTAGEXDSFLOWVARIBL 
  select 
    tb3.*,
    lvl1,
    rownum as rn
  from tb3
  cross join lateral (
    select
      level lvl1
    from dual
    connect by level <= q_polje+1
  ) cjl
  --where q_polje is not null
)
--select * From tb5; /
,
TB6 AS (
  -- izbacujemo sve prve, njima ćemo ostaviti mapiranje, a na ostale ćemo nakačiti iz DATASTAGEXDSFLOWVARIBL
  SELECT
    TB5.*,
    ROWNUM RN_JOIN_FLW
  FROM TB5 WHERE LVL1 > 1
  ORDER BY RN
),
TB7 AS (
  -- SPAJAMO FLOWVARIABLE I MJESTA NAKON Q IZ FLOVARPROPS
  SELECT * FROM TB6
  LEFT JOIN TB4
    ON TB6.RN_JOIN_FLW = TB4.COL_ID
),
TB8 AS (
  -- sajamo nove kolone na priširene stare
  SELECT
    NVL(TB7.COLUMN_NAME,TB5.DF_NAMES) AS COLUMN_NAME,
    coalesce(TB7.COLUMN_MAPPING, TB5.P_POLJE, tb5.df_src_col_id) AS COLUMN_MAPPING,
    TB7.COL_ID AS FLOWAR_COLID,
    tb5.df_src_col_id
  FROM TB5
  LEFT JOIN TB7
    ON TB5.RNK=TB7.RNK
    AND TB5.LVL1=TB7.LVL1
  ORDER BY 
    TB5.LVL, -- redoslijed ide prvo po props
    TB7.COL_ID -- zatim po ubačenim kolonama, ovime će ubačene kolone ići ispred kolone sa q>0
)
--select * From tb8; /
-- ako imamo kombinirani maping onda imamo kolone koje nisu null
-- uzimamo prvi upit
select * from   (
SELECT 
  ROWNUM AS COL_ID, 
  TB8.column_name, 
  tb8.column_mapping,
  'mixed' mapping_type,
  case 
    when tb8.FLOWAR_COLID is not null then 'CONTAINS_FLOWVARIABLE_XMETA'
    else 'DSFLOWVARPROPS_XMETA'
  end as maping_source
FROM TB8
where (SELECT max(column_name) FROM TB8) is not null
union all
-- ako nemamo kombinirani maping onda uzimamo samo kolone iz flowvariable
-- ovo uključujemo sa where uvjetom ako u prethodnom upitu dobijemo da je vijrednost column_name null, samo ima jedan redak
SELECT 
  TB4.*,
  'clean' mapping_type,
  'CONTAINS_FLOWVARIABLE_XMETA' as maping_source
FROM TB4
where (SELECT max(column_name) FROM TB8) is null
) dat
where 1=1 and   dat.column_name = 'ORIGINATION_DATE'