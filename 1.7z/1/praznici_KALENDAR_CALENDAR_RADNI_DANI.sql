CREATE OR REPLACE VIEW DWHRBA.KALENDAR_TECAJ_PROVERA AS
WITH
-- dat AS (SELECT DATE '2021-08-05' d FROM DUAL),
     d_before
     AS (SELECT *
           FROM DWHRBA.DATE_DIMENSION d),
     /* d_before_yesterday
     AS (SELECT *
           FROM DWHRBA.DATE_DIMENSION d),*/
     dat as
     (      
  SELECT  
         d.d_date d_date,
         d.weekday weekday,
         d.weekdayname weekdayname,
         d.isholiday isholiday,
         d.holidayname holidayname,
         CASE WHEN b.weekday in (1,7) OR b.isholiday = 1 THEN 'YES' ELSE null END
            date_before_sun_or_holiday,
         --
         b.d_date b_d_date,
         b.weekday b_weekday,
         b.weekdayname b_weekdayname,
         b.isholiday b_isholiday,
         b.holidayname b_holidayname
         /*,
         --
         b_y.d_date         b_y_d_date,
         b_y.weekday        b_y_weekday,
         b_y.weekdayname    b_y_weekdayname,
         b_y.isholiday      b_y_isholiday,
         b_y.holidayname    b_y_holidayname*/
    FROM DWHRBA.DATE_DIMENSION d
         JOIN d_before b ON b.d_date = d.d_date - 1
   WHERE 1 = 1
)
select   dat.d_date datum,
        -- dat.weekday,
         dat.weekdayname dan_u_tjednu_ime,
         dat.weekday dan_u_tjednu,
         dat.isholiday praznik,
         case
            --ako je dan prije ned ili holiday onda null
            when dat.weekday in (1,7)  or dat.isholiday = 1  THEN
                null
            when dat.b_weekday in (1,7) or dat.b_isholiday = 1   THEN                
                (
                select max(d_def.d_Date)
                  FROM dat d_def
                     --  JOIN dat b1 ON b1.d_date = d_def.d_date - 1
                 where d_def.d_Date < dat.d_Date
                   and d_def.weekday not in (1,2)
                   and (d_def.isholiday = 0  OR  d_def.weekday = 6 or d_def.b_isholiday = 0)
                   and d_def.b_isholiday != 1
                  -- and b1.isholiday != 1                 
                )
            else
                dat.d_date
            end datum_vazenja_za_provjeru, 
         case
            --ako je dan prije ned ili holiday onda null
            when dat.weekday in (1,7)  or dat.isholiday = 1  THEN
                'Ne provjeravam jer je subota, nedjelja ili praznik'
            when dat.b_weekday in (1,7) or dat.b_isholiday = 1   THEN
                'Provjeravan unazad datum '||
                (
                select to_char(max(d_def.d_Date),'dd.mm.yyyy')||' - '||to_char(max(d_def.d_Date),'day','NLS_DATE_LANGUAGE = CROATIAN')
                  FROM dat d_def
                      -- JOIN dat b1 ON b1.d_date = d_def.d_date - 1
                 where d_def.d_Date < dat.d_Date
                   and d_def.weekday not in (1,2)
                   and (d_def.isholiday = 0  OR  d_def.weekday = 6 or d_def.b_isholiday = 0)
                   and d_def.b_isholiday != 1
                   --and b1.isholiday != 1
                )
            else
                'Provjeravam datum '||to_char(dat.d_date,'dd.mm.yyyy')||' jer dan prije nije subota, nedjelja niti praznik'
            end opis_provjere,        
         --dat.isholiday,
         dat.holidayname praznik_ime
         /*                  
         dat.b_y_holidayname         
         dat.date_before_sun_or_holiday,
         --        
         dat.b_d_date,
         dat.b_weekday,
         dat.b_weekdayname,
         dat.b_isholiday,
         dat.b_holidayname
         */
from  dat
order by d_date